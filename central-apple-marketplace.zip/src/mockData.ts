import { Product, Supplier } from './types';

export const CATEGORIES = [
  'Smartphones',
  'Laptops',
  'Tablets',
  'Acessórios',
  'Smartwatches',
  'Áudio'
];

export const SUPPLIERS: Supplier[] = [
  {
    id: 's1',
    name: 'Central Apple Official',
    photo: 'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?q=80&w=100&auto=format&fit=crop',
    rating: 4.9,
    isB2C: true
  }
];

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'iPhone 13 Pro 128GB',
    price: 750,
    category: 'Smartphones',
    condition: 'Semi-novo',
    image: 'https://images.unsplash.com/photo-1632661674596-df8be070a5c5?q=80&w=400&auto=format&fit=crop',
    description: 'iPhone 13 Pro em excelente estado, bateria a 92%. Inclui caixa e cabo original.',
    supplierId: 's1',
    featured: true,
    bestSeller: true,
    createdAt: '2024-03-01'
  },
  {
    id: '2',
    name: 'MacBook Air M1 2020',
    price: 850,
    category: 'Laptops',
    condition: 'Usado',
    image: 'https://images.unsplash.com/photo-1611186871348-b1ec696e52c9?q=80&w=400&auto=format&fit=crop',
    description: 'MacBook Air M1, 8GB RAM, 256GB SSD. Algumas marcas de uso leves.',
    supplierId: 's1',
    featured: true,
    createdAt: '2024-03-05'
  },
  {
    id: '3',
    name: 'iPad Pro 11" M2',
    price: 900,
    category: 'Tablets',
    condition: 'Novo',
    image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?q=80&w=400&auto=format&fit=crop',
    description: 'iPad Pro novo, selado na caixa. Versão 128GB Wi-Fi.',
    supplierId: 's1',
    bestSeller: true,
    createdAt: '2024-03-10'
  },
  {
    id: '4',
    name: 'AirPods Pro 2nd Gen',
    price: 180,
    category: 'Acessórios',
    condition: 'Semi-novo',
    image: 'https://images.unsplash.com/photo-1588423770574-91021160df63?q=80&w=400&auto=format&fit=crop',
    description: 'AirPods Pro com cancelamento de ruído ativo. Higienizados e prontos a usar.',
    supplierId: 's1',
    createdAt: '2024-03-12'
  },
  {
    id: '5',
    name: 'Apple Watch Series 7',
    price: 250,
    category: 'Smartwatches',
    condition: 'Usado',
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?q=80&w=400&auto=format&fit=crop',
    description: 'Apple Watch 45mm, GPS. Bracelete desportiva preta.',
    supplierId: 's1',
    createdAt: '2024-03-15'
  },
  {
    id: '6',
    name: 'iPhone 11 64GB',
    price: 320,
    category: 'Smartphones',
    condition: 'Usado',
    image: 'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?q=80&w=400&auto=format&fit=crop',
    description: 'iPhone 11 em bom estado. Ecrã sem riscos.',
    supplierId: 's1',
    bestSeller: true,
    createdAt: '2024-03-18'
  }
];
