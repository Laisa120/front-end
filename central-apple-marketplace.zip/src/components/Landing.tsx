import React, { useState, useEffect } from 'react';
import { ShoppingBag, PlusCircle, ArrowRight, ShieldCheck, Zap, Users } from 'lucide-react';
import { View } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface LandingProps {
  setView: (view: View) => void;
}

const CAROUSEL_IMAGES = [
  "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=800&auto=format&fit=crop", // Smartphone
  "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=800&auto=format&fit=crop", // Laptop
  "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=800&auto=format&fit=crop", // Camera
  "https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop", // Keyboard
  "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?q=80&w=800&auto=format&fit=crop", // Mouse
];

export default function Landing({ setView }: LandingProps) {
  const [currentImage, setCurrentImage] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % CAROUSEL_IMAGES.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-[calc(100vh-64px)] flex flex-col items-center justify-center py-12">
      {/* Main Publicity Banner */}
      <section className="w-full max-w-6xl mx-auto bg-white rounded-[32px] overflow-hidden shadow-2xl border border-gray-100 relative">
        <div className="absolute top-0 left-0 w-full h-2 gradient-primary"></div>
        
        <div className="flex flex-col lg:flex-row items-stretch">
          {/* Left Content */}
          <div className="flex-1 p-8 md:p-16 flex flex-col justify-center">
            <div className="inline-flex items-center space-x-2 bg-orange-50 text-primary px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider mb-6 w-fit">
              <Zap className="w-3 h-3" />
              <span>Plataforma #1 em Eletrónicos</span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-black text-gray-900 leading-tight mb-6">
              O Teu Universo <span className="text-primary">Eletrónico</span> Começa Aqui.
            </h1>
            
            <p className="text-lg text-gray-500 mb-10 leading-relaxed max-w-lg">
              Compra com segurança os teus dispositivos favoritos. A Central Apple une transparência e tecnologia para a melhor experiência de compra de eletrónicos.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => setView('listing')}
                className="w-full gradient-primary text-white px-8 py-4 rounded-2xl font-bold text-lg hover:opacity-90 transition-all shadow-xl shadow-primary/30 flex items-center justify-center group"
              >
                <ShoppingBag className="mr-2 w-5 h-5" />
                Comprar Agora
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
          
          {/* Right Visual - Carousel */}
          <div className="flex-1 relative min-h-[400px] lg:min-h-full overflow-hidden">
            <div className="absolute inset-0 gradient-primary opacity-10 z-10 pointer-events-none"></div>
            
            <AnimatePresence mode="wait">
              <motion.img
                key={currentImage}
                src={CAROUSEL_IMAGES[currentImage]}
                initial={{ opacity: 0, scale: 1.1 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.8, ease: "easeInOut" }}
                alt="Central Apple Visual"
                className="absolute inset-0 w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </AnimatePresence>

            {/* Carousel Indicators */}
            <div className="absolute bottom-6 right-0 left-0 flex justify-center space-x-2 z-20">
              {CAROUSEL_IMAGES.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentImage(i)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    currentImage === i ? 'bg-primary w-6' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>

            {/* Floating Badges */}
            <div className="absolute top-8 right-8 glass p-4 rounded-2xl shadow-xl animate-bounce-slow z-20">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-green-500 text-white rounded-full flex items-center justify-center">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold text-gray-900">100% Seguro</p>
                  <p className="text-[10px] text-gray-500">Garantia Verificada</p>
                </div>
              </div>
            </div>
            
            <div className="absolute bottom-8 left-8 glass p-4 rounded-2xl shadow-xl animate-bounce-slow delay-700 z-20">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary text-white rounded-full flex items-center justify-center">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs font-bold text-gray-900">+50k Usuários</p>
                  <p className="text-[10px] text-gray-500">Comunidade Ativa</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Trust Badges */}
      <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8 w-full max-w-4xl opacity-50 grayscale hover:grayscale-0 transition-all duration-700">
        <div className="flex items-center justify-center font-black text-2xl text-gray-400">APPLE</div>
        <div className="flex items-center justify-center font-black text-2xl text-gray-400">SAMSUNG</div>
        <div className="flex items-center justify-center font-black text-2xl text-gray-400">HUAWEI</div>
        <div className="flex items-center justify-center font-black text-2xl text-gray-400">XIAOMI</div>
      </div>
    </div>
  );
}
