import React, { useState } from 'react';
import { Mail, Lock, User, ArrowRight } from 'lucide-react';
import { View } from '../types';

interface AuthProps {
  setView: (view: View) => void;
  onAuthSuccess: (isSupplier: boolean) => void;
}

export default function Auth({ setView, onAuthSuccess }: AuthProps) {
  const [accountType, setAccountType] = useState<'customer' | 'supplier'>('customer');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAuthSuccess(accountType === 'supplier');
  };

  return (
    <div className="py-12 flex justify-center">
      <div className="w-full max-w-md bg-white p-8 rounded-2xl border border-gray-100 shadow-xl">
        <div className="text-center mb-8">
          <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center text-white font-bold text-3xl mx-auto mb-4 shadow-lg shadow-primary/20">
            C
          </div>
          <h2 className="text-2xl font-bold text-gray-900">
            Bem-vindo de volta!
          </h2>
          <p className="text-sm text-gray-500 mt-2">
            Acede à tua conta para continuar.
          </p>
        </div>

        <div className="flex p-1 bg-surface rounded-xl mb-6">
          <button 
            onClick={() => setAccountType('customer')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${accountType === 'customer' ? 'bg-white shadow-sm text-primary' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Sou Cliente
          </button>
          <button 
            onClick={() => setAccountType('supplier')}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${accountType === 'supplier' ? 'bg-white shadow-sm text-primary' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Sou Fornecedor
          </button>
        </div>

        {accountType === 'supplier' && (
          <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl mb-6 flex items-start space-x-3">
            <div className="w-2 h-2 mt-1.5 rounded-full bg-blue-500 shrink-0" />
            <p className="text-[10px] text-blue-700 font-medium leading-relaxed">
              O acesso de fornecedor é restrito à conta oficial da **Central Apple**.
            </p>
          </div>
        )}

        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-700 ml-1">E-mail</label>
            <div className="relative">
              <input 
                type="email" 
                placeholder="exemplo@email.com" 
                className="w-full bg-surface border-none rounded-xl py-3 pl-10 pr-4 text-sm focus:ring-2 focus:ring-primary"
                required
              />
              <Mail className="absolute left-3 top-3 text-gray-400 w-4 h-4" />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between items-center ml-1">
              <label className="text-xs font-bold text-gray-700">Palavra-passe</label>
              <button type="button" className="text-[10px] text-primary hover:underline">Esqueceste-te?</button>
            </div>
            <div className="relative">
              <input 
                type="password" 
                placeholder="••••••••" 
                className="w-full bg-surface border-none rounded-xl py-3 pl-10 pr-4 text-sm focus:ring-2 focus:ring-primary"
                required
              />
              <Lock className="absolute left-3 top-3 text-gray-400 w-4 h-4" />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full gradient-primary text-white py-4 rounded-xl font-bold hover:opacity-90 transition-all flex items-center justify-center shadow-lg shadow-primary/20 mt-6"
          >
            Entrar <ArrowRight className="ml-2 w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
