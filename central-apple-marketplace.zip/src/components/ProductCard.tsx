import React from 'react';
import { Star, ShoppingCart } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  key?: string | number;
  product: Product;
  onClick: (product: Product) => void;
  onAddToCart: (e: React.MouseEvent, product: Product) => void;
}

export default function ProductCard({ product, onClick, onAddToCart }: ProductCardProps) {
  return (
    <div 
      onClick={() => onClick(product)}
      className="group bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer border border-transparent hover:border-gray-100"
    >
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
            product.condition === 'Novo' ? 'bg-green-100 text-green-700' :
            product.condition === 'Semi-novo' ? 'bg-blue-100 text-blue-700' :
            'bg-orange-100 text-orange-700'
          }`}>
            {product.condition}
          </span>
          {product.featured && (
            <span className="bg-accent text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
              Destaque
            </span>
          )}
        </div>
      </div>
      
      <div className="p-4">
        <p className="text-xs text-gray-400 mb-1">{product.category}</p>
        <h3 className="font-bold text-gray-900 text-sm mb-2 line-clamp-1 group-hover:text-primary transition-colors">
          {product.name}
        </h3>
        
        <div className="flex items-center mb-3">
          <div className="flex text-yellow-400 mr-1">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3 h-3 fill-current" />
            ))}
          </div>
          <span className="text-[10px] text-gray-400">(24)</span>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-primary">
            {product.price.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }).replace('AOA', 'Kz')}
          </span>
          <button 
            onClick={(e) => onAddToCart(e, product)}
            className="p-2 bg-surface hover:bg-primary hover:text-white rounded-lg transition-all"
          >
            <ShoppingCart className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
