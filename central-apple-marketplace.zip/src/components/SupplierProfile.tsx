import React from 'react';
import { Star, MapPin, Package, ShoppingBag, ChevronLeft, ShieldCheck, Clock } from 'lucide-react';
import { Supplier, Product } from '../types';

interface SupplierProfileProps {
  supplier: Supplier;
  onBack: () => void;
  products: Product[];
}

export default function SupplierProfile({ supplier, onBack, products }: SupplierProfileProps) {
  return (
    <div className="py-8">
      <button 
        onClick={onBack}
        className="flex items-center text-gray-500 hover:text-primary mb-8 transition-colors group"
      >
        <ChevronLeft className="w-5 h-5 mr-1 group-hover:-translate-x-1 transition-transform" />
        <span>Voltar para o produto</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Profile Card */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm text-center">
            <div className="relative inline-block mb-6">
              <img 
                src={supplier.photo} 
                className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl" 
                referrerPolicy="no-referrer" 
              />
              {supplier.isB2C && (
                <div className="absolute bottom-1 right-1 bg-primary text-white p-1.5 rounded-full shadow-lg">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              )}
            </div>
            
            <h1 className="text-2xl font-black text-gray-900 mb-1">{supplier.name}</h1>
            <p className="text-sm text-gray-500 mb-6">{supplier.isB2C ? 'Loja Oficial Verificada' : 'Vendedor Particular'}</p>
            
            <div className="flex items-center justify-center space-x-2 mb-8">
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className={`w-4 h-4 ${i < Math.floor(supplier.rating) ? 'fill-current' : ''}`} />
                ))}
              </div>
              <span className="text-sm font-bold text-gray-900">{supplier.rating}</span>
            </div>

            <div className="grid grid-cols-3 gap-4 border-t border-gray-50 pt-8">
              <div>
                <p className="text-xl font-black text-primary">{products.length}</p>
                <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Produtos</p>
              </div>
              <div>
                <p className="text-xl font-black text-primary">120</p>
                <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Vendas</p>
              </div>
              <div>
                <p className="text-xl font-black text-primary">24</p>
                <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest">Reviews</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
            <h3 className="font-bold text-gray-900">Sobre o Fornecedor</h3>
            <div className="space-y-3">
              <div className="flex items-center text-sm text-gray-600">
                <MapPin className="w-4 h-4 mr-3 text-primary" />
                <span>Luanda, Angola</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <Clock className="w-4 h-4 mr-3 text-primary" />
                <span>Membro desde Jan 2024</span>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <ShieldCheck className="w-4 h-4 mr-3 text-primary" />
                <span>Identidade Verificada</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: History & Products */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
            <h2 className="text-xl font-black text-gray-900 mb-6 flex items-center">
              <Package className="w-5 h-5 mr-2 text-primary" />
              Historial de Produtos
            </h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {products.map(product => (
                <div key={product.id} className="flex items-center space-x-4 p-4 bg-surface rounded-2xl border border-gray-50 hover:border-primary/30 transition-all cursor-pointer group">
                  <div className="w-16 h-16 rounded-xl overflow-hidden bg-white shadow-sm">
                    <img src={product.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform" referrerPolicy="no-referrer" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-gray-900 text-sm truncate">{product.name}</h4>
                    <p className="text-primary font-black text-sm">{product.price.toLocaleString()} Kz</p>
                    <span className="text-[10px] font-bold text-gray-400 uppercase">{product.condition}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
            <h2 className="text-xl font-black text-gray-900 mb-6 flex items-center">
              <ShoppingBag className="w-5 h-5 mr-2 text-primary" />
              Feedback dos Clientes
            </h2>
            
            <div className="space-y-6">
              {[1, 2].map(i => (
                <div key={i} className="border-b border-gray-50 pb-6 last:border-0 last:pb-0">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-gray-100 rounded-full"></div>
                      <span className="font-bold text-sm text-gray-900">Cliente Satisfeito</span>
                    </div>
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => <Star key={i} className="w-3 h-3 fill-current" />)}
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 italic">"Excelente vendedor, o produto chegou em perfeitas condições e muito rápido. Recomendo vivamente!"</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
