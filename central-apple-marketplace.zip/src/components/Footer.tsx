export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center mb-4">
              <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center text-white font-bold text-lg mr-2">
                C
              </div>
              <span className="text-lg font-bold text-primary">Central Apple</span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed">
              A maior plataforma de eletrónicos usados em Angola. Qualidade, confiança e transparência em cada negócio.
            </p>
          </div>
          
          <div>
            <h4 className="font-bold text-gray-900 mb-4">Categorias</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-primary">Smartphones</a></li>
              <li><a href="#" className="hover:text-primary">Laptops</a></li>
              <li><a href="#" className="hover:text-primary">Tablets</a></li>
              <li><a href="#" className="hover:text-primary">Acessórios</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 mb-4">Suporte</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-primary">Centro de Ajuda</a></li>
              <li><a href="#" className="hover:text-primary">Termos de Uso</a></li>
              <li><a href="#" className="hover:text-primary">Privacidade</a></li>
              <li><a href="#" className="hover:text-primary">Contactos</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 mb-4">Newsletter</h4>
            <p className="text-sm text-gray-600 mb-4">Recebe as melhores ofertas no teu e-mail.</p>
            <div className="flex">
              <input 
                type="email" 
                placeholder="Teu e-mail" 
                className="flex-1 bg-surface border-none rounded-l-lg px-4 py-2 text-sm focus:ring-1 focus:ring-primary"
              />
              <button className="bg-primary text-white px-4 py-2 rounded-r-lg text-sm font-bold hover:bg-opacity-90 transition-opacity">
                OK
              </button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-100 pt-8 text-center">
          <p className="text-gray-400 text-xs">
            © 2026 Central Apple Marketplace. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
