import React, { useState, useMemo } from 'react';
import { Product } from '../types';
import ProductCard from './ProductCard';
import SidebarFilters from './SidebarFilters';
import CategoryCard from './CategoryCard';
import { ChevronDown, LayoutGrid, List, Search, SlidersHorizontal, Smartphone, Laptop, Tablet, Watch, Headphones, Speaker } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ProductListingProps {
  products: Product[];
  setSelectedProduct: (product: Product) => void;
  addToCart: (product: Product) => void;
}

export default function ProductListing({ products, setSelectedProduct, addToCart }: ProductListingProps) {
  const [sortBy, setSortBy] = useState('popular');
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    categories: [] as string[],
    conditions: [] as string[],
    maxPrice: 1000000,
    brands: [] as string[]
  });

  const categories = [
    { name: 'Smartphones', icon: <Smartphone className="w-5 h-5" /> },
    { name: 'Laptops', icon: <Laptop className="w-5 h-5" /> },
    { name: 'Tablets', icon: <Tablet className="w-5 h-5" /> },
    { name: 'Smartwatches', icon: <Watch className="w-5 h-5" /> },
    { name: 'Áudio', icon: <Headphones className="w-5 h-5" /> },
    { name: 'Acessórios', icon: <Speaker className="w-5 h-5" /> },
  ];

  const filteredProducts = useMemo(() => {
    let result = products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           product.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = filters.categories.length === 0 || filters.categories.includes(product.category);
      const matchesCondition = filters.conditions.length === 0 || filters.conditions.includes(product.condition);
      const matchesPrice = product.price <= filters.maxPrice;
      
      // For brands, we check if the name contains the brand (since mock data doesn't have brand field)
      const matchesBrand = filters.brands.length === 0 || filters.brands.some(brand => 
        product.name.toLowerCase().includes(brand.toLowerCase())
      );

      return matchesSearch && matchesCategory && matchesCondition && matchesPrice && matchesBrand;
    });

    // Sorting
    if (sortBy === 'price-asc') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'newest') {
      result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return result;
  }, [products, searchQuery, filters, sortBy]);

  return (
    <div className="py-12">
      {/* Header Section */}
      <div className="mb-12">
        <h1 className="text-4xl font-black text-gray-900 mb-4">Loja Central Apple</h1>
        
        {/* Store Banner */}
        <div className="relative w-full h-48 md:h-64 rounded-[32px] overflow-hidden mb-8 group shadow-2xl shadow-primary/10">
          <img 
            src="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=1200&auto=format&fit=crop" 
            alt="Promo Banner" 
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent flex flex-col justify-center px-8 md:px-12">
            <div className="inline-flex items-center space-x-2 bg-accent/20 backdrop-blur-md border border-accent/30 text-accent px-3 py-1 rounded-full w-fit mb-4">
              <span className="w-2 h-2 bg-accent rounded-full animate-pulse"></span>
              <span className="text-[10px] font-black uppercase tracking-widest">Campanha de Março</span>
            </div>
            <h2 className="text-2xl md:text-4xl font-black text-white mb-4 leading-tight">
              O teu próximo MacBook <br /> está à tua espera aqui.
            </h2>
            <p className="text-white/70 text-sm md:text-base max-w-md mb-6 hidden sm:block">
              Aproveita as nossas condições especiais de retoma e financiamento para o novo MacBook Pro M3.
            </p>
            <div className="flex items-center space-x-4">
              <button className="bg-white text-primary px-8 py-3 rounded-full font-black text-sm hover:scale-105 transition-transform shadow-xl">
                Explorar Agora
              </button>
              <span className="text-white/50 text-xs font-bold hidden md:block">Válido até 31 de Março</span>
            </div>
          </div>
        </div>

        <p className="text-gray-500 max-w-2xl">Explore a nossa vasta gama de eletrónicos. De iPhones a MacBooks, novos e usados, com a garantia de qualidade que você merece.</p>
      </div>

      {/* Categories Section */}
      <section className="mb-16">
        <h2 className="text-2xl font-black text-gray-900 mb-8">Categorias Populares</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((cat) => (
            <CategoryCard 
              key={cat.name} 
              name={cat.name} 
              icon={cat.icon} 
              onClick={() => setFilters(prev => ({ ...prev, categories: [cat.name] }))} 
            />
          ))}
        </div>
      </section>

      <div className="flex flex-col lg:flex-row gap-10">
        {/* Sidebar */}
        <div className="lg:w-64 flex-shrink-0">
          <SidebarFilters onFilterChange={setFilters} />
        </div>
        
        {/* Main Content */}
        <div className="flex-1">
          {/* Controls Bar */}
          <div className="bg-white p-4 rounded-3xl shadow-sm border border-gray-50 mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input 
                type="text"
                placeholder="Pesquisar na loja..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-primary/20 transition-all text-sm"
              />
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex items-center bg-gray-50 rounded-xl p-1">
                <button className="p-2 bg-white text-primary rounded-lg shadow-sm"><LayoutGrid className="w-4 h-4" /></button>
                <button className="p-2 text-gray-400 hover:text-primary transition-colors"><List className="w-4 h-4" /></button>
              </div>
              
              <div className="relative group">
                <button className="flex items-center space-x-3 bg-gray-50 px-5 py-3 rounded-2xl text-sm font-bold text-gray-700 hover:bg-gray-100 transition-all">
                  <SlidersHorizontal className="w-4 h-4 text-primary" />
                  <span>Ordenar: {
                    sortBy === 'popular' ? 'Popularidade' : 
                    sortBy === 'price-asc' ? 'Menor Preço' : 
                    sortBy === 'price-desc' ? 'Maior Preço' : 'Mais Recentes'
                  }</span>
                  <ChevronDown className="w-4 h-4" />
                </button>
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-2xl border border-gray-50 py-3 hidden group-hover:block z-30">
                  <button onClick={() => setSortBy('popular')} className="w-full text-left px-5 py-2.5 text-sm font-medium hover:bg-surface hover:text-primary transition-colors">Popularidade</button>
                  <button onClick={() => setSortBy('price-asc')} className="w-full text-left px-5 py-2.5 text-sm font-medium hover:bg-surface hover:text-primary transition-colors">Menor Preço</button>
                  <button onClick={() => setSortBy('price-desc')} className="w-full text-left px-5 py-2.5 text-sm font-medium hover:bg-surface hover:text-primary transition-colors">Maior Preço</button>
                  <button onClick={() => setSortBy('newest')} className="w-full text-left px-5 py-2.5 text-sm font-medium hover:bg-surface hover:text-primary transition-colors">Mais Recentes</button>
                </div>
              </div>
            </div>
          </div>

          {/* Results Info */}
          <div className="mb-6 flex items-center justify-between">
            <p className="text-sm font-bold text-gray-500">
              Mostrando <span className="text-gray-900">{filteredProducts.length}</span> produtos
            </p>
          </div>

          {/* Products Grid */}
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              <AnimatePresence>
                {filteredProducts.map(product => (
                  <motion.div
                    key={product.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.2 }}
                  >
                    <ProductCard 
                      product={product} 
                      onClick={setSelectedProduct}
                      onAddToCart={(e, p) => { e.stopPropagation(); addToCart(p); }}
                    />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <div className="bg-white rounded-[32px] p-20 text-center border-2 border-dashed border-gray-100">
              <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-10 h-10 text-gray-300" />
              </div>
              <h3 className="text-xl font-black text-gray-900 mb-2">Nenhum produto encontrado</h3>
              <p className="text-gray-500">Tente ajustar os seus filtros ou pesquisar por outro termo.</p>
              <button 
                onClick={() => {
                  setSearchQuery('');
                  setFilters({ categories: [], conditions: [], maxPrice: 1000000, brands: [] });
                }}
                className="mt-8 text-primary font-bold hover:underline"
              >
                Limpar todos os filtros
              </button>
            </div>
          )}
          
          {/* Pagination */}
          {filteredProducts.length > 0 && (
            <div className="mt-16 flex justify-center">
              <nav className="flex items-center space-x-3">
                <button className="px-6 py-3 rounded-2xl bg-white border border-gray-100 text-sm font-bold text-gray-400 cursor-not-allowed">Anterior</button>
                <button className="w-12 h-12 rounded-2xl bg-primary text-white text-sm font-black shadow-xl shadow-primary/20">1</button>
                <button className="w-12 h-12 rounded-2xl bg-white border border-gray-100 text-sm font-bold text-gray-600 hover:border-primary hover:text-primary transition-all">2</button>
                <button className="px-6 py-3 rounded-2xl bg-white border border-gray-100 text-sm font-bold text-gray-600 hover:border-primary hover:text-primary transition-all">Próximo</button>
              </nav>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
