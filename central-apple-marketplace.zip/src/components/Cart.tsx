import { Trash2, Plus, Minus, ShoppingBag, ArrowRight } from 'lucide-react';
import { CartItem, View } from '../types';

interface CartProps {
  items: CartItem[];
  updateQuantity: (id: string, delta: number) => void;
  removeItem: (id: string) => void;
  setView: (view: View) => void;
}

export default function Cart({ items, updateQuantity, removeItem, setView }: CartProps) {
  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const shipping = items.length > 0 ? 2500 : 0;
  const total = subtotal + shipping;

  if (items.length === 0) {
    return (
      <div className="py-20 text-center">
        <div className="w-20 h-20 bg-surface rounded-full flex items-center justify-center mx-auto mb-6">
          <ShoppingBag className="w-10 h-10 text-gray-300" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">O teu carrinho está vazio</h2>
        <p className="text-gray-500 mb-8">Parece que ainda não adicionaste nenhum produto.</p>
        <button 
          onClick={() => setView('listing')}
          className="bg-primary text-white px-8 py-3 rounded-full font-bold hover:bg-opacity-90 transition-all"
        >
          Explorar Produtos
        </button>
      </div>
    );
  }

  return (
    <div className="py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Carrinho de Compras</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Items List */}
        <div className="lg:col-span-2 space-y-6">
          {items.map(item => (
            <div key={item.id} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4">
              <div className="w-24 h-24 rounded-xl overflow-hidden bg-gray-50 flex-shrink-0">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-bold text-gray-900 truncate">{item.name}</h3>
                  <button 
                    onClick={() => removeItem(item.id)}
                    className="text-gray-400 hover:text-red-500 transition-colors p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <p className="text-xs text-gray-400 mb-3">{item.condition} • {item.category}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center bg-surface rounded-lg p-1">
                    <button 
                      onClick={() => updateQuantity(item.id, -1)}
                      className="p-1 hover:bg-white rounded-md transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-8 text-center text-sm font-bold">{item.quantity}</span>
                    <button 
                      onClick={() => updateQuantity(item.id, 1)}
                      className="p-1 hover:bg-white rounded-md transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                  <span className="font-bold text-primary">
                    {(item.price * item.quantity).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }).replace('AOA', 'Kz')}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm sticky top-24">
            <h3 className="font-bold text-gray-900 mb-6 text-xl">Resumo do Pedido</h3>
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>{subtotal.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }).replace('AOA', 'Kz')}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Entrega</span>
                <span>{shipping.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }).replace('AOA', 'Kz')}</span>
              </div>
              <div className="border-t border-gray-100 pt-4 flex justify-between text-xl font-bold text-gray-900">
                <span>Total</span>
                <span className="text-primary">{total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }).replace('AOA', 'Kz')}</span>
              </div>
            </div>
            
            <button 
              onClick={() => setView('checkout')}
              className="w-full gradient-primary text-white py-4 rounded-xl font-bold hover:opacity-90 transition-all flex items-center justify-center shadow-lg shadow-primary/20"
            >
              Finalizar Compra <ArrowRight className="ml-2 w-5 h-5" />
            </button>
            
            <p className="text-[10px] text-gray-400 text-center mt-4">
              Ao finalizar a compra, concordas com os nossos Termos e Condições.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
