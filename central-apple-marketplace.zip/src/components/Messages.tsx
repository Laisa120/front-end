import React, { useState } from 'react';
import { Send, Search, User, Phone, Video, Info, MoreVertical, ArrowLeft } from 'lucide-react';
import { View } from '../types';

const MOCK_CHATS = [
  { id: '1', name: 'António Manuel', lastMsg: 'Ainda tens o iPhone 13?', time: '10:30', unread: 2, online: true },
  { id: '2', name: 'Maria José', lastMsg: 'Obrigada, o teclado é ótimo!', time: 'Ontem', unread: 0, online: false },
  { id: '3', name: 'Carlos Silva', lastMsg: 'Fazemos entrega no Kilamba?', time: 'Ontem', unread: 0, online: true },
];

interface MessagesProps {
  setView: (view: View) => void;
}

export default function Messages({ setView }: MessagesProps) {
  const [selectedChat, setSelectedChat] = useState(MOCK_CHATS[0]);
  const [message, setMessage] = useState('');

  return (
    <div className="py-8 h-[calc(100vh-120px)]">
      <div className="bg-white rounded-3xl border border-gray-100 shadow-xl overflow-hidden flex h-full">
        {/* Sidebar */}
        <div className="w-full md:w-80 border-r border-gray-100 flex flex-col">
          <div className="p-4 border-b border-gray-100">
            <button 
              onClick={() => setView('listing')}
              className="flex items-center text-gray-400 hover:text-primary mb-4 transition-colors text-xs font-bold uppercase tracking-widest"
            >
              <ArrowLeft className="w-3 h-3 mr-1" /> Voltar à Loja
            </button>
            <h2 className="text-2xl font-black text-gray-900 mb-4">Mensagens</h2>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Procurar conversas..." 
                className="w-full bg-surface border-none rounded-xl pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {MOCK_CHATS.map(chat => (
              <button 
                key={chat.id}
                onClick={() => setSelectedChat(chat)}
                className={`w-full p-4 flex items-center space-x-4 hover:bg-surface transition-colors border-l-4 ${selectedChat.id === chat.id ? 'bg-surface border-primary' : 'border-transparent'}`}
              >
                <div className="relative">
                  <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden">
                    <img src={`https://picsum.photos/seed/${chat.id}/100/100`} alt={chat.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </div>
                  {chat.online && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>}
                </div>
                <div className="flex-1 text-left">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-gray-900 text-sm">{chat.name}</span>
                    <span className="text-[10px] text-gray-400">{chat.time}</span>
                  </div>
                  <p className="text-xs text-gray-500 truncate">{chat.lastMsg}</p>
                </div>
                {chat.unread > 0 && (
                  <div className="w-5 h-5 bg-primary text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                    {chat.unread}
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        <div className="flex-1 flex flex-col bg-surface/30">
          {/* Header */}
          <div className="p-4 bg-white border-b border-gray-100 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden">
                <img src={`https://picsum.photos/seed/${selectedChat.id}/100/100`} alt={selectedChat.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-sm">{selectedChat.name}</h3>
                <p className="text-[10px] text-green-500 font-bold">{selectedChat.online ? 'Online' : 'Offline'}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-gray-400">
              <button className="hover:text-primary transition-colors"><Phone className="w-5 h-5" /></button>
              <button className="hover:text-primary transition-colors"><Video className="w-5 h-5" /></button>
              <button className="hover:text-primary transition-colors"><Info className="w-5 h-5" /></button>
              <button className="hover:text-primary transition-colors"><MoreVertical className="w-5 h-5" /></button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 p-6 overflow-y-auto space-y-4">
            <div className="flex justify-center">
              <span className="text-[10px] font-bold text-gray-400 bg-white px-3 py-1 rounded-full shadow-sm uppercase tracking-wider">Hoje</span>
            </div>
            
            <div className="flex flex-col space-y-2 max-w-[80%]">
              <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-gray-50">
                <p className="text-sm text-gray-700">Olá! Vi o teu anúncio do iPhone 13. Ainda está disponível?</p>
              </div>
              <span className="text-[10px] text-gray-400 ml-1">10:30</span>
            </div>

            <div className="flex flex-col space-y-2 max-w-[80%] self-end items-end">
              <div className="bg-primary p-4 rounded-2xl rounded-tr-none shadow-lg shadow-primary/20">
                <p className="text-sm text-white">Olá António! Sim, ainda está disponível. Estás interessado?</p>
              </div>
              <span className="text-[10px] text-gray-400 mr-1">10:32</span>
            </div>
          </div>

          {/* Input */}
          <div className="p-4 bg-white border-t border-gray-100">
            <form 
              onSubmit={(e) => { e.preventDefault(); setMessage(''); }}
              className="flex items-center space-x-4"
            >
              <input 
                type="text" 
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Escreve a tua mensagem..." 
                className="flex-1 bg-surface border-none rounded-2xl px-6 py-3 text-sm focus:ring-2 focus:ring-primary"
              />
              <button 
                type="submit"
                className="w-12 h-12 gradient-primary text-white rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 hover:scale-105 transition-transform"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
