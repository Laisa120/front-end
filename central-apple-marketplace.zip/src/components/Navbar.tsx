import { ShoppingCart, User, Search, Menu } from 'lucide-react';
import { View } from '../types';

interface NavbarProps {
  setView: (view: View) => void;
  cartCount: number;
}

export default function Navbar({ setView, cartCount }: NavbarProps) {
  return (
    <nav className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center cursor-pointer" onClick={() => setView('landing')}>
            <div className="w-10 h-10 gradient-primary rounded-lg flex items-center justify-center text-white font-bold text-xl mr-2">
              C
            </div>
            <span className="text-xl font-bold text-primary hidden sm:block">Central Apple</span>
          </div>

          <div className="hidden md:flex items-center space-x-8 ml-10">
            <button onClick={() => setView('landing')} className="text-sm font-bold text-gray-600 hover:text-primary transition-colors">Início</button>
            <button onClick={() => setView('listing')} className="text-sm font-bold text-gray-600 hover:text-primary transition-colors">Loja</button>
          </div>

          <div className="flex-1 max-w-md mx-8 hidden md:block">
            <div className="relative">
              <input
                type="text"
                placeholder="Procurar iPhone usado..."
                className="w-full bg-surface border-none rounded-full py-2 pl-10 pr-4 focus:ring-2 focus:ring-secondary text-sm"
              />
              <Search className="absolute left-3 top-2.5 text-gray-400 w-4 h-4" />
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setView('cart')}
              className="relative p-2 text-gray-600 hover:text-primary transition-colors"
            >
              <ShoppingCart className="w-6 h-6" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-accent text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
            <button 
              onClick={() => setView('auth')}
              className="flex items-center space-x-1 p-2 text-gray-600 hover:text-primary transition-colors"
            >
              <User className="w-6 h-6" />
              <span className="text-sm font-medium hidden sm:block">Entrar</span>
            </button>
            <button className="md:hidden p-2 text-gray-600">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
