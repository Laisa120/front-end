import React from 'react';
import { User, Package, Heart, MapPin, CreditCard, ChevronRight, ArrowLeft } from 'lucide-react';
import { View } from '../types';

interface ProfileProps {
  setView: (view: View) => void;
}

export default function Profile({ setView }: ProfileProps) {
  return (
    <div className="py-8 max-w-4xl mx-auto">
      <button 
        onClick={() => setView('listing')}
        className="flex items-center text-gray-500 hover:text-primary mb-8 transition-colors group"
      >
        <ArrowLeft className="w-5 h-5 mr-1 group-hover:-translate-x-1 transition-transform" />
        <span>Voltar à Loja</span>
      </button>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Sidebar */}
        <div className="md:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-xl text-center">
            <div className="w-24 h-24 bg-surface rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-lg">
              <User className="w-12 h-12 text-gray-300" />
            </div>
            <h2 className="text-xl font-black text-gray-900">Utilizador</h2>
            <p className="text-sm text-gray-400">canguialaisa@gmail.com</p>
          </div>

          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <button className="w-full flex items-center justify-between p-4 hover:bg-surface transition-all text-primary font-bold">
              <div className="flex items-center">
                <Package className="w-5 h-5 mr-3" />
                <span>Meus Pedidos</span>
              </div>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button className="w-full flex items-center justify-between p-4 hover:bg-surface transition-all text-gray-600">
              <div className="flex items-center">
                <Heart className="w-5 h-5 mr-3" />
                <span>Favoritos</span>
              </div>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button className="w-full flex items-center justify-between p-4 hover:bg-surface transition-all text-gray-600">
              <div className="flex items-center">
                <MapPin className="w-5 h-5 mr-3" />
                <span>Endereços</span>
              </div>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button className="w-full flex items-center justify-between p-4 hover:bg-surface transition-all text-gray-600 border-t border-gray-50">
              <div className="flex items-center">
                <CreditCard className="w-5 h-5 mr-3" />
                <span>Pagamentos</span>
              </div>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-xl">
            <h3 className="text-2xl font-black text-gray-900 mb-6">Pedidos Recentes</h3>
            
            <div className="space-y-4">
              <div className="p-6 bg-surface rounded-2xl border border-gray-100 flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center">
                    <Package className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">Pedido #12345</p>
                    <p className="text-xs text-gray-400">23 Março 2026 • 2 itens</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-black text-primary">450.000 Kz</p>
                  <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-bold">Entregue</span>
                </div>
              </div>

              <div className="p-12 text-center border-2 border-dashed border-gray-100 rounded-2xl">
                <Package className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                <p className="text-gray-500">Não tens mais pedidos recentes.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
