import React, { useState, useRef } from 'react';
import { LayoutDashboard, Package, PlusCircle, User, Settings, LogOut, TrendingUp, ShoppingBag, CheckCircle, Edit, Trash2, Camera, MapPin, X, MessageSquare, Bell, ArrowLeft, CreditCard, Phone } from 'lucide-react';
import { Product, View, OrderNotification } from '../types';
import { CATEGORIES } from '../mockData';
import Messages from './Messages';

interface SupplierDashboardProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  setView: (view: View) => void;
  notifications: OrderNotification[];
  setNotifications: React.Dispatch<React.SetStateAction<OrderNotification[]>>;
}

export default function SupplierDashboard({ products, setProducts, setView, notifications, setNotifications }: SupplierDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'publish' | 'profile' | 'messages' | 'notifications'>('overview');
  const [productImages, setProductImages] = useState<string[]>([]);
  const [profileImage, setProfileImage] = useState("https://picsum.photos/seed/joao/200/200");
  const [location, setLocation] = useState("Luanda, Angola");
  
  const productInputRef = useRef<HTMLInputElement>(null);
  const profileInputRef = useRef<HTMLInputElement>(null);

  const [newProduct, setNewProduct] = useState({
    name: '',
    price: '',
    category: CATEGORIES[0],
    condition: 'Novo' as any,
    description: ''
  });

  const myProducts = products.filter(p => p.supplierId === 's2'); // Mocking current user as 's2'
  const myNotifications = notifications.filter(n => n.supplierId === 's2');
  const unreadCount = myNotifications.filter(n => !n.isRead).length;

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };

  const handleProductImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const newImages = Array.from(files).map(file => URL.createObjectURL(file as File));
      setProductImages(prev => [...prev, ...newImages].slice(0, 4));
    }
  };

  const handleProfileImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProfileImage(URL.createObjectURL(file));
    }
  };

  const handlePublish = () => {
    if (!newProduct.name || !newProduct.price) {
      alert("Por favor, preencha o nome e o preço do produto.");
      return;
    }

    const product: Product = {
      id: Math.random().toString(36).substr(2, 9),
      name: newProduct.name,
      price: Number(newProduct.price),
      category: newProduct.category,
      condition: newProduct.condition,
      image: productImages[0] || "https://picsum.photos/seed/default/400/400",
      description: newProduct.description,
      supplierId: 's2',
      createdAt: new Date().toISOString()
    };

    setProducts(prev => [product, ...prev]);
    alert("Produto publicado com sucesso!");
    setActiveTab('products');
    setNewProduct({ name: '', price: '', category: CATEGORIES[0], condition: 'Novo', description: '' });
    setProductImages([]);
  };

  return (
    <div className="py-8">
      {/* Hidden Inputs */}
      <input 
        type="file" 
        ref={productInputRef} 
        onChange={handleProductImageUpload} 
        multiple 
        accept="image/*" 
        className="hidden" 
      />
      <input 
        type="file" 
        ref={profileInputRef} 
        onChange={handleProfileImageUpload} 
        accept="image/*" 
        className="hidden" 
      />

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Sidebar Nav */}
        <aside className="w-full lg:w-64 space-y-2">
          <button 
            onClick={() => setView('listing')}
            className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-bold text-primary hover:bg-primary/5 transition-all mb-4 border border-primary/20"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Voltar à Loja</span>
          </button>

          <button 
            onClick={() => setActiveTab('overview')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'overview' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-gray-600 hover:bg-surface'}`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span>Resumo</span>
          </button>
          <button 
            onClick={() => setActiveTab('notifications')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'notifications' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-gray-600 hover:bg-surface'}`}
          >
            <div className="flex items-center space-x-3">
              <Bell className="w-5 h-5" />
              <span>Notificações</span>
            </div>
            {unreadCount > 0 && (
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold ${activeTab === 'notifications' ? 'bg-white text-primary' : 'bg-red-500 text-white'}`}>
                {unreadCount}
              </span>
            )}
          </button>
          <button 
            onClick={() => setActiveTab('products')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'products' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-gray-600 hover:bg-surface'}`}
          >
            <Package className="w-5 h-5" />
            <span>Meus Produtos</span>
          </button>
          <button 
            onClick={() => setActiveTab('publish')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'publish' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-gray-600 hover:bg-surface'}`}
          >
            <PlusCircle className="w-5 h-5" />
            <span>Publicar Produto</span>
          </button>
          <button 
            onClick={() => setActiveTab('messages')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'messages' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-gray-600 hover:bg-surface'}`}
          >
            <MessageSquare className="w-5 h-5" />
            <span>Mensagens</span>
          </button>
          <button 
            onClick={() => setActiveTab('profile')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-medium transition-all ${activeTab === 'profile' ? 'bg-primary text-white shadow-lg shadow-primary/20' : 'text-gray-600 hover:bg-surface'}`}
          >
            <User className="w-5 h-5" />
            <span>Perfil Fornecedor</span>
          </button>
          <div className="pt-8 space-y-2">
            <button 
              onClick={() => setView('settings')}
              className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-medium text-gray-600 hover:bg-surface transition-all"
            >
              <Settings className="w-5 h-5" />
              <span>Definições</span>
            </button>
            <button 
              onClick={() => setView('landing')}
              className="w-full flex items-center space-x-3 px-4 py-3 rounded-xl font-medium text-red-500 hover:bg-red-50 transition-all"
            >
              <LogOut className="w-5 h-5" />
              <span>Sair da Conta</span>
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1">
          {activeTab === 'overview' && (
            <div className="space-y-8">
              <h2 className="text-2xl font-bold text-gray-900">Resumo da Conta</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                  <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mb-4">
                    <Package className="w-6 h-6" />
                  </div>
                  <p className="text-sm text-gray-500 font-medium">Total de Produtos</p>
                  <p className="text-3xl font-bold text-gray-900">{myProducts.length}</p>
                </div>
                <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                  <div className="w-12 h-12 bg-green-50 text-green-600 rounded-xl flex items-center justify-center mb-4">
                    <ShoppingBag className="w-6 h-6" />
                  </div>
                  <p className="text-sm text-gray-500 font-medium">Produtos Vendidos</p>
                  <p className="text-3xl font-bold text-gray-900">12</p>
                </div>
                <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                  <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center mb-4">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <p className="text-sm text-gray-500 font-medium">Ganhos Totais</p>
                  <p className="text-3xl font-bold text-gray-900">450.000 Kz</p>
                </div>
              </div>

              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm">
                <h3 className="font-bold text-gray-900 mb-6">Vendas Recentes</h3>
                <div className="space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex items-center justify-between p-4 bg-surface rounded-xl">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-white rounded-lg overflow-hidden">
                          <img src={`https://picsum.photos/seed/sale-${i}/100/100`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-900 text-sm">iPhone 12 Pro Max</p>
                          <p className="text-[10px] text-gray-400">Vendido em 20 Mar 2026</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-primary text-sm">320.000 Kz</p>
                        <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-bold">Concluído</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Meus Produtos</h2>
                <button 
                  onClick={() => setActiveTab('publish')}
                  className="bg-primary text-white px-6 py-2 rounded-full font-bold text-sm hover:bg-opacity-90 transition-all flex items-center"
                >
                  <PlusCircle className="w-4 h-4 mr-2" /> Novo Produto
                </button>
              </div>

              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-surface">
                    <tr>
                      <th className="px-6 py-4 text-sm font-bold text-gray-700">Produto</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-700">Preço</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-700">Estado</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-700">Status</th>
                      <th className="px-6 py-4 text-sm font-bold text-gray-700 text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {myProducts.map(product => (
                      <tr key={product.id} className="hover:bg-surface/50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            <img src={product.image} className="w-10 h-10 rounded-lg object-cover" referrerPolicy="no-referrer" />
                            <span className="font-bold text-gray-900 text-sm truncate max-w-[150px]">{product.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm font-medium text-gray-600">
                          {product.price.toLocaleString()} Kz
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 uppercase">
                            {product.condition}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="flex items-center text-[10px] font-bold text-green-600">
                            <CheckCircle className="w-3 h-3 mr-1" /> Ativo
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right space-x-2">
                          <button className="p-2 text-gray-400 hover:text-primary transition-colors"><Edit className="w-4 h-4" /></button>
                          <button 
                            onClick={() => setProducts(prev => prev.filter(p => p.id !== product.id))}
                            className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'publish' && (
            <div className="space-y-8 max-w-2xl">
              <h2 className="text-2xl font-bold text-gray-900">Publicar Novo Produto</h2>
              
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Nome do Produto</label>
                    <input 
                      type="text" 
                      value={newProduct.name}
                      onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                      placeholder="Ex: iPhone 14 Pro Max" 
                      className="w-full bg-surface border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Preço (Kz)</label>
                    <input 
                      type="number" 
                      value={newProduct.price}
                      onChange={(e) => setNewProduct({...newProduct, price: e.target.value})}
                      placeholder="0.00" 
                      className="w-full bg-surface border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Categoria</label>
                    <select 
                      value={newProduct.category}
                      onChange={(e) => setNewProduct({...newProduct, category: e.target.value})}
                      className="w-full bg-surface border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary"
                    >
                      {CATEGORIES.map(cat => <option key={cat}>{cat}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Estado</label>
                    <select 
                      value={newProduct.condition}
                      onChange={(e) => setNewProduct({...newProduct, condition: e.target.value as any})}
                      className="w-full bg-surface border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary"
                    >
                      <option>Novo</option>
                      <option>Semi-novo</option>
                      <option>Usado</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Descrição Detalhada</label>
                  <textarea 
                    rows={4} 
                    value={newProduct.description}
                    onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                    placeholder="Descreve o estado do produto, bateria, acessórios incluídos..." 
                    className="w-full bg-surface border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary"
                  ></textarea>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Imagens do Produto (Máx 4)</label>
                  <div className="grid grid-cols-4 gap-4">
                    {productImages.map((img, i) => (
                      <div key={i} className="aspect-square bg-surface rounded-xl border border-gray-100 relative overflow-hidden group">
                        <img src={img} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        <button 
                          onClick={() => setProductImages(prev => prev.filter((_, idx) => idx !== i))}
                          className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                    {productImages.length < 4 && (
                      <button 
                        onClick={() => productInputRef.current?.click()}
                        className="aspect-square border-2 border-dashed border-gray-200 rounded-xl flex flex-col items-center justify-center text-gray-400 hover:border-primary hover:text-primary cursor-pointer transition-all"
                      >
                        <Camera className="w-6 h-6 mb-1" />
                        <span className="text-[10px] font-bold">Adicionar</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="pt-4">
                  <button 
                    onClick={handlePublish}
                    className="w-full gradient-primary text-white py-4 rounded-xl font-bold hover:opacity-90 transition-all shadow-lg shadow-primary/20"
                  >
                    Publicar Produto Agora
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'messages' && (
            <div className="h-[600px]">
              <Messages setView={setView} />
            </div>
          )}

          {activeTab === 'notifications' && (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold text-gray-900">Novos Pedidos</h2>
                <button 
                  onClick={() => setNotifications(prev => prev.map(n => n.supplierId === 's2' ? { ...n, isRead: true } : n))}
                  className="text-sm text-primary font-bold hover:underline"
                >
                  Marcar todas como lidas
                </button>
              </div>

              <div className="space-y-4">
                {myNotifications.length === 0 ? (
                  <div className="bg-white p-12 rounded-2xl border border-gray-100 text-center">
                    <Bell className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                    <p className="text-gray-500">Ainda não recebeste nenhum pedido.</p>
                  </div>
                ) : (
                  myNotifications.map(notification => (
                    <div 
                      key={notification.id} 
                      className={`bg-white p-6 rounded-2xl border transition-all ${!notification.isRead ? 'border-primary/30 shadow-md ring-1 ring-primary/10' : 'border-gray-100'}`}
                      onMouseEnter={() => !notification.isRead && markAsRead(notification.id)}
                    >
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                        <div className="flex items-center space-x-4">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${!notification.isRead ? 'bg-primary text-white' : 'bg-surface text-gray-400'}`}>
                            <ShoppingBag className="w-6 h-6" />
                          </div>
                          <div>
                            <p className="font-black text-gray-900 text-lg">Novo Pedido de {notification.customerName}</p>
                            <p className="text-xs text-gray-400">{new Date(notification.createdAt).toLocaleString('pt-AO')}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Total do Pedido</p>
                          <p className="text-2xl font-black text-primary">{notification.total.toLocaleString()} Kz</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-gray-50">
                        <div className="space-y-4">
                          <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Dados do Cliente</h4>
                          <div className="space-y-2">
                            <div className="flex items-center text-sm text-gray-600">
                              <User className="w-4 h-4 mr-2 text-gray-400" />
                              <span className="font-bold text-gray-900 mr-2">Nome:</span> {notification.customerName}
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <Phone className="w-4 h-4 mr-2 text-gray-400" />
                              <span className="font-bold text-gray-900 mr-2">Telefone:</span> {notification.customerPhone}
                            </div>
                            <div className="flex items-start text-sm text-gray-600">
                              <MapPin className="w-4 h-4 mr-2 mt-0.5 text-gray-400" />
                              <div>
                                <span className="font-bold text-gray-900 mr-2">Endereço:</span>
                                <p className="mt-1">{notification.customerAddress}</p>
                              </div>
                            </div>
                            <div className="flex items-center text-sm text-gray-600">
                              <CreditCard className="w-4 h-4 mr-2 text-gray-400" />
                              <span className="font-bold text-gray-900 mr-2">Pagamento:</span> {notification.paymentType}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Produtos Solicitados</h4>
                          <div className="bg-surface rounded-xl p-4 space-y-3">
                            {notification.items.map((item, idx) => (
                              <div key={idx} className="flex justify-between items-center text-sm">
                                <span className="text-gray-600">{item.name}</span>
                                <span className="font-bold text-gray-900">x{item.quantity}</span>
                              </div>
                            ))}
                          </div>
                          <div className="flex gap-2">
                            <button className="flex-1 bg-primary text-white py-3 rounded-xl font-bold text-sm hover:opacity-90 transition-all">
                              Aceitar Pedido
                            </button>
                            <button className="flex-1 bg-surface text-gray-600 py-3 rounded-xl font-bold text-sm hover:bg-gray-200 transition-all">
                              Recusar
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === 'profile' && (
            <div className="space-y-8 max-w-2xl">
              <h2 className="text-2xl font-bold text-gray-900">Perfil do Fornecedor</h2>
              
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-sm text-center">
                <div className="relative inline-block mb-6">
                  <img src={profileImage} className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl" referrerPolicy="no-referrer" />
                  <button 
                    onClick={() => profileInputRef.current?.click()}
                    className="absolute bottom-0 right-0 bg-primary text-white p-2 rounded-full shadow-lg hover:scale-110 transition-transform"
                  >
                    <Camera className="w-4 h-4" />
                  </button>
                </div>
                <h3 className="text-xl font-bold text-gray-900">João Silva</h3>
                <p className="text-sm text-gray-500 mb-6">Vendedor Particular desde 2024</p>
                
                <div className="flex justify-center space-x-12 mb-8">
                  <div>
                    <p className="text-2xl font-bold text-primary">4.5</p>
                    <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Avaliação</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">{myProducts.length}</p>
                    <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Produtos</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-primary">12</p>
                    <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Vendas</p>
                  </div>
                </div>

                <div className="space-y-4 text-left">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Nome Completo</label>
                    <input type="text" defaultValue="João Silva" className="w-full bg-surface border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Localização</label>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <input 
                        type="text" 
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        className="w-full bg-surface border-none rounded-xl pl-12 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary" 
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Bio / Descrição</label>
                    <textarea rows={3} defaultValue="Especialista em produtos Apple usados. Todos os meus produtos são testados e higienizados." className="w-full bg-surface border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary"></textarea>
                  </div>
                  <button className="w-full bg-primary text-white py-3 rounded-xl font-bold hover:bg-opacity-90 transition-all">
                    Guardar Alterações
                  </button>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
