import React from 'react';
import { ChevronRight } from 'lucide-react';

interface CategoryCardProps {
  key?: string | number;
  name: string;
  icon: React.ReactNode;
  onClick: () => void;
}

export default function CategoryCard({ name, icon, onClick }: CategoryCardProps) {
  return (
    <div 
      onClick={onClick}
      className="bg-white p-4 rounded-xl shadow-sm hover:shadow-md transition-all cursor-pointer flex items-center justify-between group border border-transparent hover:border-gray-100"
    >
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 bg-surface rounded-lg flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
          {icon}
        </div>
        <span className="font-bold text-gray-700">{name}</span>
      </div>
      <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-primary transition-colors" />
    </div>
  );
}
