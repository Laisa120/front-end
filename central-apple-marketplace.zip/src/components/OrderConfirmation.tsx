import React, { useState } from 'react';
import { CheckCircle, ShieldCheck, Truck, Package, ShoppingBag, ArrowRight, MessageCircle } from 'lucide-react';
import { CheckoutData, View } from '../types';

interface OrderConfirmationProps {
  data: CheckoutData;
  total: number;
  onFinish: () => void;
  setView: (view: View) => void;
}

export default function OrderConfirmation({ data, total, onFinish, setView }: OrderConfirmationProps) {
  const [isReceived, setIsReceived] = useState(false);

  const handleConfirmReceipt = () => {
    setIsReceived(true);
    // In a real app, this would trigger the payment release
  };

  return (
    <div className="py-12 max-w-3xl mx-auto text-center">
      {!isReceived ? (
        <div className="space-y-8">
          <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-8 animate-pulse">
            <Truck className="w-12 h-12 text-primary" />
          </div>
          
          <h1 className="text-4xl font-black text-gray-900 mb-4 tracking-tight">Pedido Realizado com Sucesso!</h1>
          <p className="text-gray-500 text-lg max-w-xl mx-auto leading-relaxed">
            Olá <span className="font-bold text-gray-900">{data.name}</span>, o seu pedido está a ser processado e será entregue em: <br />
            <span className="font-medium text-primary italic">"{data.address}"</span>
          </p>

          <div className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-xl text-left space-y-6">
            <div className="flex items-center justify-between border-b border-gray-50 pb-6">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-surface rounded-xl flex items-center justify-center">
                  <Package className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Estado do Pedido</p>
                  <p className="font-black text-gray-900">Aguardando Entrega</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Total a Pagar</p>
                <p className="font-black text-primary text-xl">{total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }).replace('AOA', 'Kz')}</p>
              </div>
            </div>

            <div className="bg-primary/5 p-6 rounded-2xl border border-primary/10 space-y-4">
              <div className="flex items-center text-primary font-black">
                <ShieldCheck className="w-6 h-6 mr-3" />
                POLÍTICA DE PAGAMENTO SEGURO
              </div>
              <p className="text-sm text-gray-600 leading-relaxed">
                O pagamento via <span className="font-bold text-gray-900">{data.paymentType}</span> só será libertado para o vendedor após a sua confirmação de receção. 
                <br /><br />
                <span className="font-bold text-red-500">Atenção:</span> Não partilhe códigos de confirmação antes de ter o produto em mãos e verificado.
              </p>
            </div>

            <button 
              onClick={handleConfirmReceipt}
              className="w-full gradient-primary text-white py-5 rounded-2xl font-black text-lg shadow-xl shadow-primary/20 hover:scale-[1.02] transition-all flex items-center justify-center"
            >
              CONFIRMAR QUE RECEBI O PRODUTO <CheckCircle className="ml-2 w-6 h-6" />
            </button>
            
            <button 
              onClick={() => setView('messages')}
              className="w-full bg-surface text-gray-600 py-4 rounded-2xl font-bold hover:bg-gray-200 transition-all flex items-center justify-center"
            >
              <MessageCircle className="mr-2 w-5 h-5" /> Falar com o Vendedor
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-8 animate-in fade-in zoom-in duration-500">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-8">
            <CheckCircle className="w-12 h-12 text-green-500" />
          </div>
          
          <h1 className="text-4xl font-black text-gray-900 mb-4 tracking-tight">Pagamento Confirmado!</h1>
          <p className="text-gray-500 text-lg max-w-xl mx-auto leading-relaxed">
            Obrigado por confirmar a receção. O pagamento foi libertado para o vendedor e a transação foi concluída com sucesso.
          </p>

          <div className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-xl">
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={onFinish}
                className="flex-1 gradient-primary text-white py-4 rounded-2xl font-black shadow-xl shadow-primary/20 hover:scale-[1.02] transition-all flex items-center justify-center"
              >
                Voltar à Loja <ShoppingBag className="ml-2 w-5 h-5" />
              </button>
              <button 
                onClick={() => setView('profile')}
                className="flex-1 bg-surface text-gray-600 py-4 rounded-2xl font-bold hover:bg-gray-200 transition-all flex items-center justify-center"
              >
                Ver Meus Pedidos <ArrowRight className="ml-2 w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
