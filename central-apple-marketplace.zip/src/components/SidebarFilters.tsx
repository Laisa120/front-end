import React, { useState, useEffect } from 'react';
import { Filter, ChevronDown, RotateCcw } from 'lucide-react';
import { CATEGORIES } from '../mockData';

interface SidebarFiltersProps {
  onFilterChange: (filters: {
    categories: string[];
    conditions: string[];
    maxPrice: number;
    brands: string[];
  }) => void;
}

export default function SidebarFilters({ onFilterChange }: SidebarFiltersProps) {
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedConditions, setSelectedConditions] = useState<string[]>([]);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState(1000000); // Increased max price for electronics

  const conditions = ['Novo', 'Semi-novo', 'Usado'];
  const brands = ['Apple', 'Samsung', 'Huawei', 'Xiaomi', 'Outros'];

  useEffect(() => {
    onFilterChange({
      categories: selectedCategories,
      conditions: selectedConditions,
      maxPrice: priceRange,
      brands: selectedBrands
    });
  }, [selectedCategories, selectedConditions, priceRange, selectedBrands]);

  const toggleCategory = (cat: string) => {
    setSelectedCategories(prev => 
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  const toggleCondition = (cond: string) => {
    setSelectedConditions(prev => 
      prev.includes(cond) ? prev.filter(c => c !== cond) : [...prev, cond]
    );
  };

  const toggleBrand = (brand: string) => {
    setSelectedBrands(prev => 
      prev.includes(brand) ? prev.filter(b => b !== brand) : [...prev, brand]
    );
  };

  const clearFilters = () => {
    setSelectedCategories([]);
    setSelectedConditions([]);
    setSelectedBrands([]);
    setPriceRange(1000000);
  };

  return (
    <aside className="w-full md:w-64 space-y-8 bg-white p-6 rounded-3xl shadow-sm border border-gray-50 h-fit sticky top-24">
      <div>
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-black text-gray-900 flex items-center text-lg">
            <Filter className="w-5 h-5 mr-2 text-primary" /> Filtros
          </h3>
          <button 
            onClick={clearFilters}
            className="text-xs font-bold text-primary hover:text-purple-600 flex items-center transition-colors"
          >
            <RotateCcw className="w-3 h-3 mr-1" /> Limpar
          </button>
        </div>
        
        <div className="space-y-8">
          {/* Categories */}
          <div>
            <h4 className="text-sm font-black text-gray-900 mb-4 uppercase tracking-wider">Categorias</h4>
            <div className="space-y-3">
              {CATEGORIES.map(cat => (
                <label key={cat} className="flex items-center group cursor-pointer">
                  <div className="relative flex items-center">
                    <input 
                      type="checkbox" 
                      checked={selectedCategories.includes(cat)}
                      onChange={() => toggleCategory(cat)}
                      className="peer h-5 w-5 cursor-pointer appearance-none rounded-md border-2 border-gray-200 transition-all checked:border-primary checked:bg-primary" 
                    />
                    <svg className="absolute left-1 top-1 h-3 w-3 text-white opacity-0 peer-checked:opacity-100 transition-opacity" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="ml-3 text-sm font-medium text-gray-600 group-hover:text-primary transition-colors">{cat}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Condition */}
          <div>
            <h4 className="text-sm font-black text-gray-900 mb-4 uppercase tracking-wider">Estado</h4>
            <div className="space-y-3">
              {conditions.map(cond => (
                <label key={cond} className="flex items-center group cursor-pointer">
                  <div className="relative flex items-center">
                    <input 
                      type="checkbox" 
                      checked={selectedConditions.includes(cond)}
                      onChange={() => toggleCondition(cond)}
                      className="peer h-5 w-5 cursor-pointer appearance-none rounded-md border-2 border-gray-200 transition-all checked:border-primary checked:bg-primary" 
                    />
                    <svg className="absolute left-1 top-1 h-3 w-3 text-white opacity-0 peer-checked:opacity-100 transition-opacity" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="ml-3 text-sm font-medium text-gray-600 group-hover:text-primary transition-colors">{cond}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-sm font-black text-gray-900 uppercase tracking-wider">Preço Máximo</h4>
              <span className="text-xs font-black text-primary bg-blue-50 px-2 py-1 rounded-lg">{priceRange.toLocaleString()} Kz</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="1000000" 
              step="1000"
              value={priceRange}
              onChange={(e) => setPriceRange(parseInt(e.target.value))}
              className="w-full h-1.5 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-primary"
            />
            <div className="flex justify-between text-[10px] font-bold text-gray-400 mt-3">
              <span>0 Kz</span>
              <span>1M Kz+</span>
            </div>
          </div>

          {/* Brands */}
          <div>
            <h4 className="text-sm font-black text-gray-900 mb-4 uppercase tracking-wider">Marcas</h4>
            <div className="space-y-3">
              {brands.map(brand => (
                <label key={brand} className="flex items-center group cursor-pointer">
                  <div className="relative flex items-center">
                    <input 
                      type="checkbox" 
                      checked={selectedBrands.includes(brand)}
                      onChange={() => toggleBrand(brand)}
                      className="peer h-5 w-5 cursor-pointer appearance-none rounded-md border-2 border-gray-200 transition-all checked:border-primary checked:bg-primary" 
                    />
                    <svg className="absolute left-1 top-1 h-3 w-3 text-white opacity-0 peer-checked:opacity-100 transition-opacity" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="4">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="ml-3 text-sm font-medium text-gray-600 group-hover:text-primary transition-colors">{brand}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
