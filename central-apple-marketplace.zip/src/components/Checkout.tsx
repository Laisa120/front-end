import React, { useState } from 'react';
import { ChevronLeft, CreditCard, MapPin, Phone, User, ShieldCheck, ArrowRight } from 'lucide-react';
import { CheckoutData, View } from '../types';

interface CheckoutProps {
  onBack: () => void;
  onSubmit: (data: CheckoutData) => void;
}

export default function Checkout({ onBack, onSubmit }: CheckoutProps) {
  const [formData, setFormData] = useState<CheckoutData>({
    name: '',
    address: '',
    phone: '',
    paymentType: 'Express'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.address || !formData.phone) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }
    onSubmit(formData);
  };

  return (
    <div className="py-8 max-w-2xl mx-auto">
      <button 
        onClick={onBack}
        className="flex items-center text-gray-500 hover:text-primary mb-8 transition-colors group"
      >
        <ChevronLeft className="w-5 h-5 mr-1 group-hover:-translate-x-1 transition-transform" />
        <span>Voltar ao carrinho</span>
      </button>

      <div className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-xl">
        <h1 className="text-3xl font-black text-gray-900 mb-2">Finalizar Compra</h1>
        <p className="text-gray-500 mb-8 text-sm">Preencha os seus dados para processar o pedido.</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <h3 className="font-bold text-gray-900 flex items-center">
              <User className="w-4 h-4 mr-2 text-primary" /> Dados Pessoais
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <input 
                type="text" 
                placeholder="Nome Completo" 
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-5 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-primary/20 transition-all"
              />
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input 
                  type="tel" 
                  placeholder="Telefone" 
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-primary/20 transition-all"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-gray-900 flex items-center">
              <MapPin className="w-4 h-4 mr-2 text-primary" /> Endereço de Entrega
            </h3>
            <textarea 
              placeholder="Endereço completo (Rua, Bairro, Ponto de Referência)" 
              required
              rows={3}
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full px-5 py-3 bg-gray-50 border-none rounded-2xl focus:ring-2 focus:ring-primary/20 transition-all resize-none"
            />
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-gray-900 flex items-center">
              <CreditCard className="w-4 h-4 mr-2 text-primary" /> Método de Pagamento
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(['Express', 'Transferência', 'Em queche'] as const).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setFormData({ ...formData, paymentType: type })}
                  className={`px-4 py-3 rounded-2xl text-sm font-bold border-2 transition-all ${
                    formData.paymentType === type 
                      ? 'border-primary bg-primary/5 text-primary' 
                      : 'border-gray-50 bg-gray-50 text-gray-500 hover:border-gray-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          {/* Payment Policy */}
          <div className="bg-primary/5 p-6 rounded-2xl border border-primary/10 space-y-3">
            <div className="flex items-center text-primary font-bold">
              <ShieldCheck className="w-5 h-5 mr-2" />
              Política de Segurança e Pagamento
            </div>
            <p className="text-sm text-gray-600 leading-relaxed">
              Para a sua segurança, o pagamento só será processado e confirmado quando você 
              <span className="font-bold text-gray-900"> confirmar que recebeu o produto em mãos</span>. 
              Garantimos que o seu dinheiro está protegido até à entrega final.
            </p>
          </div>

          <button 
            type="submit"
            className="w-full gradient-primary text-white py-4 rounded-2xl font-black text-lg shadow-xl shadow-primary/20 hover:scale-[1.02] transition-all flex items-center justify-center"
          >
            Confirmar Pedido <ArrowRight className="ml-2 w-5 h-5" />
          </button>
        </form>
      </div>
    </div>
  );
}
