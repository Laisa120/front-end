import { Star, ShoppingCart, MessageCircle, ShieldCheck, Truck, RefreshCw, ChevronLeft } from 'lucide-react';
import { Product, Supplier, View } from '../types';
import { SUPPLIERS } from '../mockData';

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
  addToCart: (product: Product) => void;
  setView: (view: View) => void;
  setSelectedSupplier: (supplier: Supplier) => void;
}

export default function ProductDetail({ product, onBack, addToCart, setView, setSelectedSupplier }: ProductDetailProps) {
  const supplier = SUPPLIERS.find(s => s.id === product.supplierId) || SUPPLIERS[0];

  const handleContactSupplier = () => {
    setView('messages');
  };

  const handleViewProfile = () => {
    setSelectedSupplier(supplier);
    setView('supplierProfile');
  };

  return (
    <div className="py-8">
      <button 
        onClick={onBack}
        className="flex items-center text-gray-500 hover:text-primary mb-8 transition-colors group"
      >
        <ChevronLeft className="w-5 h-5 mr-1 group-hover:-translate-x-1 transition-transform" />
        <span>Voltar para a listagem</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-square rounded-2xl overflow-hidden bg-white shadow-sm border border-gray-100">
            <img 
              src={product.image} 
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => {
              const keywords = product.category.toLowerCase() === 'smartphones' ? 'iphone' : 
                              product.category.toLowerCase() === 'laptops' ? 'macbook' :
                              product.category.toLowerCase() === 'tablets' ? 'ipad' : 'electronics';
              return (
                <div key={i} className={`aspect-square rounded-xl overflow-hidden cursor-pointer border-2 ${i === 0 ? 'border-primary' : 'border-transparent hover:border-gray-200'}`}>
                  <img 
                    src={`https://images.unsplash.com/photo-${[
                      '1511707171634-5f897ff02aa9',
                      '1512941937669-90a1b58e7e9c',
                      '1591337676887-a217a6970c8a',
                      '1556656793-062ff9f1b74b'
                    ][i]}?q=80&w=200&auto=format&fit=crop`} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <span className={`text-xs font-bold px-3 py-1 rounded-full uppercase ${
                product.condition === 'Novo' ? 'bg-green-100 text-green-700' :
                product.condition === 'Semi-novo' ? 'bg-blue-100 text-blue-700' :
                'bg-orange-100 text-orange-700'
              }`}>
                {product.condition}
              </span>
              <span className="text-gray-400 text-sm">• {product.category}</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{product.name}</h1>
            
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-current" />
                ))}
              </div>
              <span className="text-sm text-gray-500 font-medium">4.9 (128 avaliações)</span>
            </div>

            <div className="text-3xl font-bold text-primary mb-6">
              {product.price.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }).replace('AOA', 'Kz')}
            </div>

            <p className="text-gray-600 leading-relaxed">
              {product.description}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => addToCart(product)}
              className="flex-1 bg-primary text-white py-4 rounded-xl font-bold hover:bg-opacity-90 transition-all flex items-center justify-center shadow-lg shadow-primary/20"
            >
              <ShoppingCart className="w-5 h-5 mr-2" /> Adicionar ao Carrinho
            </button>
            <button 
              onClick={handleContactSupplier}
              className="flex-1 bg-surface text-primary py-4 rounded-xl font-bold hover:bg-gray-200 transition-all flex items-center justify-center"
            >
              <MessageCircle className="w-5 h-5 mr-2" /> Contactar Fornecedor
            </button>
          </div>

          {/* Supplier Info */}
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
            <h3 className="font-bold text-gray-900 mb-4">Informação do Fornecedor</h3>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <img src={supplier.photo} className="w-12 h-12 rounded-full object-cover" referrerPolicy="no-referrer" />
                <div>
                  <h4 className="font-bold text-gray-900">{supplier.name}</h4>
                  <div className="flex items-center text-xs text-gray-500">
                    <Star className="w-3 h-3 text-yellow-400 fill-current mr-1" />
                    <span>{supplier.rating} • {supplier.isB2C ? 'Loja Oficial' : 'Vendedor Particular'}</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={handleViewProfile}
                className="text-primary font-bold text-sm hover:underline"
              >
                Ver Perfil
              </button>
            </div>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-gray-100">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-50 text-green-600 rounded-full flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-gray-900">Compra Segura</p>
                <p className="text-gray-500">Garantia Central Apple</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center">
                <Truck className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-gray-900">Entrega Rápida</p>
                <p className="text-gray-500">Em todo o país</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-purple-50 text-purple-600 rounded-full flex items-center justify-center">
                <RefreshCw className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-bold text-gray-900">Devolução</p>
                <p className="text-gray-500">Até 7 dias grátis</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
