import React from 'react';
import { Settings as SettingsIcon, Bell, Shield, Globe, CreditCard, HelpCircle, ChevronRight, User, LogOut, ArrowLeft } from 'lucide-react';
import { View } from '../types';

interface SettingsProps {
  setView: (view: View) => void;
}

export default function Settings({ setView }: SettingsProps) {
  const sections = [
    { 
      title: 'Conta', 
      items: [
        { icon: <User className="w-5 h-5" />, label: 'Informações Pessoais', desc: 'Nome, email, telefone' },
        { icon: <Shield className="w-5 h-5" />, label: 'Segurança', desc: 'Palavra-passe, autenticação 2FA' },
        { icon: <CreditCard className="w-5 h-5" />, label: 'Pagamentos', desc: 'Métodos de pagamento, faturas' },
      ]
    },
    { 
      title: 'Preferências', 
      items: [
        { icon: <Bell className="w-5 h-5" />, label: 'Notificações', desc: 'Sons, alertas, email' },
        { icon: <Globe className="w-5 h-5" />, label: 'Idioma e Região', desc: 'Português (Angola)' },
      ]
    },
    { 
      title: 'Suporte', 
      items: [
        { icon: <HelpCircle className="w-5 h-5" />, label: 'Centro de Ajuda', desc: 'Perguntas frequentes, contacto' },
        { icon: <Shield className="w-5 h-5" />, label: 'Privacidade', desc: 'Termos e condições' },
      ]
    }
  ];

  return (
    <div className="py-12 max-w-3xl mx-auto">
      <button 
        onClick={() => setView('listing')}
        className="flex items-center text-gray-500 hover:text-primary mb-8 transition-colors group"
      >
        <ArrowLeft className="w-5 h-5 mr-1 group-hover:-translate-x-1 transition-transform" />
        <span>Voltar à Loja</span>
      </button>

      <div className="flex items-center space-x-4 mb-12">
        <div className="w-16 h-16 gradient-primary text-white rounded-2xl flex items-center justify-center shadow-xl shadow-primary/20">
          <SettingsIcon className="w-8 h-8" />
        </div>
        <div>
          <h1 className="text-4xl font-black text-gray-900">Definições</h1>
          <p className="text-gray-500">Gere a tua conta e preferências do sistema.</p>
        </div>
      </div>

      <div className="space-y-8">
        {sections.map((section, idx) => (
          <div key={idx} className="space-y-4">
            <h2 className="text-sm font-black text-gray-400 uppercase tracking-widest ml-4">{section.title}</h2>
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
              {section.items.map((item, i) => (
                <button 
                  key={i}
                  className={`w-full flex items-center justify-between p-6 hover:bg-surface transition-colors ${i !== section.items.length - 1 ? 'border-b border-gray-50' : ''}`}
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-10 h-10 bg-surface text-primary rounded-xl flex items-center justify-center">
                      {item.icon}
                    </div>
                    <div className="text-left">
                      <p className="font-bold text-gray-900 text-sm">{item.label}</p>
                      <p className="text-xs text-gray-400">{item.desc}</p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-300" />
                </button>
              ))}
            </div>
          </div>
        ))}

        <button className="w-full flex items-center justify-center space-x-3 p-6 bg-red-50 text-red-500 rounded-3xl font-bold hover:bg-red-100 transition-all">
          <LogOut className="w-5 h-5" />
          <span>Terminar Sessão</span>
        </button>
      </div>
    </div>
  );
}
