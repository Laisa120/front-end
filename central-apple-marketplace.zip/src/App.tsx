import { useState, useEffect } from 'react';
import { Product, CartItem, View, Supplier, CheckoutData, OrderNotification } from './types';
import { MOCK_PRODUCTS, SUPPLIERS } from './mockData';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ProductListing from './components/ProductListing';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import SupplierDashboard from './components/SupplierDashboard';
import Auth from './components/Auth';
import Landing from './components/Landing';
import Messages from './components/Messages';
import Settings from './components/Settings';
import SupplierProfile from './components/SupplierProfile';
import Checkout from './components/Checkout';
import OrderConfirmation from './components/OrderConfirmation';
import Profile from './components/Profile';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [suppliers, setSuppliers] = useState<Supplier[]>(SUPPLIERS);
  const [view, setView] = useState<View>('landing');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedSupplier, setSelectedSupplier] = useState<Supplier | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [checkoutData, setCheckoutData] = useState<CheckoutData | null>(null);
  const [notifications, setNotifications] = useState<OrderNotification[]>([]);

  // Scroll to top on view change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [view, selectedProduct]);

  const handleAuthSuccess = (isSupplierAccount: boolean) => {
    if (isSupplierAccount) {
      setView('dashboard');
    } else {
      setView('listing');
    }
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    // Optional: show a toast or notification
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const removeItem = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const handleCheckoutSubmit = (data: CheckoutData) => {
    setCheckoutData(data);
    
    // Create notifications for suppliers
    const supplierIds = Array.from(new Set(cart.map(item => item.supplierId))) as string[];
    
    const newNotifications: OrderNotification[] = supplierIds.map(sId => ({
      id: Math.random().toString(36).substr(2, 9),
      supplierId: sId,
      customerName: data.name,
      customerPhone: data.phone,
      customerAddress: data.address,
      paymentType: data.paymentType,
      items: cart
        .filter(item => item.supplierId === sId)
        .map(item => ({ name: item.name, quantity: item.quantity })),
      total: cart
        .filter(item => item.supplierId === sId)
        .reduce((acc, item) => acc + item.price * item.quantity, 0),
      createdAt: new Date().toISOString(),
      isRead: false
    }));

    setNotifications(prev => [...newNotifications, ...prev]);
    setCart([]); // Clear cart when order is placed
    setView('orderConfirmation');
  };

  const handleOrderFinish = () => {
    setCheckoutData(null);
    setView('listing');
  };

  const cartTotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0) + (cart.length > 0 ? 2500 : 0);

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setView('detail');
  };

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-surface">
      {view !== 'landing' && <Navbar setView={setView} cartCount={cartCount} />}
      
      <main className={`flex-grow ${view === 'landing' ? '' : 'max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full'}`}>
        <AnimatePresence mode="wait">
          <motion.div
            key={view + (selectedProduct?.id || '')}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {view === 'landing' && (
              <Landing setView={setView} />
            )}
            
            {view === 'listing' && (
              <ProductListing 
                products={products} 
                setSelectedProduct={handleProductClick}
                addToCart={addToCart}
              />
            )}
            
            {view === 'detail' && selectedProduct && (
              <ProductDetail 
                product={selectedProduct} 
                onBack={() => setView('listing')}
                addToCart={addToCart}
                setView={setView}
                setSelectedSupplier={setSelectedSupplier}
              />
            )}

            {view === 'supplierProfile' && selectedSupplier && (
              <SupplierProfile 
                supplier={selectedSupplier}
                onBack={() => setView('detail')}
                products={products.filter(p => p.supplierId === selectedSupplier.id)}
              />
            )}
            
            {view === 'cart' && (
              <Cart 
                items={cart} 
                updateQuantity={updateQuantity} 
                removeItem={removeItem}
                setView={setView}
              />
            )}

            {view === 'checkout' && (
              <Checkout 
                onBack={() => setView('cart')}
                onSubmit={handleCheckoutSubmit}
              />
            )}

            {view === 'orderConfirmation' && checkoutData && (
              <OrderConfirmation 
                data={checkoutData}
                total={cartTotal}
                onFinish={handleOrderFinish}
                setView={setView}
              />
            )}
            
            {view === 'dashboard' && (
              <SupplierDashboard 
                products={products} 
                setProducts={setProducts}
                setView={setView}
                notifications={notifications}
                setNotifications={setNotifications}
              />
            )}
            
            {view === 'messages' && (
              <Messages setView={setView} />
            )}

            {view === 'settings' && (
              <Settings setView={setView} />
            )}

            {view === 'profile' && (
              <Profile setView={setView} />
            )}
            
            {view === 'auth' && (
              <Auth 
                setView={setView} 
                onAuthSuccess={handleAuthSuccess}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {view !== 'landing' && <Footer />}
    </div>
  );
}
