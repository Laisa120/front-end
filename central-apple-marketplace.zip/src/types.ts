export type ProductCondition = 'Novo' | 'Semi-novo' | 'Usado';

export interface Supplier {
  id: string;
  name: string;
  photo: string;
  rating: number;
  isB2C: boolean;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  condition: ProductCondition;
  image: string;
  description: string;
  supplierId: string;
  featured?: boolean;
  bestSeller?: boolean;
  createdAt: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface CheckoutData {
  name: string;
  address: string;
  phone: string;
  paymentType: 'Express' | 'Transferência' | 'Em queche';
}

export interface OrderNotification {
  id: string;
  supplierId: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  paymentType: string;
  items: { name: string; quantity: number }[];
  total: number;
  createdAt: string;
  isRead: boolean;
}

export type View = 'landing' | 'listing' | 'detail' | 'cart' | 'dashboard' | 'auth' | 'profile' | 'messages' | 'settings' | 'supplierProfile' | 'checkout' | 'orderConfirmation';
