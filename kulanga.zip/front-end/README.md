# Website institucional — front-end

Website responsivo de front-end, feito em HTML, CSS e JavaScript sem dependências de compilação. O nome, a actividade, os serviços, a história, os contactos e os projectos reais da empresa não foram fornecidos; os textos e projectos assinalados como ilustrativos devem ser substituídos antes da publicação.

## Pré-visualização

Abra `index.html` num navegador ou sirva a pasta com qualquer servidor de ficheiros estáticos. Por exemplo, com Python instalado:

```sh
python -m http.server 8000
```

Depois, visite `http://localhost:8000`. As imagens de demonstração e os tipos de letra são carregados de serviços externos (Unsplash e Google Fonts).

Para abrir a interface de gestão local, visite `http://localhost:8000/admin.html`. As páginas têm de ser servidas na mesma origem para partilharem o `localStorage`.

## O que funciona no front-end

- Navegação por secções, menu móvel e disposição adaptável.
- Filtros de categoria, detalhe de projecto, partilha nativa e cópia da ligação quando suportadas pelo navegador.
- Formulário com validação local. **Não envia nem guarda mensagens**: é necessário integrar um serviço de formulários ou uma API antes de receber pedidos.
- Página de gestão separada em `admin.html` para editar projectos, categorias, serviços, vídeos promocionais, textos, contactos, redes sociais, nome, logótipo, slides do banner, degradés e cor de destaque. Permite carregar fotografias comprimidas no navegador, organizar a galeria e destacar até três projectos.
- O painel front-end escreve em `localStorage`; a página pública lê os mesmos dados e actualiza-se entre separadores da mesma origem e perfil de navegador. Não sincroniza entre dispositivos, utilizadores nem navegadores.
- Para adicionar um projecto, crie primeiro uma categoria, abra **Projectos → Novo projecto**, preencha os dados e escolha uma imagem por URL ou carregue fotografias. Pode ordenar/remover imagens, seleccionar até três destaques e guardar; para serviços e textos, use as respectivas secções do painel.
- Em **Conteúdo e contactos → Marca visual**, altere o nome, indique ou carregue um logótipo e adicione até cinco slides ao carrossel do banner. Cada slide tem título, apresentação e imagem; pode reordenar, remover e pré-visualizar slides. O banner avança automaticamente, permite pausar/retomar e inclui controlos manuais.
- Na secção **Degradés dos fundos**, escolha duas cores e a direcção do degradé aplicado aos fundos das secções claras do website. A pré-visualização aparece no painel antes de guardar.
- Em **Vídeos**, carregue do dispositivo ficheiros MP4, WebM ou Ogg até 100 MB, ou adicione uma ligação do YouTube ou Vimeo. Os ficheiros carregados são guardados no IndexedDB do navegador e os metadados no `localStorage`; o carrossel de publicidade aparece no início da página pública, logo após o banner, e mostra controlos quando há vários anúncios. É necessário carregar novamente os ficheiros noutro dispositivo ou perfil de navegador.
- Carregamentos de imagem são convertidos para WebP no navegador, limitados a 500 KB e guardados localmente.
- A cor principal pode ser extraída de um logótipo carregado ou escolhida manualmente. Ela define tons coordenados para realces, botões, fundos e cartões do website e do painel. Em **Títulos, subtítulos e chamadas**, edite os títulos de secção, subtítulos, botões e textos institucionais; os campos de identidade e serviços editam também os parágrafos correspondentes.

## Configuração antes da publicação

1. Substitua “A sua empresa”, a descrição, os serviços, as imagens ilustrativas e os restantes campos pela identidade e informação confirmadas da empresa. Use apenas imagens autorizadas e testemunhos reais fornecidos.
2. Configure os contactos oficiais e adicione o número de WhatsApp internacional (apenas algarismos, incluindo indicativo do país) ao botão flutuante.
3. Ligue o formulário a um endpoint/API ou fornecedor de formulários. Valide e proteja também os envios no servidor; não coloque segredos no JavaScript público.
4. Substitua os dados de demonstração pelo portfólio autorizado. Para actualização de conteúdo partilhada por vários utilizadores, adicione uma API, armazenamento e autenticação no servidor.
5. Actualize título, descrição, imagem social e domínio. Adicione sitemap XML, robots.txt, páginas individuais de projecto e metadados por página quando o conteúdo real e o alojamento estiverem definidos.
6. Publique os ficheiros estáticos num alojamento HTTPS. Aponte o domínio para o alojamento escolhido e configure DNS/TLS segundo as instruções do fornecedor.
7. Teste o formulário integrado, ligações de contacto, navegação e layout em telemóveis, tablets e computadores antes de divulgar o endereço.

## Limites desta entrega

Este projecto é exclusivamente front-end. `admin.html` **não tem autenticação nem controlo de acesso**; não aponte um domínio público para esta página nem guarde conteúdo confidencial. `noindex` e a ausência de uma ligação no website público não protegem a página. Um painel seguro exige autenticação e autorização no servidor, API protegida, armazenamento persistente de ficheiros e controlo de acesso à rota. O painel local não recebe pedidos de formulários e não inclui base de dados, backend, mapa, sitemap ou serviço de envio de e-mail.
