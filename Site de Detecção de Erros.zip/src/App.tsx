import { useState } from 'react';
import { ServerMonitor } from './components/ServerMonitor';
import { ServerList } from './components/ServerList';
import { ErrorLogs } from './components/ErrorLogs';
import { AlertNotification } from './components/AlertNotification';
import { Activity, Server, AlertTriangle } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'servers' | 'logs'>('dashboard');

  return (
    <div className="min-h-screen bg-black">
      {/* Alert Notifications */}
      <AlertNotification />
      
      {/* Header */}
      <header className="bg-zinc-900 border-b border-zinc-800 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-yellow-500 p-2 rounded-lg">
                <Activity className="w-6 h-6 text-black" />
              </div>
              <div>
                <h1 className="text-white">Monitor de Servidores</h1>
                <p className="text-zinc-400 text-sm">Detecção de erros em tempo real</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse"></div>
              <span className="text-zinc-300 text-sm">Sistema Ativo</span>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-zinc-900/50 border-b border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-6 py-3 transition-colors ${
                activeTab === 'dashboard'
                  ? 'bg-zinc-800 text-white border-b-2 border-yellow-500'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setActiveTab('servers')}
              className={`px-6 py-3 transition-colors ${
                activeTab === 'servers'
                  ? 'bg-zinc-800 text-white border-b-2 border-yellow-500'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
              }`}
            >
              Servidores
            </button>
            <button
              onClick={() => setActiveTab('logs')}
              className={`px-6 py-3 transition-colors ${
                activeTab === 'logs'
                  ? 'bg-zinc-800 text-white border-b-2 border-yellow-500'
                  : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
              }`}
            >
              Logs de Erro
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && <ServerMonitor />}
        {activeTab === 'servers' && <ServerList />}
        {activeTab === 'logs' && <ErrorLogs />}
      </main>
    </div>
  );
}