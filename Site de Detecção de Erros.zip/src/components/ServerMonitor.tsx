import { Server, AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const mockData = [
  { time: '00:00', uptime: 98, errors: 2 },
  { time: '04:00', uptime: 99, errors: 1 },
  { time: '08:00', uptime: 97, errors: 5 },
  { time: '12:00', uptime: 100, errors: 0 },
  { time: '16:00', uptime: 99, errors: 2 },
  { time: '20:00', uptime: 98, errors: 3 },
  { time: '23:59', uptime: 100, errors: 0 },
];

export function ServerMonitor() {
  const stats = {
    totalServers: 12,
    onlineServers: 10,
    offlineServers: 1,
    warningServers: 1,
    totalErrors: 23,
    avgResponseTime: 145,
  };

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Servers */}
        <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-zinc-400 text-sm">Total de Servidores</p>
              <p className="text-white text-3xl mt-2">{stats.totalServers}</p>
            </div>
            <div className="bg-yellow-500/20 p-3 rounded-lg">
              <Server className="w-6 h-6 text-yellow-400" />
            </div>
          </div>
        </div>

        {/* Online Servers */}
        <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-zinc-400 text-sm">Servidores Online</p>
              <p className="text-white text-3xl mt-2">{stats.onlineServers}</p>
            </div>
            <div className="bg-yellow-500/20 p-3 rounded-lg">
              <CheckCircle className="w-6 h-6 text-yellow-400" />
            </div>
          </div>
          <div className="mt-3 flex items-center gap-2">
            <div className="flex-1 bg-zinc-800 rounded-full h-2">
              <div
                className="bg-yellow-500 h-2 rounded-full"
                style={{ width: `${(stats.onlineServers / stats.totalServers) * 100}%` }}
              ></div>
            </div>
            <span className="text-yellow-400 text-sm">
              {Math.round((stats.onlineServers / stats.totalServers) * 100)}%
            </span>
          </div>
        </div>

        {/* Errors */}
        <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-zinc-400 text-sm">Erros (24h)</p>
              <p className="text-white text-3xl mt-2">{stats.totalErrors}</p>
            </div>
            <div className="bg-zinc-800 p-3 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
          </div>
          <p className="text-zinc-400 text-sm mt-3">+5 desde a última hora</p>
        </div>

        {/* Response Time */}
        <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-zinc-400 text-sm">Tempo Médio de Resposta</p>
              <p className="text-white text-3xl mt-2">{stats.avgResponseTime}ms</p>
            </div>
            <div className="bg-yellow-500/20 p-3 rounded-lg">
              <Clock className="w-6 h-6 text-yellow-400" />
            </div>
          </div>
          <p className="text-yellow-400 text-sm mt-3">↓ 12ms desde ontem</p>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-6">
        <h2 className="text-white mb-6">Uptime nas Últimas 24 Horas</h2>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={mockData}>
            <defs>
              <linearGradient id="colorUptime" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#eab308" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#eab308" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
            <XAxis dataKey="time" stroke="#a1a1aa" />
            <YAxis stroke="#a1a1aa" domain={[0, 100]} />
            <Tooltip
              contentStyle={{
                backgroundColor: '#18181b',
                border: '1px solid #3f3f46',
                borderRadius: '8px',
                color: '#fff',
              }}
            />
            <Area
              type="monotone"
              dataKey="uptime"
              stroke="#eab308"
              strokeWidth={2}
              fill="url(#colorUptime)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Quick Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <CheckCircle className="w-5 h-5 text-yellow-400" />
            <h3 className="text-white">Status Normal</h3>
          </div>
          <p className="text-3xl text-yellow-400">{stats.onlineServers}</p>
          <p className="text-zinc-400 text-sm mt-2">servidores operacionais</p>
        </div>

        <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <AlertTriangle className="w-5 h-5 text-zinc-400" />
            <h3 className="text-white">Avisos</h3>
          </div>
          <p className="text-3xl text-zinc-300">{stats.warningServers}</p>
          <p className="text-zinc-400 text-sm mt-2">com alta latência</p>
        </div>

        <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <XCircle className="w-5 h-5 text-white" />
            <h3 className="text-white">Offline</h3>
          </div>
          <p className="text-3xl text-white">{stats.offlineServers}</p>
          <p className="text-zinc-400 text-sm mt-2">servidor não responde</p>
        </div>
      </div>
    </div>
  );
}