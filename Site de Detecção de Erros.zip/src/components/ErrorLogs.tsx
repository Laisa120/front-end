import { useState } from 'react';
import { AlertTriangle, XCircle, AlertCircle, Clock, Server, Search } from 'lucide-react';

interface ErrorLog {
  id: string;
  timestamp: string;
  server: string;
  severity: 'critical' | 'error' | 'warning';
  message: string;
  details: string;
}

const mockLogs: ErrorLog[] = [
  {
    id: '1',
    timestamp: '2025-12-15 14:23:45',
    server: 'File Server',
    severity: 'critical',
    message: 'Servidor não está respondendo',
    details: 'Connection timeout after 30 seconds. Host: 192.168.1.50',
  },
  {
    id: '2',
    timestamp: '2025-12-15 14:18:32',
    server: 'API Server 01',
    severity: 'warning',
    message: 'Alta utilização de CPU detectada',
    details: 'CPU usage reached 88%. Threshold: 80%',
  },
  {
    id: '3',
    timestamp: '2025-12-15 14:15:12',
    server: 'Database Server',
    severity: 'error',
    message: 'Falha na conexão com o banco de dados',
    details: 'Connection pool exhausted. Max connections: 100',
  },
  {
    id: '4',
    timestamp: '2025-12-15 14:10:55',
    server: 'Web Server 01',
    severity: 'warning',
    message: 'Tempo de resposta elevado',
    details: 'Average response time: 320ms. Expected: <200ms',
  },
  {
    id: '5',
    timestamp: '2025-12-15 14:05:22',
    server: 'Mail Server',
    severity: 'error',
    message: 'Falha no envio de e-mail',
    details: 'SMTP connection refused. Port 587 blocked',
  },
  {
    id: '6',
    timestamp: '2025-12-15 13:58:17',
    server: 'API Server 01',
    severity: 'critical',
    message: 'Erro 500 - Internal Server Error',
    details: 'Exception in /api/users endpoint. Stack trace logged',
  },
  {
    id: '7',
    timestamp: '2025-12-15 13:45:09',
    server: 'Cache Server',
    severity: 'warning',
    message: 'Cache miss rate elevada',
    details: 'Cache miss rate: 45%. Expected: <20%',
  },
  {
    id: '8',
    timestamp: '2025-12-15 13:32:44',
    server: 'Web Server 02',
    severity: 'error',
    message: 'Disco quase cheio',
    details: 'Disk usage: 95%. Free space: 2.5GB',
  },
  {
    id: '9',
    timestamp: '2025-12-15 13:20:31',
    server: 'Database Server',
    severity: 'warning',
    message: 'Query lenta detectada',
    details: 'Query execution time: 5.2s. Table: users',
  },
  {
    id: '10',
    timestamp: '2025-12-15 13:10:18',
    server: 'File Server',
    severity: 'critical',
    message: 'Serviço reiniciado inesperadamente',
    details: 'Service crash detected. Exit code: 1',
  },
];

export function ErrorLogs() {
  const [logs] = useState<ErrorLog[]>(mockLogs);
  const [filter, setFilter] = useState<'all' | 'critical' | 'error' | 'warning'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = logs.filter((log) => {
    const matchesFilter = filter === 'all' || log.severity === filter;
    const matchesSearch =
      searchTerm === '' ||
      log.server.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.message.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <XCircle className="w-5 h-5 text-white" />;
      case 'error':
        return <AlertTriangle className="w-5 h-5 text-zinc-300" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-yellow-400" />;
      default:
        return null;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'border-white/30 bg-white/5';
      case 'error':
        return 'border-zinc-600 bg-zinc-800/50';
      case 'warning':
        return 'border-yellow-500/50 bg-yellow-500/5';
      default:
        return 'border-zinc-800';
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-white/20 text-white border-white/30';
      case 'error':
        return 'bg-zinc-700 text-zinc-300 border-zinc-600';
      case 'warning':
        return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      default:
        return 'bg-zinc-800 text-zinc-300 border-zinc-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-4">
          <p className="text-zinc-400 text-sm">Total de Erros</p>
          <p className="text-white text-2xl mt-1">{logs.length}</p>
        </div>
        <div className="bg-white/10 border border-white/30 rounded-xl p-4">
          <p className="text-white text-sm">Críticos</p>
          <p className="text-white text-2xl mt-1">{logs.filter((l) => l.severity === 'critical').length}</p>
        </div>
        <div className="bg-zinc-800 border border-zinc-600 rounded-xl p-4">
          <p className="text-zinc-300 text-sm">Erros</p>
          <p className="text-zinc-300 text-2xl mt-1">{logs.filter((l) => l.severity === 'error').length}</p>
        </div>
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4">
          <p className="text-yellow-300 text-sm">Avisos</p>
          <p className="text-yellow-400 text-2xl mt-1">{logs.filter((l) => l.severity === 'warning').length}</p>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filter === 'all'
                ? 'bg-yellow-500 text-black'
                : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
            }`}
          >
            Todos
          </button>
          <button
            onClick={() => setFilter('critical')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filter === 'critical'
                ? 'bg-white text-black'
                : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
            }`}
          >
            Críticos
          </button>
          <button
            onClick={() => setFilter('error')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filter === 'error'
                ? 'bg-zinc-300 text-black'
                : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
            }`}
          >
            Erros
          </button>
          <button
            onClick={() => setFilter('warning')}
            className={`px-4 py-2 rounded-lg transition-colors ${
              filter === 'warning'
                ? 'bg-yellow-500 text-black'
                : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
            }`}
          >
            Avisos
          </button>
        </div>

        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400" />
          <input
            type="text"
            placeholder="Buscar por servidor ou mensagem..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-10 pr-4 py-2 text-white placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />
        </div>
      </div>

      {/* Logs List */}
      <div className="space-y-3">
        {filteredLogs.length === 0 ? (
          <div className="bg-zinc-900 backdrop-blur-sm border border-zinc-800 rounded-xl p-8 text-center">
            <p className="text-zinc-400">Nenhum log encontrado</p>
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className={`bg-zinc-900 backdrop-blur-sm border rounded-xl p-5 transition-all hover:shadow-lg ${getSeverityColor(
                log.severity
              )}`}
            >
              <div className="flex items-start gap-4">
                <div className="mt-1">{getSeverityIcon(log.severity)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4 mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span
                          className={`px-3 py-1 rounded-full border text-xs uppercase ${getSeverityBadge(
                            log.severity
                          )}`}
                        >
                          {log.severity}
                        </span>
                        <div className="flex items-center gap-2 text-zinc-400">
                          <Server className="w-4 h-4" />
                          <span className="text-sm">{log.server}</span>
                        </div>
                      </div>
                      <h3 className="text-white mb-2">{log.message}</h3>
                      <p className="text-zinc-400 text-sm">{log.details}</p>
                    </div>
                    <div className="flex items-center gap-2 text-zinc-400 text-sm whitespace-nowrap">
                      <Clock className="w-4 h-4" />
                      <span>{log.timestamp}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}