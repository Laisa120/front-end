import { useState, useEffect } from 'react';
import { Server, CheckCircle, XCircle, AlertTriangle, Globe, Cpu, HardDrive, Activity, ChevronDown, ChevronUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface ServerData {
  id: string;
  name: string;
  ip: string;
  status: 'online' | 'offline' | 'warning';
  uptime: number;
  cpu: number;
  memory: number;
  disk: number;
  responseTime: number;
  lastCheck: string;
  history: {
    time: string;
    cpu: number;
    memory: number;
    responseTime: number;
  }[];
}

// Generate initial history data for each server
const generateHistory = (baseValues: { cpu: number; memory: number; responseTime: number }) => {
  const history = [];
  const times = ['5m', '4m', '3m', '2m', '1m', 'Agora'];
  
  for (let i = 0; i < times.length; i++) {
    history.push({
      time: times[i],
      cpu: Math.max(10, Math.min(95, baseValues.cpu + (Math.random() - 0.5) * 20)),
      memory: Math.max(10, Math.min(95, baseValues.memory + (Math.random() - 0.5) * 15)),
      responseTime: Math.max(40, Math.min(400, baseValues.responseTime + (Math.random() - 0.5) * 50)),
    });
  }
  
  return history;
};

const mockServers: ServerData[] = [
  {
    id: '1',
    name: 'Web Server 01',
    ip: '192.168.1.10',
    status: 'online',
    uptime: 99.9,
    cpu: 45,
    memory: 62,
    disk: 78,
    responseTime: 120,
    lastCheck: 'Agora',
    history: generateHistory({ cpu: 45, memory: 62, responseTime: 120 }),
  },
  {
    id: '2',
    name: 'Database Server',
    ip: '192.168.1.20',
    status: 'online',
    uptime: 99.8,
    cpu: 72,
    memory: 85,
    disk: 65,
    responseTime: 95,
    lastCheck: 'Agora',
    history: generateHistory({ cpu: 72, memory: 85, responseTime: 95 }),
  },
  {
    id: '3',
    name: 'API Server 01',
    ip: '192.168.1.30',
    status: 'warning',
    uptime: 98.5,
    cpu: 88,
    memory: 91,
    disk: 45,
    responseTime: 320,
    lastCheck: '1 min atrás',
    history: generateHistory({ cpu: 88, memory: 91, responseTime: 320 }),
  },
  {
    id: '4',
    name: 'Cache Server',
    ip: '192.168.1.40',
    status: 'online',
    uptime: 100,
    cpu: 25,
    memory: 48,
    disk: 32,
    responseTime: 45,
    lastCheck: 'Agora',
    history: generateHistory({ cpu: 25, memory: 48, responseTime: 45 }),
  },
  {
    id: '5',
    name: 'File Server',
    ip: '192.168.1.50',
    status: 'offline',
    uptime: 95.2,
    cpu: 0,
    memory: 0,
    disk: 0,
    responseTime: 0,
    lastCheck: '5 min atrás',
    history: generateHistory({ cpu: 0, memory: 0, responseTime: 0 }),
  },
  {
    id: '6',
    name: 'Mail Server',
    ip: '192.168.1.60',
    status: 'online',
    uptime: 99.7,
    cpu: 38,
    memory: 55,
    disk: 70,
    responseTime: 180,
    lastCheck: 'Agora',
    history: generateHistory({ cpu: 38, memory: 55, responseTime: 180 }),
  },
  {
    id: '7',
    name: 'Web Server 02',
    ip: '192.168.1.11',
    status: 'online',
    uptime: 99.6,
    cpu: 52,
    memory: 68,
    disk: 82,
    responseTime: 135,
    lastCheck: 'Agora',
    history: generateHistory({ cpu: 52, memory: 68, responseTime: 135 }),
  },
  {
    id: '8',
    name: 'Backup Server',
    ip: '192.168.1.70',
    status: 'online',
    uptime: 99.9,
    cpu: 15,
    memory: 32,
    disk: 95,
    responseTime: 210,
    lastCheck: 'Agora',
    history: generateHistory({ cpu: 15, memory: 32, responseTime: 210 }),
  },
];

export function ServerList() {
  const [servers, setServers] = useState<ServerData[]>(mockServers);
  const [filter, setFilter] = useState<'all' | 'online' | 'warning' | 'offline'>('all');
  const [expandedServer, setExpandedServer] = useState<string | null>(null);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setServers((prev) =>
        prev.map((server) => {
          const newCpu = server.status === 'offline' ? 0 : Math.max(10, Math.min(95, server.cpu + (Math.random() - 0.5) * 10));
          const newMemory = server.status === 'offline' ? 0 : Math.max(10, Math.min(95, server.memory + (Math.random() - 0.5) * 8));
          const newResponseTime = server.status === 'offline' ? 0 : Math.max(40, Math.min(400, server.responseTime + (Math.random() - 0.5) * 30));
          
          // Update history
          const newHistory = [...server.history.slice(1), {
            time: 'Agora',
            cpu: newCpu,
            memory: newMemory,
            responseTime: newResponseTime,
          }];
          
          return {
            ...server,
            cpu: newCpu,
            memory: newMemory,
            responseTime: newResponseTime,
            history: newHistory,
          };
        })
      );
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const filteredServers = servers.filter((server) => {
    if (filter === 'all') return true;
    return server.status === filter;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="w-5 h-5 text-yellow-400" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-zinc-300" />;
      case 'offline':
        return <XCircle className="w-5 h-5 text-white" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'border-yellow-500/50 bg-yellow-500/5';
      case 'warning':
        return 'border-zinc-600 bg-zinc-800/50';
      case 'offline':
        return 'border-zinc-700 bg-zinc-900';
      default:
        return 'border-zinc-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filter === 'all'
              ? 'bg-yellow-500 text-black'
              : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
          }`}
        >
          Todos ({servers.length})
        </button>
        <button
          onClick={() => setFilter('online')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filter === 'online'
              ? 'bg-yellow-500 text-black'
              : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
          }`}
        >
          Online ({servers.filter((s) => s.status === 'online').length})
        </button>
        <button
          onClick={() => setFilter('warning')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filter === 'warning'
              ? 'bg-zinc-300 text-black'
              : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
          }`}
        >
          Avisos ({servers.filter((s) => s.status === 'warning').length})
        </button>
        <button
          onClick={() => setFilter('offline')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filter === 'offline'
              ? 'bg-white text-black'
              : 'bg-zinc-900 text-zinc-300 hover:bg-zinc-800 border border-zinc-800'
          }`}
        >
          Offline ({servers.filter((s) => s.status === 'offline').length})
        </button>
      </div>

      {/* Server Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredServers.map((server) => (
          <div
            key={server.id}
            className={`bg-zinc-900 backdrop-blur-sm border rounded-xl p-6 transition-all hover:shadow-lg ${getStatusColor(
              server.status
            )}`}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-3">
                <div className="bg-zinc-800 p-2 rounded-lg">
                  <Server className="w-5 h-5 text-zinc-300" />
                </div>
                <div>
                  <h3 className="text-white">{server.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <Globe className="w-4 h-4 text-zinc-400" />
                    <span className="text-zinc-400 text-sm">{server.ip}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getStatusIcon(server.status)}
                <span className="text-zinc-300 text-sm capitalize">{server.status}</span>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Cpu className="w-4 h-4 text-zinc-400" />
                  <span className="text-zinc-400 text-sm">CPU</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-zinc-800 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        server.cpu > 80 ? 'bg-white' : server.cpu > 60 ? 'bg-zinc-300' : 'bg-yellow-500'
                      }`}
                      style={{ width: `${server.cpu}%` }}
                    ></div>
                  </div>
                  <span className="text-white text-sm w-10 text-right">{Math.round(server.cpu)}%</span>
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="w-4 h-4 text-zinc-400" />
                  <span className="text-zinc-400 text-sm">Memória</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-zinc-800 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        server.memory > 80 ? 'bg-white' : server.memory > 60 ? 'bg-zinc-300' : 'bg-yellow-500'
                      }`}
                      style={{ width: `${server.memory}%` }}
                    ></div>
                  </div>
                  <span className="text-white text-sm w-10 text-right">{Math.round(server.memory)}%</span>
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <HardDrive className="w-4 h-4 text-zinc-400" />
                  <span className="text-zinc-400 text-sm">Disco</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 bg-zinc-800 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        server.disk > 80 ? 'bg-white' : server.disk > 60 ? 'bg-zinc-300' : 'bg-yellow-500'
                      }`}
                      style={{ width: `${server.disk}%` }}
                    ></div>
                  </div>
                  <span className="text-white text-sm w-10 text-right">{server.disk}%</span>
                </div>
              </div>

              <div>
                <span className="text-zinc-400 text-sm">Tempo de Resposta</span>
                <p className="text-white text-xl mt-1">{Math.round(server.responseTime)}ms</p>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
              <div>
                <span className="text-zinc-400 text-sm">Uptime: </span>
                <span className="text-white text-sm">{server.uptime}%</span>
              </div>
              <span className="text-zinc-400 text-sm">{server.lastCheck}</span>
            </div>

            {/* Expandable Chart */}
            <div className="mt-4">
              <button
                onClick={() => setExpandedServer(server.id === expandedServer ? null : server.id)}
                className="flex items-center gap-2 text-zinc-300 hover:text-yellow-400 transition-colors text-sm"
              >
                {server.id === expandedServer ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                <span>Ver gráficos detalhados</span>
              </button>
              
              {server.id === expandedServer && (
                <div className="mt-4 space-y-6">
                  {/* CPU & Memory Chart */}
                  <div className="bg-black/30 rounded-lg p-4 border border-zinc-800">
                    <h4 className="text-white text-sm mb-3">CPU e Memória (%)</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <LineChart data={server.history}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                        <XAxis dataKey="time" stroke="#a1a1aa" style={{ fontSize: '12px' }} />
                        <YAxis stroke="#a1a1aa" style={{ fontSize: '12px' }} domain={[0, 100]} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#18181b',
                            border: '1px solid #3f3f46',
                            borderRadius: '8px',
                            color: '#fff',
                          }}
                        />
                        <Legend 
                          wrapperStyle={{ fontSize: '12px' }}
                          iconType="line"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="cpu" 
                          stroke="#eab308" 
                          strokeWidth={2}
                          name="CPU"
                          dot={{ fill: '#eab308', r: 3 }}
                          activeDot={{ r: 5 }} 
                        />
                        <Line 
                          type="monotone" 
                          dataKey="memory" 
                          stroke="#ffffff" 
                          strokeWidth={2}
                          name="Memória"
                          dot={{ fill: '#ffffff', r: 3 }}
                          activeDot={{ r: 5 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Response Time Chart */}
                  <div className="bg-black/30 rounded-lg p-4 border border-zinc-800">
                    <h4 className="text-white text-sm mb-3">Tempo de Resposta (ms)</h4>
                    <ResponsiveContainer width="100%" height={200}>
                      <LineChart data={server.history}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#3f3f46" />
                        <XAxis dataKey="time" stroke="#a1a1aa" style={{ fontSize: '12px' }} />
                        <YAxis stroke="#a1a1aa" style={{ fontSize: '12px' }} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#18181b',
                            border: '1px solid #3f3f46',
                            borderRadius: '8px',
                            color: '#fff',
                          }}
                        />
                        <Legend 
                          wrapperStyle={{ fontSize: '12px' }}
                          iconType="line"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="responseTime" 
                          stroke="#71717a" 
                          strokeWidth={2}
                          name="Tempo de Resposta"
                          dot={{ fill: '#71717a', r: 3 }}
                          activeDot={{ r: 5 }} 
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}