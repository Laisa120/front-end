import { useEffect, useState } from 'react';
import { X, AlertTriangle, XCircle, Bell } from 'lucide-react';

interface Alert {
  id: string;
  message: string;
  severity: 'critical' | 'warning';
  timestamp: number;
}

export function AlertNotification() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    // Simulate random alerts
    const interval = setInterval(() => {
      const shouldShowAlert = Math.random() > 0.85;
      if (shouldShowAlert) {
        const newAlert: Alert = {
          id: Date.now().toString(),
          message:
            Math.random() > 0.5
              ? 'API Server 01 está com alta latência'
              : 'File Server não está respondendo',
          severity: Math.random() > 0.5 ? 'critical' : 'warning',
          timestamp: Date.now(),
        };
        setAlerts((prev) => [newAlert, ...prev].slice(0, 5));
      }
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const removeAlert = (id: string) => {
    setAlerts((prev) => prev.filter((alert) => alert.id !== id));
  };

  const clearAll = () => {
    setAlerts([]);
  };

  return (
    <>
      {/* Notification Bell */}
      <div className="fixed top-4 right-4 z-50">
        <button
          onClick={() => setShowNotifications(!showNotifications)}
          className="relative bg-zinc-900 border border-zinc-800 p-3 rounded-full hover:bg-zinc-800 transition-colors"
        >
          <Bell className="w-6 h-6 text-white" />
          {alerts.length > 0 && (
            <span className="absolute -top-1 -right-1 bg-yellow-500 text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {alerts.length}
            </span>
          )}
        </button>
      </div>

      {/* Notifications Panel */}
      {showNotifications && (
        <div className="fixed top-20 right-4 w-96 max-h-[600px] bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl z-50 overflow-hidden">
          <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
            <h3 className="text-white">Notificações</h3>
            <div className="flex items-center gap-2">
              {alerts.length > 0 && (
                <button
                  onClick={clearAll}
                  className="text-zinc-400 hover:text-white text-sm transition-colors"
                >
                  Limpar tudo
                </button>
              )}
              <button
                onClick={() => setShowNotifications(false)}
                className="text-zinc-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="max-h-[500px] overflow-y-auto">
            {alerts.length === 0 ? (
              <div className="p-8 text-center">
                <Bell className="w-12 h-12 text-zinc-700 mx-auto mb-3" />
                <p className="text-zinc-400">Nenhuma notificação</p>
              </div>
            ) : (
              <div className="p-2 space-y-2">
                {alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`p-3 rounded-lg border ${
                      alert.severity === 'critical'
                        ? 'bg-white/10 border-white/30'
                        : 'bg-yellow-500/10 border-yellow-500/30'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {alert.severity === 'critical' ? (
                        <XCircle className="w-5 h-5 text-white flex-shrink-0 mt-0.5" />
                      ) : (
                        <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p
                          className={`text-sm ${
                            alert.severity === 'critical' ? 'text-white' : 'text-yellow-300'
                          }`}
                        >
                          {alert.message}
                        </p>
                        <p className="text-zinc-400 text-xs mt-1">
                          {new Date(alert.timestamp).toLocaleTimeString('pt-BR')}
                        </p>
                      </div>
                      <button
                        onClick={() => removeAlert(alert.id)}
                        className="text-zinc-400 hover:text-white transition-colors flex-shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Toast Notifications */}
      <div className="fixed bottom-4 right-4 z-50 space-y-2">
        {alerts.slice(0, 3).map((alert, index) => (
          <div
            key={alert.id}
            className={`bg-zinc-900 border rounded-lg p-4 shadow-lg animate-slide-in max-w-sm ${
              alert.severity === 'critical' ? 'border-white/50' : 'border-yellow-500/50'
            }`}
            style={{
              animation: `slideIn 0.3s ease-out ${index * 0.1}s forwards`,
              opacity: 0,
            }}
          >
            <div className="flex items-start gap-3">
              {alert.severity === 'critical' ? (
                <XCircle className="w-5 h-5 text-white flex-shrink-0" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-yellow-400 flex-shrink-0" />
              )}
              <div className="flex-1">
                <p
                  className={`text-sm ${alert.severity === 'critical' ? 'text-white' : 'text-yellow-300'}`}
                >
                  {alert.message}
                </p>
              </div>
              <button
                onClick={() => removeAlert(alert.id)}
                className="text-zinc-400 hover:text-white transition-colors flex-shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @keyframes slideIn {
          from {
            transform: translateX(400px);
            opacity: 0;
          }
          to {
            transform: translateX(0);
            opacity: 1;
          }
        }
      `}</style>
    </>
  );
}