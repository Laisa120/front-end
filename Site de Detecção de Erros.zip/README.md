
  # Site de Detecção de Erros

  This is a code bundle for Site de Detecção de Erros. The original project is available at https://www.figma.com/design/B8M2YTyGCSPWPplxHLLd1R/Site-de-Detec%C3%A7%C3%A3o-de-Erros.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  