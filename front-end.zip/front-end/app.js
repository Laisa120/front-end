(() => {
  "use strict";

  const contentKey = "empresa-site-content-v1";
  const legacyKey = "empresa-portfolio-preview-v1";
  const demoProjects = [
    { id: "demo-01", title: "Espaço de possibilidades", category: "Projecto 01", description: "Projecto ilustrativo. Substitua esta descrição por informação confirmada sobre o trabalho realizado, o seu âmbito e os resultados alcançados.", image: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85", images: [], featured: true },
    { id: "demo-02", title: "Uma nova perspectiva", category: "Projecto 02", description: "Imagem e texto de demonstração. Adicione apenas projectos reais e imagens autorizadas pela empresa ou pelo cliente.", image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85", images: [], featured: true },
    { id: "demo-03", title: "Detalhes com propósito", category: "Projecto 03", description: "Conte aqui a história do projecto: o desafio, a solução executada e os resultados alcançados.", image: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85", images: [], featured: false },
    { id: "demo-04", title: "Formas de colaborar", category: "Projecto 04", description: "Este conteúdo é apenas uma pré-visualização. Edite-o para reflectir os projectos e serviços verdadeiros.", image: "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=85", images: [], featured: false }
  ];
  const initialContent = {
    company: {
      name: "A sua empresa",
      heroTitle: "Ideias que ganham forma e propósito.",
      heroDescription: "Apresente aqui a essência da sua empresa e o valor que entrega aos seus clientes.",
      aboutLead: "Um espaço para contar a história da sua empresa — com autenticidade, clareza e foco no que a distingue.",
      aboutDescription: "Apresente a sua missão, experiência e compromisso com clientes e parceiros. Substitua este texto por informação confirmada sobre a empresa.",
      mission: "A sua missão", values: "Os seus valores", commitment: "O seu compromisso",
      logo: "",
      heroImage: "",
      brandColor: "#b9c9a5",
      servicesDescription: "Adicione os serviços reais da empresa e explique como cada um pode ajudar os seus clientes.",
      portfolioDescription: "Uma selecção visual de projectos para mostrar a qualidade e o cuidado em cada detalhe.",
      portfolioDisclaimer: "Imagens e projectos ilustrativos. Substitua-os por trabalhos reais e autorizados da empresa.",
      contactDescription: "Conte-nos o que procura. Os dados de contacto da empresa devem ser configurados antes da publicação.",
      reasons: [
        { title: "Experiência comprovada", description: "Apresente a experiência e as competências da equipa." },
        { title: "Compromisso com qualidade", description: "Explique como assegura a qualidade do seu trabalho." },
        { title: "Relações de confiança", description: "Descreva a forma como trabalha com clientes e parceiros." }
      ]
    },
    contact: { email: "", phone: "", address: "Angola", whatsapp: "" },
    socials: [],
    categories: ["Projecto 01", "Projecto 02", "Projecto 03", "Projecto 04"],
    services: [
      { id: "service-01", title: "Nome do serviço", description: "Escreva uma descrição clara deste serviço e dos benefícios para o cliente." },
      { id: "service-02", title: "Nome do serviço", description: "Apresente aqui uma solução oferecida pela empresa, sem esquecer o que a torna útil." },
      { id: "service-03", title: "Nome do serviço", description: "Utilize este espaço para explicar o âmbito e as vantagens do serviço." }
    ],
    projects: demoProjects,
    requests: []
  };

  let content = loadContent();
  let activeFilter = "Todos";
  let activeProject = null;
  const grid = document.querySelector("#project-grid");
  const filters = document.querySelector("#filters");
  const projectModal = document.querySelector("#project-modal");
  let toastTimer;

  function copy(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function loadContent() {
    try {
      const saved = localStorage.getItem(contentKey);
      if (saved) return normalizeContent(JSON.parse(saved));
      const legacy = localStorage.getItem(legacyKey);
      const initial = copy(initialContent);
      if (legacy) {
        const oldProjects = JSON.parse(legacy);
        if (Array.isArray(oldProjects)) initial.projects = oldProjects.map((project, index) => ({
          ...project,
          images: Array.isArray(project.images) ? project.images : [],
          featured: index < 2
        }));
      }
      return initial;
    } catch (error) {
      console.error("Não foi possível carregar o conteúdo guardado.", error);
      return copy(initialContent);
    }
  }

  function normalizeContent(value) {
    if (!value || typeof value !== "object") throw new Error("Formato de conteúdo inválido.");
    const base = copy(initialContent);
    return {
      ...base,
      ...value,
      company: {
        ...base.company, ...(value.company || {}),
        reasons: Array.isArray(value.company?.reasons) ? value.company.reasons : base.company.reasons
      },
      contact: { ...base.contact, ...(value.contact || {}) },
      socials: Array.isArray(value.socials) ? value.socials : base.socials,
      categories: Array.isArray(value.categories) ? value.categories : base.categories,
      services: Array.isArray(value.services) ? value.services : base.services,
      projects: Array.isArray(value.projects) ? value.projects.map((project) => ({
        ...project,
        images: Array.isArray(project.images) ? project.images : [],
        featured: project.featured === true
      })) : base.projects,
      requests: Array.isArray(value.requests) ? value.requests : []
    };
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);
  }

  function safeUrl(value) {
    try {
      const url = new URL(value, window.location.href);
      return ["http:", "https:", "data:"].includes(url.protocol) ? url.href : "";
    } catch {
      return "";
    }
  }

  function persistContent() {
    try {
      localStorage.setItem(contentKey, JSON.stringify(content));
      return true;
    } catch (error) {
      console.error("Não foi possível guardar o conteúdo neste navegador.", error);
      showToast("Não foi possível guardar as alterações neste navegador.");
      return false;
    }
  }

  function renderFilters() {
    const categoryList = ["Todos", ...new Set([
      ...content.categories,
      ...content.projects.map((project) => project.category).filter(Boolean)
    ])];
    if (!categoryList.includes(activeFilter)) activeFilter = "Todos";
    filters.innerHTML = categoryList.map((category) =>
      `<button class="filter-button" type="button" aria-pressed="${category === activeFilter}" data-filter="${escapeHtml(category)}">${escapeHtml(category)}</button>`
    ).join("");
  }

  function renderProjects() {
    const projectList = [...content.projects].sort((a, b) => Number(b.featured) - Number(a.featured));
    const visible = activeFilter === "Todos" ? projectList : projectList.filter((project) => project.category === activeFilter);
    grid.innerHTML = visible.length ? visible.map((project) => `
      <article class="project-card" tabindex="0" role="button" aria-label="Ver projecto: ${escapeHtml(project.title)}" data-project="${escapeHtml(project.id)}">
        <div class="project-image"><img src="${escapeHtml(safeUrl(project.image))}" alt="${escapeHtml(project.title)}" loading="lazy"><span class="project-overlay" aria-hidden="true">${project.featured ? "★" : "↗"}</span></div>
        <div class="project-meta"><span class="project-category">${escapeHtml(project.category)}</span><span class="project-year">${project.featured ? "DESTAQUE" : "PORTFÓLIO"}</span></div>
        <h3>${escapeHtml(project.title)}</h3>
      </article>`).join("") : `<div class="empty-projects"><p>Ainda não existem projectos nesta categoria.</p></div>`;
    renderFilters();
  }

  function renderServices() {
    const serviceGrid = document.querySelector("#service-grid");
    serviceGrid.innerHTML = content.services.map((service, index) => `
      <article class="service-card">
        <span class="service-number">${String(index + 1).padStart(2, "0")} / SERVIÇO</span><span class="service-icon" aria-hidden="true">${["↗", "✳", "⌁"][index % 3]}</span>
        <h3>${escapeHtml(service.title)}</h3><p>${escapeHtml(service.description)}</p>
        <a href="#contacto" class="service-link" aria-label="Pedir informações sobre ${escapeHtml(service.title)}">Pedir informações <span aria-hidden="true">→</span></a>
      </article>`).join("");
    document.querySelector("#services-note").hidden = content.services.length > 0;
    document.querySelector("#contact-service-options").innerHTML =
      `<option value="">Seleccione um serviço (opcional)</option>${content.services.map((service) =>
        `<option value="${escapeHtml(service.title)}">${escapeHtml(service.title)}</option>`
      ).join("")}<option value="Outro / ainda não sei">Outro / ainda não sei</option>`;
  }

  function applyContent() {
    const root = document.documentElement;
    root.style.setProperty("--accent", content.company.brandColor || "#b9c9a5");
    document.querySelectorAll(".brand-logo").forEach((logo) => {
      const source = safeUrl(content.company.logo);
      logo.src = source;
      logo.hidden = !source;
      logo.closest(".brand-mark").classList.toggle("has-logo", Boolean(source));
    });
    document.querySelectorAll(".brand-monogram").forEach((monogram) => {
      monogram.textContent = (content.company.name || "A").trim().charAt(0).toLocaleUpperCase() || "A";
    });
    const heroImage = safeUrl(content.company.heroImage);
    document.querySelector(".hero-image").style.backgroundImage = heroImage
      ? `url(${JSON.stringify(heroImage)})`
      : "";
    document.querySelectorAll("[data-company-name]").forEach((element) => {
      element.textContent = content.company.name || "A sua empresa";
    });
    document.title = `${content.company.name || "A sua empresa"} — projectos e serviços`;
    document.querySelector('meta[name="description"]').content = content.company.heroDescription || "";
    document.querySelector('meta[property="og:title"]').content = document.title;
    document.querySelector('meta[name="theme-color"]').content = content.company.brandColor || "#b9c9a5";
    document.querySelectorAll(".brand[aria-label]").forEach((brand) => {
      brand.setAttribute("aria-label", `${content.company.name || "A sua empresa"} — início`);
    });
    document.querySelector("#hero-title").textContent = content.company.heroTitle;
    document.querySelector("#hero-description").textContent = content.company.heroDescription;
    document.querySelector("#about-lead").textContent = content.company.aboutLead;
    document.querySelector("#about-description").textContent = content.company.aboutDescription;
    document.querySelector("#mission-value").textContent = content.company.mission;
    document.querySelector("#values-value").textContent = content.company.values;
    document.querySelector("#commitment-value").textContent = content.company.commitment;
    document.querySelector("#services-description").textContent = content.company.servicesDescription;
    document.querySelector("#portfolio-description").textContent = content.company.portfolioDescription;
    document.querySelector("#portfolio-disclaimer").textContent = content.company.portfolioDisclaimer;
    document.querySelector("#contact-description").textContent = content.company.contactDescription;
    content.company.reasons.forEach((reason, index) => {
      const number = index + 1;
      const title = document.querySelector(`#reason-title-${number}`);
      if (title) title.textContent = reason.title;
      const description = document.querySelector(`#reason-description-${number}`);
      if (description) description.textContent = reason.description;
    });
    document.querySelector("#contact-email").textContent = content.contact.email || "A configurar";
    document.querySelector("#contact-phone").textContent = content.contact.phone || "A configurar";
    document.querySelector("#contact-address").textContent = content.contact.address || "A configurar";
    const whatsapp = document.querySelector(".whatsapp-float");
    const phoneDigits = (content.contact.whatsapp || "").replace(/\D/g, "");
    whatsapp.classList.toggle("is-unconfigured", !phoneDigits);
    whatsapp.href = phoneDigits ? `https://wa.me/${phoneDigits}` : "#contacto";
    whatsapp.title = phoneDigits ? "Contactar pelo WhatsApp" : "Número de WhatsApp por configurar";
    document.querySelector("#social-links").innerHTML = content.socials.map((social) => {
      const href = safeUrl(social.url);
      return href ? `<a href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer">${escapeHtml(social.name)} ↗</a>` : "";
    }).join("");
    renderServices();
    renderProjects();
  }

  function openModal(modal) {
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    modal.querySelector(".modal-close").focus();
  }

  function closeModal(modal) {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    if (!document.querySelector(".modal.is-open")) document.body.classList.remove("modal-open");
  }

  function showToast(message) {
    const toast = document.querySelector("#toast");
    toast.textContent = message;
    toast.classList.add("is-visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 3200);
  }

  function showProject(project) {
    if (!project) return;
    activeProject = project;
    const detailImage = document.querySelector("#detail-image");
    detailImage.src = safeUrl(project.image);
    detailImage.alt = project.title;
    document.querySelector("#detail-category").textContent = project.category;
    document.querySelector("#modal-title").textContent = project.title;
    document.querySelector("#detail-description").textContent = project.description;
    const gallery = document.querySelector("#detail-gallery");
    const photos = [...new Set([project.image, ...(project.images || [])].filter(Boolean))];
    gallery.innerHTML = photos.length > 1 ? photos.map((photo, index) =>
      `<button type="button" class="detail-thumb${index === 0 ? " is-selected" : ""}" data-photo="${escapeHtml(safeUrl(photo))}" aria-label="Ver fotografia ${index + 1}"><img src="${escapeHtml(safeUrl(photo))}" alt=""></button>`
    ).join("") : "";
    openModal(projectModal);
  }

  filters.addEventListener("click", (event) => {
    const button = event.target.closest("[data-filter]");
    if (!button) return;
    activeFilter = button.dataset.filter;
    renderProjects();
  });

  grid.addEventListener("click", (event) => {
    const card = event.target.closest("[data-project]");
    if (card) showProject(content.projects.find((project) => project.id === card.dataset.project));
  });

  grid.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const card = event.target.closest("[data-project]");
    if (!card) return;
    event.preventDefault();
    showProject(content.projects.find((project) => project.id === card.dataset.project));
  });

  document.querySelectorAll("[data-close-modal]").forEach((element) => {
    element.addEventListener("click", () => closeModal(element.closest(".modal")));
  });
  document.querySelector("#detail-gallery").addEventListener("click", (event) => {
    const button = event.target.closest("[data-photo]");
    if (!button) return;
    document.querySelector("#detail-image").src = button.dataset.photo;
    document.querySelectorAll(".detail-thumb").forEach((thumbnail) => thumbnail.classList.toggle("is-selected", thumbnail === button));
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") document.querySelectorAll(".modal.is-open").forEach(closeModal);
  });
  document.querySelector("#share-project").addEventListener("click", async () => {
    if (!activeProject) return;
    const shareData = { title: activeProject.title, text: activeProject.title, url: window.location.href.split("#")[0] };
    try {
      if (navigator.share) await navigator.share(shareData);
      else if (navigator.clipboard) {
        await navigator.clipboard.writeText(`${shareData.text}: ${shareData.url}`);
        showToast("Ligação copiada para a área de transferência.");
      } else showToast("A partilha não está disponível neste navegador.");
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Não foi possível partilhar o projecto.", error);
        showToast("Não foi possível partilhar o projecto.");
      }
    }
  });
  document.querySelector("#project-contact").addEventListener("click", () => {
    if (!activeProject) return;
    document.querySelector("#contact-form").elements.message.value =
      `Tenho interesse num serviço semelhante ao projecto "${activeProject.title}".`;
    closeModal(projectModal);
  });
  document.querySelector("#contact-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const status = document.querySelector("#form-status");
    if (!form.reportValidity()) return;
    status.classList.add("error");
    status.textContent = "A solicitação não foi enviada: não existe um serviço de envio configurado. Contacte a empresa pelos canais oficiais, quando disponíveis.";
    showToast("Envio indisponível: configure um serviço de contacto.");
  });
  document.querySelector(".whatsapp-float").addEventListener("click", (event) => {
    if (content.contact.whatsapp) return;
    event.preventDefault();
    document.querySelector("#contacto").scrollIntoView({ behavior: "smooth" });
    showToast("Configure o número oficial da empresa para activar o WhatsApp.");
  });
  window.addEventListener("storage", (event) => {
    if (event.key !== contentKey) return;
    content = loadContent();
    applyContent();
  });
  document.querySelector("#year").textContent = new Date().getFullYear();
  applyContent();
})();
