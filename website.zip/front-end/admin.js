(() => {
  "use strict";

  const contentKey = "empresa-site-content-v1";
  const legacyKey = "empresa-portfolio-preview-v1";
  const defaultProjects = [
    { id: "demo-01", title: "Espaço de possibilidades", category: "Projecto 01", description: "Projecto ilustrativo. Substitua esta descrição por informação confirmada sobre o trabalho realizado, o seu âmbito e os resultados alcançados.", image: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85", images: [], featured: true },
    { id: "demo-02", title: "Uma nova perspectiva", category: "Projecto 02", description: "Imagem e texto de demonstração. Adicione apenas projectos reais e imagens autorizadas pela empresa ou pelo cliente.", image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85", images: [], featured: true },
    { id: "demo-03", title: "Detalhes com propósito", category: "Projecto 03", description: "Conte aqui a história do projecto: o desafio, a solução executada e os resultados alcançados.", image: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85", images: [], featured: false },
    { id: "demo-04", title: "Formas de colaborar", category: "Projecto 04", description: "Este conteúdo é apenas uma pré-visualização. Edite-o para reflectir os projectos e serviços verdadeiros.", image: "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=85", images: [], featured: false }
  ];
  const copyGroups = [
    {
      title: "Navegação e chamadas",
      fields: [
        ["navAbout", "Menu: empresa", "A empresa"],
        ["navServices", "Menu: serviços", "Serviços"],
        ["navPortfolio", "Menu: portfólio", "Portfólio"],
        ["navContact", "Menu: contacto", "Contacto"],
        ["navCta", "Botão de contacto no menu", "Fale connosco"],
        ["heroPrimaryCta", "Botão principal do banner", "Conheça o nosso portfólio"],
        ["heroSecondaryCta", "Botão secundário do banner", "Solicitar orçamento"],
        ["heroNote", "Nota no banner", "Conteúdo ilustrativo — personalize com os dados da empresa"],
        ["scrollLabel", "Texto de navegação do banner", "DESCOBRIR"],
        ["aboutLink", "Ligação da secção da empresa", "Saiba mais sobre nós"],
        ["portfolioCta", "Botão do portfólio", "Tem um projecto em mente?"],
        ["footerBack", "Ligação do rodapé", "Voltar ao topo"]
      ]
    },
    {
      title: "Títulos e introduções das secções",
      fields: [
        ["aboutEyebrow", "Subtítulo da secção da empresa", "Quem somos"],
        ["aboutTitle", "Título da secção da empresa", "Uma empresa feita para fazer acontecer."],
        ["statsNote", "Nota da secção da empresa", "Substitua os campos por dados reais."],
        ["servicesEyebrow", "Subtítulo dos serviços", "O que fazemos"],
        ["servicesTitle", "Título dos serviços", "Serviços com intenção."],
        ["servicesNote", "Nota dos serviços", "Os serviços acima são campos de preenchimento, não serviços confirmados."],
        ["serviceCta", "Ligação em cada serviço", "Pedir informações"],
        ["portfolioEyebrow", "Subtítulo do portfólio", "Portfólio"],
        ["portfolioTitle", "Título do portfólio", "Trabalho que fala por si."],
        ["portfolioIndex", "Identificação do portfólio", "PORTFÓLIO · ANGOLA"],
        ["whyEyebrow", "Subtítulo dos diferenciais", "Porque nós"],
        ["whyTitle", "Título dos diferenciais", "Excelência em cada detalhe."],
        ["whyDescription", "Texto dos diferenciais", "Partilhe os motivos reais pelos quais os clientes escolhem a sua empresa. Estes pontos são sugestões de estrutura, não afirmações sobre a empresa.", true],
        ["whyImageAlt", "Texto alternativo da imagem dos diferenciais", "Edifícios modernos vistos de baixo, imagem ilustrativa", true],
        ["whyImageCaption", "Legenda da imagem dos diferenciais", "01 — VISÃO"],
        ["contactEyebrow", "Subtítulo de contacto", "Vamos conversar"],
        ["contactTitle", "Título de contacto", "O próximo passo começa com uma conversa."],
        ["footerIntro", "Texto institucional do rodapé", "Uma apresentação digital à medida da sua empresa."],
        ["footerCopyright", "Texto de copyright", "Personalize antes de publicar."],
        ["footerInstitutional", "Texto institucional final", "Angola · Informação institucional a configurar"]
      ]
    }
  ];
  const defaultCopy = Object.fromEntries(copyGroups.flatMap((group) => group.fields.map(([key, , value]) => [key, value])));
  const defaults = {
    company: {
      name: "A sua empresa", heroTitle: "Ideias que ganham forma e propósito.",
      heroDescription: "Apresente aqui a essência da sua empresa e o valor que entrega aos seus clientes.",
      aboutLead: "Um espaço para contar a história da sua empresa — com autenticidade, clareza e foco no que a distingue.",
      aboutDescription: "Apresente a sua missão, experiência e compromisso com clientes e parceiros. Substitua este texto por informação confirmada sobre a empresa.",
      mission: "A sua missão", values: "Os seus valores", commitment: "O seu compromisso",
      logo: "", heroImage: "", brandColor: "#b9c9a5",
      copy: defaultCopy,
      servicesDescription: "Adicione os serviços reais da empresa e explique como cada um pode ajudar os seus clientes.",
      portfolioDescription: "Uma selecção visual de projectos para mostrar a qualidade e o cuidado em cada detalhe.",
      portfolioDisclaimer: "Imagens e projectos ilustrativos. Substitua-os por trabalhos reais e autorizados da empresa.",
      contactDescription: "Conte-nos o que procura. Os dados de contacto da empresa devem ser configurados antes da publicação.",
      reasons: [
        { title: "Experiência comprovada", description: "Apresente a experiência e as competências da equipa." },
        { title: "Compromisso com qualidade", description: "Explique como assegura a qualidade do seu trabalho." },
        { title: "Relações de confiança", description: "Descreva a forma como trabalha com clientes e parceiros." }
      ]
    },
    contact: { email: "", phone: "", address: "Angola", whatsapp: "" },
    socials: [],
    categories: ["Projecto 01", "Projecto 02", "Projecto 03", "Projecto 04"],
    services: [
      { id: "service-01", title: "Nome do serviço", description: "Escreva uma descrição clara deste serviço e dos benefícios para o cliente." },
      { id: "service-02", title: "Nome do serviço", description: "Apresente aqui uma solução oferecida pela empresa, sem esquecer o que a torna útil." },
      { id: "service-03", title: "Nome do serviço", description: "Utilize este espaço para explicar o âmbito e as vantagens do serviço." }
    ],
    projects: defaultProjects,
    requests: []
  };

  let content = loadContent();
  let editingPhotos = [];
  let toastTimer;

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function loadContent() {
    try {
      const saved = localStorage.getItem(contentKey);
      if (saved) return normalize(JSON.parse(saved));
      const legacy = localStorage.getItem(legacyKey);
      const initial = clone(defaults);
      if (legacy) {
        const parsed = JSON.parse(legacy);
        if (Array.isArray(parsed)) initial.projects = parsed.map((project, index) => ({
          ...project,
          images: Array.isArray(project.images) ? project.images : [],
          featured: project.featured === true || (!("featured" in project) && index < 2)
        }));
      }
      return initial;
    } catch (error) {
      console.error("Não foi possível carregar o conteúdo guardado.", error);
      return clone(defaults);
    }
  }

  function normalize(value) {
    if (!value || typeof value !== "object") throw new Error("Formato de conteúdo inválido.");
    const base = clone(defaults);
    return {
      ...base, ...value,
      company: {
        ...base.company, ...(value.company || {}),
        copy: { ...base.company.copy, ...(value.company?.copy || {}) },
        reasons: Array.isArray(value.company?.reasons) ? value.company.reasons : base.company.reasons
      },
      contact: { ...base.contact, ...(value.contact || {}) },
      categories: Array.isArray(value.categories) ? value.categories : base.categories,
      socials: Array.isArray(value.socials) ? value.socials : [],
      services: Array.isArray(value.services) ? value.services : base.services,
      projects: Array.isArray(value.projects) ? value.projects.map((project) => ({
        ...project, images: Array.isArray(project.images) ? project.images : [], featured: project.featured === true
      })) : base.projects,
      requests: Array.isArray(value.requests) ? value.requests : []
    };
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);
  }

  function safeUrl(value) {
    try {
      const url = new URL(value, window.location.href);
      return ["http:", "https:", "data:"].includes(url.protocol) ? url.href : "";
    } catch {
      return "";
    }
  }

  function safeImageSource(value) {
    const source = String(value || "").trim();
    if (source.startsWith("data:")) return /^data:image\/(?:jpeg|png|webp|gif);base64,/i.test(source) ? source : "";
    const url = safeUrl(source);
    return url && /^https?:/i.test(url) ? url : "";
  }

  function notify(message) {
    const toast = document.querySelector("#admin-toast");
    toast.textContent = message;
    toast.classList.add("is-visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 3500);
  }

  function persist() {
    const serialized = JSON.stringify(content);
    if (serialized.length > 3_500_000) {
      notify("O conteúdo excede o limite local. Reduza o número ou tamanho das fotografias.");
      return false;
    }
    try {
      localStorage.setItem(contentKey, serialized);
      return true;
    } catch (error) {
      console.error("Não foi possível guardar o conteúdo neste navegador.", error);
      notify("Não foi possível guardar. O armazenamento do navegador pode estar cheio.");
      return false;
    }
  }

  function renderOverview() {
    document.querySelector("#project-count").textContent = content.projects.length;
    document.querySelector("#service-count").textContent = content.services.length;
    document.querySelector("#request-count").textContent = content.requests.length;
    document.querySelector("#stat-projects").textContent = content.projects.length;
    document.querySelector("#stat-featured").textContent = content.projects.filter((project) => project.featured).length;
    document.querySelector("#stat-services").textContent = content.services.length;
    document.querySelector("#stat-requests").textContent = content.requests.length;
    const recent = [...content.projects].sort((a, b) => Number(b.featured) - Number(a.featured)).slice(0, 4);
    document.querySelector("#recent-projects").innerHTML = recent.length ? recent.map((project) => `
      <div class="recent-row"><img src="${escapeHtml(safeUrl(project.image))}" alt=""><div><strong>${escapeHtml(project.title)}</strong><small>${escapeHtml(project.category)}</small></div>${project.featured ? '<span class="featured-label">DESTAQUE</span>' : ""}</div>`).join("")
      : `<p class="project-management-empty">Ainda não existem projectos.</p>`;
  }

  function renderCopyFields() {
    document.querySelector("#website-copy-fields").innerHTML = copyGroups.flatMap((group) => `
      <div class="copy-group-heading full-field">${escapeHtml(group.title)}</div>
      ${group.fields.map(([key, label, , multiline]) => `
        <label class="${multiline ? "full-field" : ""}">${escapeHtml(label)}
          ${multiline
            ? `<textarea data-copy-field="${key}" rows="3" maxlength="300"></textarea>`
            : `<input data-copy-field="${key}" maxlength="120">`}
        </label>`).join("")}`).join("");
  }

  function renderProjectRows() {
    const categorySelect = document.querySelector("#project-category");
    const selected = categorySelect.value;
    categorySelect.innerHTML = content.categories.map((category) =>
      `<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`).join("");
    if (content.categories.includes(selected)) categorySelect.value = selected;
    document.querySelector("#project-list-count").textContent = `${content.projects.length} projecto${content.projects.length === 1 ? "" : "s"}`;
    document.querySelector("#project-list").innerHTML = content.projects.length ? content.projects.map((project) => `
      <div class="managed-project">
        <img src="${escapeHtml(safeUrl(project.image))}" alt="">
        <div><strong>${escapeHtml(project.title)}</strong><small>${escapeHtml(project.category)}${project.featured ? " · Destaque" : ""}</small></div>
        <button type="button" data-feature="${escapeHtml(project.id)}" aria-label="${project.featured ? "Remover destaque de" : "Destacar"} ${escapeHtml(project.title)}">${project.featured ? "★ Destaque" : "☆ Destacar"}</button>
        <button type="button" data-edit-project="${escapeHtml(project.id)}">Editar</button>
        <button type="button" data-delete-project="${escapeHtml(project.id)}">Eliminar</button>
      </div>`).join("") : `<p class="project-management-empty">Ainda não existem projectos. Crie o primeiro projecto acima.</p>`;
    document.querySelector("#category-list").innerHTML = content.categories.length ? content.categories.map((category) => `
      <div class="category-row" data-category="${escapeHtml(category)}"><span>${escapeHtml(category)}</span><span><button type="button" data-rename-category>Renomear</button> <button type="button" data-delete-category>Eliminar</button></span></div>`).join("")
      : `<p class="project-management-empty">Adicione uma categoria para organizar projectos.</p>`;
    renderOverview();
  }

  function renderServices() {
    document.querySelector("#service-list").innerHTML = content.services.length ? content.services.map((service) => `
      <article class="service-admin-card"><p class="eyebrow">SERVIÇO</p><h3>${escapeHtml(service.title)}</h3><p>${escapeHtml(service.description)}</p><div class="service-admin-actions"><button type="button" data-edit-service="${escapeHtml(service.id)}">Editar</button><button type="button" data-delete-service="${escapeHtml(service.id)}">Remover</button></div></article>`).join("")
      : `<p class="project-management-empty">Ainda não existem serviços.</p>`;
    renderOverview();
  }

  function showView(name) {
    document.querySelectorAll(".view-panel").forEach((panel) => {
      const selected = panel.id === `view-${name}`;
      panel.classList.toggle("is-visible", selected);
      panel.hidden = !selected;
    });
    document.querySelectorAll("[data-view]").forEach((button) => button.classList.toggle("is-active", button.dataset.view === name));
    const headings = { overview: "Visão geral", projects: "Projectos", services: "Serviços", company: "Conteúdo e contactos", requests: "Pedidos recebidos" };
    document.querySelector("#page-heading").textContent = headings[name] || headings.overview;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function clearProjectForm() {
    document.querySelector("#project-form").reset();
    document.querySelector('#project-form [name="id"]').value = "";
    document.querySelector("#project-form-heading").textContent = "Novo projecto";
    document.querySelector("#save-project").textContent = "Guardar projecto";
    document.querySelector("#project-message").textContent = "";
    editingPhotos = [];
    renderPhotos();
    document.querySelector("#project-editor").hidden = true;
  }

  function renderPhotos() {
    const list = document.querySelector("#photo-list");
    list.innerHTML = editingPhotos.length ? editingPhotos.map((image, index) => `
      <div class="photo-thumb"><img src="${escapeHtml(safeUrl(image))}" alt="Fotografia ${index + 1}"><small>${index === 0 ? "Capa" : `Imagem ${index + 1}`}</small><span class="photo-actions"><button type="button" data-move-photo="${index}" data-direction="-1" aria-label="Mover imagem ${index + 1} para a esquerda" ${index === 0 ? "disabled" : ""}>←</button><button type="button" data-move-photo="${index}" data-direction="1" aria-label="Mover imagem ${index + 1} para a direita" ${index === editingPhotos.length - 1 ? "disabled" : ""}>→</button><button type="button" data-remove-photo="${index}" aria-label="Remover imagem ${index + 1}">×</button></span></div>`).join("")
      : `<span class="empty-photos">Ainda não foram adicionadas fotografias.</span>`;
  }

  function openNewProject() {
    if (!content.categories.length) {
      notify("Adicione uma categoria antes de criar um projecto.");
      return;
    }
    clearProjectForm();
    document.querySelector("#project-editor").hidden = false;
    document.querySelector("#project-form-heading").textContent = "Novo projecto";
    document.querySelector("#project-form").elements.title.focus();
    document.querySelector("#project-editor").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function editProject(id) {
    const project = content.projects.find((entry) => entry.id === id);
    if (!project) return;
    const form = document.querySelector("#project-form");
    form.elements.id.value = project.id;
    form.elements.title.value = project.title;
    form.elements.category.value = project.category;
    form.elements.description.value = project.description;
    form.elements.image.value = project.image.startsWith("data:") ? "" : project.image;
    form.elements.featured.checked = project.featured;
    editingPhotos = [...(project.images || [])];
    if (!editingPhotos.length && project.image.startsWith("data:")) editingPhotos = [project.image];
    renderPhotos();
    document.querySelector("#project-form-heading").textContent = "Editar projecto";
    document.querySelector("#save-project").textContent = "Guardar alterações";
    document.querySelector("#project-editor").hidden = false;
    document.querySelector("#project-editor").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function readFile(file, maxDimension = 1400) {
    return new Promise((resolve, reject) => {
      if (!file.type.startsWith("image/")) {
        reject(new Error(`${file.name} não é um ficheiro de imagem.`));
        return;
      }
      if (file.size > 12 * 1024 * 1024) {
        reject(new Error(`${file.name} excede o limite de 12 MB.`));
        return;
      }
      const reader = new FileReader();
      reader.onerror = () => reject(new Error(`Não foi possível ler ${file.name}.`));
      reader.onload = () => {
        const image = new Image();
        image.onerror = () => reject(new Error(`${file.name} não é uma imagem válida.`));
        image.onload = () => {
          const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
          const canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
          canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
          const context = canvas.getContext("2d");
          if (!context) {
            reject(new Error("Este navegador não conseguiu processar a imagem."));
            return;
          }
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          canvas.toBlob((blob) => {
            if (!blob) {
              reject(new Error(`Não foi possível comprimir ${file.name}.`));
              return;
            }
            if (blob.size > 500 * 1024) {
              reject(new Error(`${file.name} continua demasiado grande após compressão.`));
              return;
            }
            const output = new FileReader();
            output.onerror = () => reject(new Error(`Não foi possível guardar ${file.name}.`));
            output.onload = () => resolve(output.result);
            output.readAsDataURL(blob);
          }, "image/webp", 0.78);
        };
        image.src = String(reader.result);
      };
      reader.readAsDataURL(file);
    });
  }

  document.querySelectorAll("[data-view]").forEach((button) => button.addEventListener("click", () => showView(button.dataset.view)));
  document.querySelectorAll("[data-open-view]").forEach((button) => button.addEventListener("click", () => showView(button.dataset.openView)));
  document.querySelector("#new-project").addEventListener("click", openNewProject);
  document.querySelectorAll("[data-cancel-project]").forEach((button) => button.addEventListener("click", clearProjectForm));
  document.querySelector("#project-form").elements.photos.addEventListener("change", async (event) => {
    const files = [...event.currentTarget.files];
    event.currentTarget.value = "";
    if (editingPhotos.length + files.length > 8) {
      notify("Cada projecto pode ter até 8 fotografias.");
      return;
    }
    for (const file of files) {
      try {
        editingPhotos.push(await readFile(file));
      } catch (error) {
        console.error("Falha ao processar fotografia.", error);
        notify(error.message);
      }
    }
    renderPhotos();
  });
  document.querySelector("#photo-list").addEventListener("click", (event) => {
    const remove = event.target.closest("[data-remove-photo]");
    const move = event.target.closest("[data-move-photo]");
    if (remove) editingPhotos.splice(Number(remove.dataset.removePhoto), 1);
    if (move) {
      const index = Number(move.dataset.movePhoto);
      const nextIndex = index + Number(move.dataset.direction);
      if (nextIndex < 0 || nextIndex >= editingPhotos.length) return;
      [editingPhotos[index], editingPhotos[nextIndex]] = [editingPhotos[nextIndex], editingPhotos[index]];
    }
    if (remove || move) renderPhotos();
  });
  document.querySelector("#project-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const id = data.get("id") || `project-${Date.now()}`;
    const category = data.get("category");
    const imageInput = data.get("image").trim();
    const validUrl = imageInput ? safeUrl(imageInput) : "";
    if (!category || !content.categories.includes(category)) {
      notify("Escolha uma categoria válida.");
      return;
    }
    if (imageInput && !validUrl) {
      notify("A imagem de capa deve usar um endereço HTTP ou HTTPS válido.");
      return;
    }
    if (!validUrl && !editingPhotos.length) {
      notify("Indique uma imagem de capa ou carregue pelo menos uma fotografia.");
      return;
    }
    const featured = form.elements.featured.checked;
    const featuredCount = content.projects.filter((project) => project.featured && project.id !== id).length;
    if (featured && featuredCount >= 3) {
      notify("Pode destacar no máximo três projectos na página inicial.");
      return;
    }
    const project = {
      id,
      title: data.get("title").trim(),
      category,
      description: data.get("description").trim(),
      image: validUrl || editingPhotos[0],
      images: editingPhotos,
      featured
    };
    const oldProjects = content.projects;
    const index = content.projects.findIndex((entry) => entry.id === id);
    if (index < 0) content.projects = [...content.projects, project];
    else content.projects = content.projects.map((entry) => entry.id === id ? project : entry);
    if (!persist()) {
      content.projects = oldProjects;
      return;
    }
    clearProjectForm();
    renderProjectRows();
    notify(index < 0 ? "Projecto guardado no navegador." : "Projecto actualizado no navegador.");
  });
  document.querySelector("#project-list").addEventListener("click", (event) => {
    const edit = event.target.closest("[data-edit-project]");
    const remove = event.target.closest("[data-delete-project]");
    const feature = event.target.closest("[data-feature]");
    if (edit) editProject(edit.dataset.editProject);
    if (feature) {
      const project = content.projects.find((entry) => entry.id === feature.dataset.feature);
      if (!project) return;
      if (!project.featured && content.projects.filter((entry) => entry.featured).length >= 3) {
        notify("Pode destacar no máximo três projectos na página inicial.");
        return;
      }
      project.featured = !project.featured;
      if (persist()) renderProjectRows();
    }
    if (remove) {
      const project = content.projects.find((entry) => entry.id === remove.dataset.deleteProject);
      if (!project || !window.confirm(`Eliminar o projecto "${project.title}"?`)) return;
      const oldProjects = content.projects;
      content.projects = content.projects.filter((entry) => entry.id !== project.id);
      if (persist()) {
        renderProjectRows();
        notify("Projecto eliminado.");
      } else content.projects = oldProjects;
    }
  });

  document.querySelector("#category-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const category = form.elements.category.value.trim();
    if (content.categories.some((entry) => entry.toLocaleLowerCase() === category.toLocaleLowerCase())) {
      notify("Essa categoria já existe.");
      return;
    }
    const previous = content.categories;
    content.categories = [...content.categories, category];
    if (persist()) {
      form.reset();
      renderProjectRows();
      notify("Categoria adicionada.");
    } else content.categories = previous;
  });
  document.querySelector("#category-list").addEventListener("click", (event) => {
    const row = event.target.closest("[data-category]");
    const rename = event.target.closest("[data-rename-category]");
    const cancel = event.target.closest("[data-cancel-rename]");
    const remove = event.target.closest("[data-delete-category]");
    if (rename) {
      if (!row) return;
      const category = row.dataset.category;
      row.innerHTML = `<form class="category-rename-form" data-rename-form><input name="category" required maxlength="35" aria-label="Novo nome da categoria" value="${escapeHtml(category)}"><button type="submit">Guardar</button><button type="button" data-cancel-rename>Cancelar</button></form>`;
      row.querySelector("input").focus();
      row.querySelector("input").select();
      return;
    }
    if (cancel && row) renderProjectRows();
    if (remove) {
      const category = row?.dataset.category;
      if (!category) return;
      if (content.projects.some((project) => project.category === category)) {
        notify("Reatribua primeiro os projectos antes de eliminar esta categoria.");
        return;
      }
      const previous = content.categories;
      content.categories = content.categories.filter((entry) => entry !== category);
      if (persist()) {
        renderProjectRows();
        notify("Categoria eliminada.");
      } else content.categories = previous;
    }
  });
  document.querySelector("#category-list").addEventListener("submit", (event) => {
    const form = event.target.closest("[data-rename-form]");
    if (!form) return;
    event.preventDefault();
    const row = form.closest("[data-category]");
    const oldName = row.dataset.category;
    const newName = form.elements.category.value.trim();
    if (!newName || newName === oldName) {
      renderProjectRows();
      return;
    }
    if (content.categories.some((category) => category.toLocaleLowerCase() === newName.toLocaleLowerCase())) {
      notify("Essa categoria já existe.");
      return;
    }
    const oldCategories = content.categories;
    const oldProjects = content.projects;
    content.categories = content.categories.map((category) => category === oldName ? newName : category);
    content.projects = content.projects.map((project) => project.category === oldName ? { ...project, category: newName } : project);
    if (persist()) {
      renderProjectRows();
      notify("Categoria actualizada.");
    } else {
      content.categories = oldCategories;
      content.projects = oldProjects;
    }
  });

  document.querySelector("#new-service").addEventListener("click", () => {
    const form = document.querySelector("#service-form");
    form.reset();
    form.elements.id.value = "";
    document.querySelector("#service-form-heading").textContent = "Novo serviço";
    document.querySelector("#service-editor").hidden = false;
    form.elements.title.focus();
  });
  document.querySelectorAll("[data-cancel-service]").forEach((button) => button.addEventListener("click", () => {
    document.querySelector("#service-editor").hidden = true;
  }));
  document.querySelector("#service-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const id = data.get("id") || `service-${Date.now()}`;
    const service = { id, title: data.get("title").trim(), description: data.get("description").trim() };
    const oldServices = content.services;
    const exists = content.services.some((entry) => entry.id === id);
    content.services = exists ? content.services.map((entry) => entry.id === id ? service : entry) : [...content.services, service];
    if (persist()) {
      document.querySelector("#service-editor").hidden = true;
      renderServices();
      notify(exists ? "Serviço actualizado." : "Serviço adicionado.");
    } else content.services = oldServices;
  });
  document.querySelector("#service-list").addEventListener("click", (event) => {
    const edit = event.target.closest("[data-edit-service]");
    const remove = event.target.closest("[data-delete-service]");
    if (edit) {
      const service = content.services.find((entry) => entry.id === edit.dataset.editService);
      if (!service) return;
      const form = document.querySelector("#service-form");
      form.elements.id.value = service.id;
      form.elements.title.value = service.title;
      form.elements.description.value = service.description;
      document.querySelector("#service-form-heading").textContent = "Editar serviço";
      document.querySelector("#service-editor").hidden = false;
      form.elements.title.focus();
      document.querySelector("#service-editor").scrollIntoView({ behavior: "smooth" });
    }
    if (remove) {
      const service = content.services.find((entry) => entry.id === remove.dataset.deleteService);
      if (!service || !window.confirm(`Remover o serviço "${service.title}"?`)) return;
      const previous = content.services;
      content.services = content.services.filter((entry) => entry.id !== service.id);
      if (persist()) {
        renderServices();
        notify("Serviço removido.");
      } else content.services = previous;
    }
  });

  function populateCompanyForm() {
    const form = document.querySelector("#company-form");
    const fields = { ...content.company, ...content.contact };
    content.company.reasons.forEach((reason, index) => {
      fields[`reasonTitle${index + 1}`] = reason.title;
      fields[`reasonDescription${index + 1}`] = reason.description;
    });
    Object.entries(fields).forEach(([name, value]) => {
      if (form.elements[name]) form.elements[name].value = value ?? "";
    });
    document.querySelectorAll("[data-copy-field]").forEach((field) => {
      field.value = content.company.copy[field.dataset.copyField] ?? "";
    });
    window.applyBrandTheme(content.company.brandColor || "#b9c9a5");
    updateAdminBrand();
    renderImagePreview("logo", content.company.logo);
    renderImagePreview("heroImage", content.company.heroImage);
    renderSocials();
  }

  function updateAdminBrand() {
    document.querySelector("[data-admin-company-name]").textContent = content.company.name || "A sua empresa";
    document.querySelector(".admin-monogram").textContent = (content.company.name || "A").trim().charAt(0).toLocaleUpperCase() || "A";
    const adminLogo = document.querySelector(".admin-logo");
    const logoSource = safeImageSource(content.company.logo);
    adminLogo.src = logoSource;
    adminLogo.hidden = !logoSource;
    adminLogo.closest(".brand-mark").classList.toggle("has-logo", Boolean(logoSource));
  }

  function renderImagePreview(field, value) {
    const isLogo = field === "logo";
    const image = document.querySelector(isLogo ? "#logo-preview" : "#banner-preview");
    const placeholder = document.querySelector(isLogo ? "#logo-placeholder" : "#banner-placeholder");
    const source = safeImageSource(value);
    image.src = source;
    image.hidden = !source;
    placeholder.hidden = Boolean(source);
  }

  async function handleBrandImage(event, field, maxDimension) {
    const input = event.currentTarget;
    const file = input.files[0];
    input.value = "";
    if (!file) return;
    try {
      const image = await readFile(file, maxDimension);
      document.querySelector(`#company-form [name="${field}"]`).value = image;
      renderImagePreview(field, image);
      if (field === "logo") {
        try {
          const color = await window.extractLogoColor(image);
          updateBrandColor(color);
          notify("Logótipo carregado e cor principal extraída.");
        } catch (error) {
          console.error("Não foi possível extrair a cor do logótipo.", error);
          notify("Logótipo carregado. Escolha a cor da marca manualmente.");
        }
      }
    } catch (error) {
      console.error("Falha ao processar imagem da marca.", error);
      notify(error.message);
    }
  }

  document.querySelector('#company-form [name="logoFile"]').addEventListener("change", (event) => handleBrandImage(event, "logo", 500));
  document.querySelector('#company-form [name="heroImageFile"]').addEventListener("change", (event) => handleBrandImage(event, "heroImage", 2200));
  document.querySelector('#company-form [name="logo"]').addEventListener("input", (event) => renderImagePreview("logo", event.currentTarget.value));
  document.querySelector('#company-form [name="heroImage"]').addEventListener("input", (event) => renderImagePreview("heroImage", event.currentTarget.value));
  document.querySelector('#company-form [name="name"]').addEventListener("input", (event) => {
    const name = event.currentTarget.value.trim() || "A sua empresa";
    document.querySelector("[data-admin-company-name]").textContent = name;
    document.querySelector(".admin-monogram").textContent = name.charAt(0).toLocaleUpperCase();
  });
  function updateBrandColor(color) {
    document.querySelector('#company-form [name="brandColor"]').value = color;
    window.applyBrandTheme(color);
  }
  document.querySelector('#company-form [name="brandColor"]').addEventListener("input", (event) => window.applyBrandTheme(event.currentTarget.value));
  document.querySelector("#extract-brand-color").addEventListener("click", async () => {
    const source = safeImageSource(document.querySelector('#company-form [name="logo"]').value);
    if (!source) {
      notify("Carregue um logótipo ou indique um endereço de imagem antes de extrair a cor.");
      return;
    }
    try {
      updateBrandColor(await window.extractLogoColor(source));
      notify("Cor principal extraída do logótipo.");
    } catch (error) {
      console.error("Não foi possível extrair a cor do logótipo.", error);
      notify(error.message);
    }
  });
  document.querySelectorAll("[data-clear-image]").forEach((button) => button.addEventListener("click", () => {
    const field = button.dataset.clearImage;
    document.querySelector(`#company-form [name="${field}"]`).value = "";
    renderImagePreview(field, "");
  }));

  function renderSocials() {
    document.querySelector("#social-list").innerHTML = content.socials.map((social, index) => `
      <div class="social-row"><label class="visually-hidden" for="social-name-${index}">Nome da rede social</label><input id="social-name-${index}" data-social-name="${index}" value="${escapeHtml(social.name)}" maxlength="35" placeholder="Nome da rede"><label class="visually-hidden" for="social-url-${index}">Endereço da rede social</label><input id="social-url-${index}" data-social-url="${index}" type="url" value="${escapeHtml(social.url)}" placeholder="https://…"><button type="button" data-remove-social="${index}">Remover</button></div>`).join("")
      || `<p class="project-management-empty">Ainda não foram adicionadas redes sociais.</p>`;
  }

  document.querySelector("#add-social").addEventListener("click", () => {
    content.socials.push({ name: "", url: "" });
    renderSocials();
    document.querySelector(`#social-name-${content.socials.length - 1}`).focus();
  });
  document.querySelector("#social-list").addEventListener("click", (event) => {
    const remove = event.target.closest("[data-remove-social]");
    if (!remove) return;
    content.socials.splice(Number(remove.dataset.removeSocial), 1);
    renderSocials();
  });
  document.querySelector("#company-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const data = new FormData(form);
    const previous = clone({ company: content.company, contact: content.contact, socials: content.socials });
    const logo = safeImageSource(data.get("logo"));
    const heroImage = safeImageSource(data.get("heroImage"));
    if (data.get("logo").trim() && !logo) {
      notify("O logótipo deve ser uma imagem válida por URL HTTP/HTTPS ou carregada neste navegador.");
      return;
    }
    if (data.get("heroImage").trim() && !heroImage) {
      notify("O banner deve ser uma imagem válida por URL HTTP/HTTPS ou carregada neste navegador.");
      return;
    }
    const socials = [...document.querySelectorAll(".social-row")].map((row) => ({
      name: row.querySelector("[data-social-name]").value.trim(),
      url: row.querySelector("[data-social-url]").value.trim()
    })).filter((social) => social.name && social.url);
    if (socials.some((social) => !safeUrl(social.url) || !/^https?:/i.test(social.url))) {
      notify("Cada rede social deve ter um endereço HTTP ou HTTPS válido.");
      return;
    }
    const companyFields = ["name", "heroTitle", "heroDescription", "aboutLead", "aboutDescription", "mission", "values", "commitment", "servicesDescription", "portfolioDescription", "portfolioDisclaimer", "contactDescription"];
    companyFields.forEach((field) => { content.company[field] = String(data.get(field) || "").trim(); });
    content.company.logo = logo;
    content.company.heroImage = heroImage;
    content.company.brandColor = /^#[0-9a-f]{6}$/i.test(data.get("brandColor"))
      ? data.get("brandColor")
      : "#b9c9a5";
    content.company.reasons = [1, 2, 3].map((index) => ({
      title: String(data.get(`reasonTitle${index}`) || "").trim(),
      description: String(data.get(`reasonDescription${index}`) || "").trim()
    }));
    content.company.copy = { ...content.company.copy };
    document.querySelectorAll("[data-copy-field]").forEach((field) => {
      content.company.copy[field.dataset.copyField] = field.value.trim();
    });
    ["email", "phone", "address", "whatsapp"].forEach((field) => { content.contact[field] = String(data.get(field) || "").trim(); });
    content.socials = socials;
    if (persist()) {
      document.querySelector("#company-message").textContent = "Conteúdo guardado neste navegador.";
      updateAdminBrand();
      notify("Conteúdo institucional actualizado.");
    } else {
      content.company = previous.company;
      content.contact = previous.contact;
      content.socials = previous.socials;
      window.applyBrandTheme(previous.company.brandColor || "#b9c9a5");
    }
  });

  window.addEventListener("storage", (event) => {
    if (event.key !== contentKey) return;
    content = loadContent();
    renderProjectRows();
    renderServices();
    populateCompanyForm();
  });

  renderCopyFields();
  renderProjectRows();
  renderServices();
  populateCompanyForm();
})();
