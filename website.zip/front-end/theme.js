(() => {
  "use strict";

  function parseHex(value) {
    const normalized = /^#[0-9a-f]{6}$/i.test(value) ? value.slice(1) : "b9c9a5";
    return [0, 2, 4].map((offset) => Number.parseInt(normalized.slice(offset, offset + 2), 16));
  }

  function toHex(rgb) {
    return `#${rgb.map((channel) => Math.round(channel).toString(16).padStart(2, "0")).join("")}`;
  }

  function mix(first, second, amount) {
    const a = parseHex(first);
    const b = parseHex(second);
    return toHex(a.map((channel, index) => channel * (1 - amount) + b[index] * amount));
  }

  function luminance(hex) {
    const channels = parseHex(hex).map((channel) => {
      const value = channel / 255;
      return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
    });
    return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
  }

  function applyBrandTheme(color, target = document.documentElement) {
    const brand = /^#[0-9a-f]{6}$/i.test(color) ? color : "#b9c9a5";
    const deep = mix(brand, "#17211c", 0.76);
    const brightness = luminance(brand);
    const textColor = brightness > 0.38 ? "#17211c" : "#ffffff";
    const readableAccent = brightness > 0.48 ? mix(brand, "#17211c", 0.34) : brand;
    const accentOnDark = brightness > 0.48 ? readableAccent : mix(brand, "#ffffff", 0.55);
    const mutedBrand = brightness > 0.48 ? mix(brand, "#17211c", 0.28) : brand;
    const values = {
      "--brand": brand,
      "--accent": accentOnDark,
      "--brand-hover": readableAccent,
      "--brand-muted": mutedBrand,
      "--brand-focus": mutedBrand,
      "--brand-deep": deep,
      "--brand-contrast": textColor,
      "--dark": deep,
      "--paper": mix("#f5f3ee", brand, 0.12),
      "--section-bg": mix("#ebeae3", brand, 0.17),
      "--contact-bg": mix("#edede6", brand, 0.14),
      "--white": mix("#fffefa", brand, 0.06),
      "--line": mix("#deded5", brand, 0.19),
      "--admin-paper": mix("#f4f5f2", brand, 0.12),
      "--admin-card": mix("#ffffff", brand, 0.055),
      "--admin-line": mix("#e5e8e2", brand, 0.2),
      "--admin-soft": mix("#eff3ed", brand, 0.16),
      "--line": mix("#e5e8e2", brand, 0.2),
      "--soft-green": mix("#eff3ed", brand, 0.16),
      "--paper": mix("#f4f5f2", brand, 0.12),
      "--white": mix("#ffffff", brand, 0.055),
      "--admin-primary": brand,
      "--admin-primary-contrast": textColor,
      "--green": brand,
      "--green-dark": deep,
      "--admin-deep": deep,
      "--admin-active": mix(brand, "#17211c", 0.35),
      "--admin-eyebrow": mix(brand, "#17211c", 0.28)
    };
    Object.entries(values).forEach(([property, value]) => target.style.setProperty(property, value));
    return brand;
  }

  function extractLogoColor(source) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.crossOrigin = "anonymous";
      image.onerror = () => reject(new Error("Não foi possível ler o logótipo. Para extrair a cor, carregue o ficheiro em vez de usar um URL externo."));
      image.onload = () => {
        try {
          const canvas = document.createElement("canvas");
          canvas.width = 48;
          canvas.height = 48;
          const context = canvas.getContext("2d", { willReadFrequently: true });
          if (!context) throw new Error("Este navegador não permite analisar a imagem.");
          context.drawImage(image, 0, 0, canvas.width, canvas.height);
          const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
          const samples = [];
          for (let index = 0; index < pixels.length; index += 4) {
            const [red, green, blue, alpha] = pixels.slice(index, index + 4);
            if (alpha < 150) continue;
            const max = Math.max(red, green, blue);
            const min = Math.min(red, green, blue);
            const saturation = max === 0 ? 0 : (max - min) / max;
            if (max < 35 || min > 242 || saturation < 0.2) continue;
            samples.push([red, green, blue]);
          }
          if (!samples.length) throw new Error("Não foi possível detectar uma cor dominante. Escolha-a manualmente.");
          const average = samples.reduce((sum, rgb) => sum.map((channel, index) => channel + rgb[index]), [0, 0, 0])
            .map((channel) => channel / samples.length);
          resolve(toHex(average));
        } catch (error) {
          reject(error);
        }
      };
      image.src = source;
    });
  }

  window.applyBrandTheme = applyBrandTheme;
  window.extractLogoColor = extractLogoColor;
})();
