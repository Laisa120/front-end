(() => {
  "use strict";

  const contentKey = "empresa-site-content-v1";
  const legacyKey = "empresa-portfolio-preview-v1";
  const feedbackKey = "empresa-site-feedback-v1";
  const demoProjects = [
    { id: "demo-01", title: "Espaço de possibilidades", category: "Projecto 01", description: "Projecto ilustrativo. Substitua esta descrição por informação confirmada sobre o trabalho realizado, o seu âmbito e os resultados alcançados.", image: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1200&q=85", images: [], featured: true },
    { id: "demo-02", title: "Uma nova perspectiva", category: "Projecto 02", description: "Imagem e texto de demonstração. Adicione apenas projectos reais e imagens autorizadas pela empresa ou pelo cliente.", image: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=85", images: [], featured: true },
    { id: "demo-03", title: "Detalhes com propósito", category: "Projecto 03", description: "Conte aqui a história do projecto: o desafio, a solução executada e os resultados alcançados.", image: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=85", images: [], featured: false },
    { id: "demo-04", title: "Formas de colaborar", category: "Projecto 04", description: "Este conteúdo é apenas uma pré-visualização. Edite-o para reflectir os projectos e serviços verdadeiros.", image: "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=85", images: [], featured: false }
  ];
  const initialContent = {
    company: {
      name: "A sua empresa",
      heroTitle: "Ideias que ganham forma e propósito.",
      heroDescription: "Apresente aqui a essência da sua empresa e o valor que entrega aos seus clientes.",
      aboutLead: "Um espaço para contar a história da sua empresa — com autenticidade, clareza e foco no que a distingue.",
      aboutDescription: "Apresente a sua missão, experiência e compromisso com clientes e parceiros. Substitua este texto por informação confirmada sobre a empresa.",
      mission: "A sua missão", values: "Os seus valores", commitment: "O seu compromisso",
      logo: "",
      heroImage: "",
      brandColor: "#b9c9a5",
      gradientStart: "#ebeae3",
      gradientEnd: "#f5f3ee",
      gradientAngle: "135",
      heroSlides: [{
        title: "Ideias que ganham forma e propósito.",
        description: "Apresente aqui a essência da sua empresa e o valor que entrega aos seus clientes.",
        image: ""
      }],
      copy: {
        navAbout: "A empresa",
        navServices: "Serviços",
        navPortfolio: "Portfólio",
        navContact: "Contacto",
        navCta: "Fale connosco",
        heroPrimaryCta: "Conheça o nosso portfólio",
        heroSecondaryCta: "Solicitar orçamento",
        heroNote: "Conteúdo ilustrativo — personalize com os dados da empresa",
        scrollLabel: "DESCOBRIR",
        aboutEyebrow: "Quem somos",
        aboutTitle: "Uma empresa feita para fazer acontecer.",
        aboutLink: "Saiba mais sobre nós",
        statsNote: "Substitua os campos por dados reais.",
        servicesEyebrow: "O que fazemos",
        servicesTitle: "Serviços com intenção.",
        servicesNote: "Os serviços acima são campos de preenchimento, não serviços confirmados.",
        serviceCta: "Pedir informações",
        portfolioEyebrow: "Portfólio",
        portfolioTitle: "Trabalho que fala por si.",
        portfolioCta: "Tem um projecto em mente?",
        portfolioIndex: "PORTFÓLIO · ANGOLA",
        whyEyebrow: "Porque nós",
        whyTitle: "Excelência em cada detalhe.",
        whyDescription: "Partilhe os motivos reais pelos quais os clientes escolhem a sua empresa. Estes pontos são sugestões de estrutura, não afirmações sobre a empresa.",
        whyImageAlt: "Edifícios modernos vistos de baixo, imagem ilustrativa",
        whyImageCaption: "01 — VISÃO",
        contactEyebrow: "Vamos conversar",
        contactTitle: "O próximo passo começa com uma conversa.",
        footerIntro: "Uma apresentação digital à medida da sua empresa.",
        footerBack: "Voltar ao topo",
        footerCopyright: "Personalize antes de publicar.",
        footerInstitutional: "Angola · Informação institucional a configurar"
      },
      servicesDescription: "Adicione os serviços reais da empresa e explique como cada um pode ajudar os seus clientes.",
      portfolioDescription: "Uma selecção visual de projectos para mostrar a qualidade e o cuidado em cada detalhe.",
      portfolioDisclaimer: "Imagens e projectos ilustrativos. Substitua-os por trabalhos reais e autorizados da empresa.",
      contactDescription: "Conte-nos o que procura. Os dados de contacto da empresa devem ser configurados antes da publicação.",
      reasons: [
        { title: "Experiência comprovada", description: "Apresente a experiência e as competências da equipa." },
        { title: "Compromisso com qualidade", description: "Explique como assegura a qualidade do seu trabalho." },
        { title: "Relações de confiança", description: "Descreva a forma como trabalha com clientes e parceiros." }
      ]
    },
    contact: { email: "", phone: "", address: "Angola", whatsapp: "" },
    socials: [],
    categories: ["Projecto 01", "Projecto 02", "Projecto 03", "Projecto 04"],
    services: [
      { id: "service-01", title: "Nome do serviço", description: "Escreva uma descrição clara deste serviço e dos benefícios para o cliente." },
      { id: "service-02", title: "Nome do serviço", description: "Apresente aqui uma solução oferecida pela empresa, sem esquecer o que a torna útil." },
      { id: "service-03", title: "Nome do serviço", description: "Utilize este espaço para explicar o âmbito e as vantagens do serviço." }
    ],
    projects: demoProjects,
    videoAds: [],
    requests: []
  };

  let content = loadContent();
  let activeFilter = "Todos";
  let activeProject = null;
  let activeHeroSlide = 0;
  let activeVideoAd = 0;
  let activeVideoObjectUrl = "";
  let videoRenderVersion = 0;
  let heroAutoplayPaused = false;
  let heroAutoplayEnabled = true;
  const grid = document.querySelector("#project-grid");
  const filters = document.querySelector("#filters");
  const projectModal = document.querySelector("#project-modal");
  let toastTimer;

  function copy(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function loadContent() {
    try {
      const saved = localStorage.getItem(contentKey);
      if (saved) return normalizeContent(JSON.parse(saved));
      const legacy = localStorage.getItem(legacyKey);
      const initial = copy(initialContent);
      if (legacy) {
        const oldProjects = JSON.parse(legacy);
        if (Array.isArray(oldProjects)) initial.projects = oldProjects.map((project, index) => ({
          ...project,
          images: Array.isArray(project.images) ? project.images : [],
          featured: index < 2
        }));
      }
      return initial;
    } catch (error) {
      console.error("Não foi possível carregar o conteúdo guardado.", error);
      return copy(initialContent);
    }
  }

  function normalizeContent(value) {
    if (!value || typeof value !== "object") throw new Error("Formato de conteúdo inválido.");
    const base = copy(initialContent);
    return {
      ...base,
      ...value,
      company: {
        ...base.company, ...(value.company || {}),
        copy: { ...base.company.copy, ...(value.company?.copy || {}) },
        reasons: Array.isArray(value.company?.reasons) ? value.company.reasons : base.company.reasons,
        heroSlides: Array.isArray(value.company?.heroSlides) && value.company.heroSlides.length
          ? value.company.heroSlides
          : [{
            title: value.company?.heroTitle || base.company.heroTitle,
            description: value.company?.heroDescription || base.company.heroDescription,
            image: value.company?.heroImage || ""
          }]
      },
      contact: { ...base.contact, ...(value.contact || {}) },
      socials: Array.isArray(value.socials) ? value.socials : base.socials,
      categories: Array.isArray(value.categories) ? value.categories : base.categories,
      services: Array.isArray(value.services) ? value.services : base.services,
      projects: Array.isArray(value.projects) ? value.projects.map((project) => ({
        ...project,
        images: Array.isArray(project.images) ? project.images : [],
        featured: project.featured === true
      })) : base.projects,
      videoAds: Array.isArray(value.videoAds) ? value.videoAds : base.videoAds,
      requests: Array.isArray(value.requests) ? value.requests : []
    };
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);
  }

  function safeUrl(value) {
    try {
      const url = new URL(value, window.location.href);
      return ["http:", "https:", "data:"].includes(url.protocol) ? url.href : "";
    } catch {
      return "";
    }
  }

  function safeImageSource(value) {
    const source = String(value || "").trim();
    if (/^data:image\/(?:jpeg|png|webp|gif);base64,/i.test(source)) return source;
    const url = safeUrl(source);
    return url && /^https?:/i.test(url) ? url : "";
  }

  function parseVideoUrl(value) {
    try {
      const url = new URL(value);
      if (!["http:", "https:"].includes(url.protocol)) return null;
      const host = url.hostname.toLowerCase();
      if (["youtube.com", "www.youtube.com", "m.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com", "youtu.be"].includes(host)) {
        const id = host === "youtu.be"
          ? url.pathname.split("/").filter(Boolean)[0]
          : url.searchParams.get("v") || url.pathname.match(/\/(?:embed|shorts)\/([A-Za-z0-9_-]{11})/)?.[1];
        return id && /^[A-Za-z0-9_-]{11}$/.test(id)
          ? { type: "embed", src: `https://www.youtube-nocookie.com/embed/${id}` }
          : null;
      }
      if (["vimeo.com", "www.vimeo.com", "player.vimeo.com"].includes(host)) {
        const id = host === "player.vimeo.com"
          ? url.pathname.match(/^\/video\/(\d+)/)?.[1]
          : url.pathname.match(/^\/(\d+)/)?.[1];
        return id ? { type: "embed", src: `https://player.vimeo.com/video/${id}` } : null;
      }
      return /\.mp4$/i.test(url.pathname) ? { type: "file", src: url.href } : null;
    } catch {
      return null;
    }
  }

  function renderHeroCarousel() {
    const slides = content.company.heroSlides.length
      ? content.company.heroSlides
      : [{ title: content.company.heroTitle, description: content.company.heroDescription, image: content.company.heroImage }];
    activeHeroSlide = (activeHeroSlide + slides.length) % slides.length;
    const slide = slides[activeHeroSlide];
    const source = safeImageSource(slide.image);
    const image = document.querySelector(".hero-image");
    image.style.backgroundImage = source ? `url(${JSON.stringify(source)})` : "";
    image.setAttribute("aria-label", source ? `Imagem do banner: ${slide.title}` : "Imagem ilustrativa de arquitectura contemporânea");
    document.querySelector("#hero-title").textContent = slide.title || "";
    document.querySelector("#hero-description").textContent = slide.description || "";
    document.querySelector("#hero-indicators").innerHTML = slides.map((entry, index) =>
      `<button type="button" data-hero-slide-index="${index}" aria-label="Ver slide ${index + 1}" aria-current="${index === activeHeroSlide ? "true" : "false"}"></button>`
    ).join("");
    document.querySelectorAll("[data-hero-direction]").forEach((button) => {
      button.hidden = slides.length < 2;
    });
    document.querySelector("#hero-indicators").hidden = slides.length < 2;
  }

  async function renderVideoAds() {
    const renderVersion = ++videoRenderVersion;
    const validVideos = content.videoAds.map((video) => ({
      ...video,
      media: video.source === "device" && video.videoKey
        ? { type: "device", key: video.videoKey }
        : parseVideoUrl(video.url)
    })).filter((video) => video.media);
    const section = document.querySelector("#videos");
    const carousel = document.querySelector("#video-carousel");
    const controls = document.querySelector("#video-carousel-controls");
    if (activeVideoObjectUrl) {
      URL.revokeObjectURL(activeVideoObjectUrl);
      activeVideoObjectUrl = "";
    }
    section.hidden = validVideos.length === 0;
    document.querySelector('.main-nav a[href="#videos"]').hidden = validVideos.length === 0;
    activeVideoAd = validVideos.length ? activeVideoAd % validVideos.length : 0;
    if (!validVideos.length) {
      carousel.innerHTML = "";
      controls.hidden = true;
      return;
    }
    const video = validVideos[activeVideoAd];
    let media;
    if (video.media.type === "device") {
      try {
        const file = await window.videoMediaStorage.get(video.media.key);
        if (renderVersion !== videoRenderVersion) return;
        if (!(file instanceof Blob)) throw new Error(`O ficheiro do anúncio "${video.title}" já não está disponível neste navegador.`);
        activeVideoObjectUrl = URL.createObjectURL(file);
        media = `<video controls playsinline preload="metadata" aria-label="${escapeHtml(video.title)}"><source src="${escapeHtml(activeVideoObjectUrl)}" type="${escapeHtml(file.type || video.videoType || "video/mp4")}">O navegador não suporta a reprodução deste vídeo.</video>`;
      } catch (error) {
        if (renderVersion !== videoRenderVersion) return;
        console.error("Não foi possível carregar o vídeo guardado neste dispositivo.", error);
        carousel.innerHTML = `<p class="video-load-error">${escapeHtml(error.message || "Não foi possível carregar o vídeo guardado neste dispositivo.")}</p>`;
        controls.hidden = validVideos.length < 2;
        document.querySelector("#video-carousel-position").textContent = `${activeVideoAd + 1} / ${validVideos.length}`;
        return;
      }
    } else {
      media = video.media.type === "file"
        ? `<video controls playsinline preload="metadata" aria-label="${escapeHtml(video.title)}"><source src="${escapeHtml(video.media.src)}" type="video/mp4">O navegador não suporta a reprodução deste vídeo.</video>`
        : `<iframe src="${escapeHtml(video.media.src)}" title="${escapeHtml(video.title)}" loading="lazy" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`;
    }
    if (renderVersion !== videoRenderVersion) return;
    carousel.innerHTML = `<div class="video-player">${media}</div><div class="video-caption"><h3>${escapeHtml(video.title)}</h3>${video.description ? `<p>${escapeHtml(video.description)}</p>` : ""}</div>`;
    controls.hidden = validVideos.length < 2;
    document.querySelector("#video-carousel-position").textContent = `${activeVideoAd + 1} / ${validVideos.length}`;
  }

  function persistContent() {
    try {
      localStorage.setItem(contentKey, JSON.stringify(content));
      return true;
    } catch (error) {
      console.error("Não foi possível guardar o conteúdo neste navegador.", error);
      showToast("Não foi possível guardar as alterações neste navegador.");
      return false;
    }
  }

  function renderFilters() {
    const categoryList = ["Todos", ...new Set([
      ...content.categories,
      ...content.projects.map((project) => project.category).filter(Boolean)
    ])];
    if (!categoryList.includes(activeFilter)) activeFilter = "Todos";
    filters.innerHTML = categoryList.map((category) =>
      `<button class="filter-button" type="button" aria-pressed="${category === activeFilter}" data-filter="${escapeHtml(category)}">${escapeHtml(category)}</button>`
    ).join("");
  }

  function renderProjects() {
    const projectList = [...content.projects].sort((a, b) => Number(b.featured) - Number(a.featured));
    const visible = activeFilter === "Todos" ? projectList : projectList.filter((project) => project.category === activeFilter);
    grid.innerHTML = visible.length ? visible.map((project) => `
      <article class="project-card" tabindex="0" role="button" aria-label="Ver projecto: ${escapeHtml(project.title)}" data-project="${escapeHtml(project.id)}">
        <div class="project-image"><img src="${escapeHtml(safeUrl(project.image))}" alt="${escapeHtml(project.title)}" loading="lazy"><span class="project-overlay" aria-hidden="true">${project.featured ? "★" : "↗"}</span></div>
        <div class="project-meta"><span class="project-category">${escapeHtml(project.category)}</span><span class="project-year">${project.featured ? "DESTAQUE" : "PORTFÓLIO"}</span></div>
        <h3>${escapeHtml(project.title)}</h3>
      </article>`).join("") : `<div class="empty-projects"><p>Ainda não existem projectos nesta categoria.</p></div>`;
    renderFilters();
  }

  function renderServices() {
    const serviceGrid = document.querySelector("#service-grid");
    serviceGrid.innerHTML = content.services.map((service, index) => `
      <article class="service-card">
        <span class="service-number">${String(index + 1).padStart(2, "0")} / SERVIÇO</span><span class="service-icon" aria-hidden="true">${["↗", "✳", "⌁"][index % 3]}</span>
        <h3>${escapeHtml(service.title)}</h3><p>${escapeHtml(service.description)}</p>
        <a href="#contacto" class="service-link" aria-label="${escapeHtml(content.company.copy.serviceCta)} sobre ${escapeHtml(service.title)}">${escapeHtml(content.company.copy.serviceCta)} <span aria-hidden="true">→</span></a>
      </article>`).join("");
    document.querySelector("#services-note").hidden = content.services.length > 0;
    document.querySelector("#contact-service-options").innerHTML =
      `<option value="">Seleccione um serviço (opcional)</option>${content.services.map((service) =>
        `<option value="${escapeHtml(service.title)}">${escapeHtml(service.title)}</option>`
      ).join("")}<option value="Outro / ainda não sei">Outro / ainda não sei</option>`;
  }

  function applyContent() {
    const root = document.documentElement;
    window.applyBrandTheme(content.company.brandColor || "#b9c9a5", root);
    const gradientStart = /^#[0-9a-f]{6}$/i.test(content.company.gradientStart) ? content.company.gradientStart : "#ebeae3";
    const gradientEnd = /^#[0-9a-f]{6}$/i.test(content.company.gradientEnd) ? content.company.gradientEnd : "#f5f3ee";
    const gradientAngle = ["90", "135", "180"].includes(String(content.company.gradientAngle)) ? content.company.gradientAngle : "135";
    root.style.setProperty("--site-gradient", `linear-gradient(${gradientAngle}deg, ${gradientStart}, ${gradientEnd})`);
    document.querySelectorAll(".brand-logo").forEach((logo) => {
      const source = safeUrl(content.company.logo);
      logo.src = source;
      logo.hidden = !source;
      logo.closest(".brand-mark").classList.toggle("has-logo", Boolean(source));
    });
    document.querySelectorAll(".brand-monogram").forEach((monogram) => {
      monogram.textContent = (content.company.name || "A").trim().charAt(0).toLocaleUpperCase() || "A";
    });
    document.querySelectorAll("[data-company-name]").forEach((element) => {
      element.textContent = content.company.name || "A sua empresa";
    });
    document.querySelectorAll("[data-copy]").forEach((element) => {
      const key = element.dataset.copy;
      if (Object.prototype.hasOwnProperty.call(content.company.copy, key)) element.textContent = content.company.copy[key];
    });
    document.title = `${content.company.name || "A sua empresa"} — projectos e serviços`;
    document.querySelector('meta[name="description"]').content = content.company.heroDescription || "";
    document.querySelector('meta[property="og:title"]').content = document.title;
    document.querySelector('meta[name="theme-color"]').content = content.company.brandColor || "#b9c9a5";
    document.querySelectorAll(".brand[aria-label]").forEach((brand) => {
      brand.setAttribute("aria-label", `${content.company.name || "A sua empresa"} — início`);
    });
    renderHeroCarousel();
    document.querySelector("#about-lead").textContent = content.company.aboutLead;
    document.querySelector("#about-description").textContent = content.company.aboutDescription;
    document.querySelector("#mission-value").textContent = content.company.mission;
    document.querySelector("#values-value").textContent = content.company.values;
    document.querySelector("#commitment-value").textContent = content.company.commitment;
    document.querySelector("#services-description").textContent = content.company.servicesDescription;
    document.querySelector("#portfolio-description").textContent = content.company.portfolioDescription;
    document.querySelector("#portfolio-disclaimer").textContent = content.company.portfolioDisclaimer;
    document.querySelector("#contact-description").textContent = content.company.contactDescription;
    document.querySelector(".why-visual img").alt = content.company.copy.whyImageAlt;
    content.company.reasons.forEach((reason, index) => {
      const number = index + 1;
      const title = document.querySelector(`#reason-title-${number}`);
      if (title) title.textContent = reason.title;
      const description = document.querySelector(`#reason-description-${number}`);
      if (description) description.textContent = reason.description;
    });
    document.querySelector("#contact-email").textContent = content.contact.email || "A configurar";
    document.querySelector("#contact-phone").textContent = content.contact.phone || "A configurar";
    document.querySelector("#contact-address").textContent = content.contact.address || "A configurar";
    const whatsapp = document.querySelector(".whatsapp-float");
    const phoneDigits = (content.contact.whatsapp || "").replace(/\D/g, "");
    whatsapp.classList.toggle("is-unconfigured", !phoneDigits);
    whatsapp.href = phoneDigits ? `https://wa.me/${phoneDigits}` : "#contacto";
    whatsapp.title = phoneDigits ? "Contactar pelo WhatsApp" : "Número de WhatsApp por configurar";
    document.querySelector("#social-links").innerHTML = content.socials.map((social) => {
      const href = safeUrl(social.url);
      return href ? `<a href="${escapeHtml(href)}" target="_blank" rel="noopener noreferrer">${escapeHtml(social.name)} ↗</a>` : "";
    }).join("");
    renderServices();
    renderProjects();
    renderVideoAds();
  }

  function openModal(modal) {
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    modal.querySelector(".modal-close").focus();
  }

  function closeModal(modal) {
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    if (!document.querySelector(".modal.is-open")) document.body.classList.remove("modal-open");
  }

  function showToast(message) {
    const toast = document.querySelector("#toast");
    toast.textContent = message;
    toast.classList.add("is-visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 3200);
  }

  function showProject(project) {
    if (!project) return;
    activeProject = project;
    const detailImage = document.querySelector("#detail-image");
    detailImage.src = safeUrl(project.image);
    detailImage.alt = project.title;
    document.querySelector("#detail-category").textContent = project.category;
    document.querySelector("#modal-title").textContent = project.title;
    document.querySelector("#detail-description").textContent = project.description;
    const gallery = document.querySelector("#detail-gallery");
    const photos = [...new Set([project.image, ...(project.images || [])].filter(Boolean))];
    gallery.innerHTML = photos.length > 1 ? photos.map((photo, index) =>
      `<button type="button" class="detail-thumb${index === 0 ? " is-selected" : ""}" data-photo="${escapeHtml(safeUrl(photo))}" aria-label="Ver fotografia ${index + 1}"><img src="${escapeHtml(safeUrl(photo))}" alt=""></button>`
    ).join("") : "";
    openModal(projectModal);
  }

  document.querySelector(".hero-carousel-controls").addEventListener("click", (event) => {
    const toggle = event.target.closest("[data-hero-toggle]");
    const direction = event.target.closest("[data-hero-direction]");
    const indicator = event.target.closest("[data-hero-slide-index]");
    const length = content.company.heroSlides.length || 1;
    if (toggle) {
      heroAutoplayEnabled = !heroAutoplayEnabled;
      toggle.setAttribute("aria-pressed", String(heroAutoplayEnabled));
      toggle.setAttribute("aria-label", heroAutoplayEnabled ? "Pausar rotação do banner" : "Retomar rotação do banner");
      toggle.textContent = heroAutoplayEnabled ? "Pausar" : "Retomar";
    }
    if (direction) activeHeroSlide = (activeHeroSlide + Number(direction.dataset.heroDirection) + length) % length;
    if (indicator) activeHeroSlide = Number(indicator.dataset.heroSlideIndex);
    renderHeroCarousel();
  });
  const hero = document.querySelector(".hero");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  if (reducedMotion.matches) {
    heroAutoplayEnabled = false;
    const toggle = document.querySelector("[data-hero-toggle]");
    toggle.setAttribute("aria-pressed", "false");
    toggle.setAttribute("aria-label", "Retomar rotação do banner");
    toggle.textContent = "Retomar";
  }
  hero.addEventListener("mouseenter", () => { heroAutoplayPaused = true; });
  hero.addEventListener("mouseleave", () => { heroAutoplayPaused = false; });
  hero.addEventListener("focusin", () => { heroAutoplayPaused = true; });
  hero.addEventListener("focusout", (event) => {
    if (!hero.contains(event.relatedTarget)) heroAutoplayPaused = false;
  });
  window.setInterval(() => {
    if (!heroAutoplayEnabled || heroAutoplayPaused || document.hidden || reducedMotion.matches || content.company.heroSlides.length < 2) return;
    activeHeroSlide = (activeHeroSlide + 1) % content.company.heroSlides.length;
    renderHeroCarousel();
  }, 6000);
  document.querySelector("#video-carousel-controls").addEventListener("click", (event) => {
    const button = event.target.closest("[data-video-direction]");
    if (!button) return;
    const count = content.videoAds.filter((video) =>
      video.source === "device" ? Boolean(video.videoKey) : Boolean(parseVideoUrl(video.url))
    ).length;
    if (!count) return;
    activeVideoAd = (activeVideoAd + Number(button.dataset.videoDirection) + count) % count;
    renderVideoAds();
  });

  filters.addEventListener("click", (event) => {
    const button = event.target.closest("[data-filter]");
    if (!button) return;
    activeFilter = button.dataset.filter;
    renderProjects();
  });

  grid.addEventListener("click", (event) => {
    const card = event.target.closest("[data-project]");
    if (card) showProject(content.projects.find((project) => project.id === card.dataset.project));
  });

  grid.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" && event.key !== " ") return;
    const card = event.target.closest("[data-project]");
    if (!card) return;
    event.preventDefault();
    showProject(content.projects.find((project) => project.id === card.dataset.project));
  });

  document.querySelectorAll("[data-close-modal]").forEach((element) => {
    element.addEventListener("click", () => closeModal(element.closest(".modal")));
  });
  document.querySelector("#detail-gallery").addEventListener("click", (event) => {
    const button = event.target.closest("[data-photo]");
    if (!button) return;
    document.querySelector("#detail-image").src = button.dataset.photo;
    document.querySelectorAll(".detail-thumb").forEach((thumbnail) => thumbnail.classList.toggle("is-selected", thumbnail === button));
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") document.querySelectorAll(".modal.is-open").forEach(closeModal);
  });
  document.querySelector("#share-project").addEventListener("click", async () => {
    if (!activeProject) return;
    const shareData = { title: activeProject.title, text: activeProject.title, url: window.location.href.split("#")[0] };
    try {
      if (navigator.share) await navigator.share(shareData);
      else if (navigator.clipboard) {
        await navigator.clipboard.writeText(`${shareData.text}: ${shareData.url}`);
        showToast("Ligação copiada para a área de transferência.");
      } else showToast("A partilha não está disponível neste navegador.");
    } catch (error) {
      if (error.name !== "AbortError") {
        console.error("Não foi possível partilhar o projecto.", error);
        showToast("Não foi possível partilhar o projecto.");
      }
    }
  });
  document.querySelector("#project-contact").addEventListener("click", () => {
    if (!activeProject) return;
    document.querySelector("#contact-form").elements.message.value =
      `Tenho interesse num serviço semelhante ao projecto "${activeProject.title}".`;
    closeModal(projectModal);
  });
  document.querySelector("#contact-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const status = document.querySelector("#form-status");
    if (!form.reportValidity()) return;
    status.classList.add("error");
    status.textContent = "A solicitação não foi enviada: não existe um serviço de envio configurado. Contacte a empresa pelos canais oficiais, quando disponíveis.";
    showToast("Envio indisponível: configure um serviço de contacto.");
  });
  document.querySelector("#feedback-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const status = document.querySelector("#feedback-status");
    if (!form.reportValidity()) return;

    try {
      const saved = localStorage.getItem(feedbackKey);
      const feedbacks = saved ? JSON.parse(saved) : [];
      if (!Array.isArray(feedbacks)) throw new Error("Formato de avaliações inválido.");
      const data = new FormData(form);
      const name = String(data.get("name")).trim();
      const message = String(data.get("message")).trim();
      const rating = Number(data.get("rating"));
      if (!name || !message || !Number.isInteger(rating) || rating < 1 || rating > 5) {
        status.classList.add("error");
        status.textContent = "Preencha o nome, o feedback e uma avaliação válida de uma a cinco estrelas.";
        return;
      }
      feedbacks.push({
        id: window.crypto?.randomUUID ? window.crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        name,
        message,
        rating,
        createdAt: new Date().toISOString()
      });
      localStorage.setItem(feedbackKey, JSON.stringify(feedbacks));
      form.reset();
      status.classList.remove("error");
      status.textContent = "Obrigado! A sua avaliação foi guardada e está disponível na área de gestão deste navegador.";
    } catch (error) {
      console.error("Não foi possível guardar a avaliação neste navegador.", error);
      status.classList.add("error");
      status.textContent = "Não foi possível guardar a avaliação. Verifique o espaço disponível no navegador e tente novamente.";
    }
  });
  document.querySelector(".whatsapp-float").addEventListener("click", (event) => {
    if (content.contact.whatsapp) return;
    event.preventDefault();
    document.querySelector("#contacto").scrollIntoView({ behavior: "smooth" });
    showToast("Configure o número oficial da empresa para activar o WhatsApp.");
  });
  window.addEventListener("storage", (event) => {
    if (event.key !== contentKey) return;
    content = loadContent();
    applyContent();
  });
  document.querySelector("#year").textContent = new Date().getFullYear();
  applyContent();
})();
