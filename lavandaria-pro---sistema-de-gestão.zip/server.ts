import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("lavanderia.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS lavandarias (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    nome_comercial TEXT,
    endereco TEXT,
    telefone TEXT,
    email TEXT,
    nif TEXT,
    registo_comercial TEXT,
    tipo_empresa TEXT,
    data_constituicao TEXT,
    regime_fiscal TEXT,
    percentagem_iva REAL,
    sujeito_retencao INTEGER DEFAULT 0,
    conta_bancaria TEXT,
    iban TEXT,
    banco TEXT,
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    senha TEXT NOT NULL,
    role TEXT NOT NULL,
    telefone TEXT
  );

  CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT NOT NULL,
    email TEXT,
    endereco TEXT,
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    data DATETIME DEFAULT CURRENT_TIMESTAMP,
    status TEXT DEFAULT 'recebido',
    tipo_servico TEXT,
    total REAL DEFAULT 0,
    pago INTEGER DEFAULT 0,
    prazo_entrega DATETIME,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
  );

  CREATE TABLE IF NOT EXISTS itens_pedido (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pedido_id INTEGER NOT NULL,
    tipo_peca TEXT NOT NULL,
    servico TEXT NOT NULL,
    preco REAL NOT NULL,
    quantidade INTEGER DEFAULT 1,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id)
  );

  CREATE TABLE IF NOT EXISTS estoque (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    produto TEXT NOT NULL,
    quantidade REAL DEFAULT 0,
    unidade TEXT NOT NULL,
    minimo_alerta REAL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS vendas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pedido_id INTEGER NOT NULL,
    forma_pagamento TEXT NOT NULL,
    valor_pago REAL NOT NULL,
    desconto REAL DEFAULT 0,
    data_pagamento DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id)
  );

  CREATE TABLE IF NOT EXISTS servicos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    preco REAL NOT NULL,
    categoria TEXT DEFAULT 'Geral'
  );
`);

// Seed default admin if not exists
const adminExists = db.prepare("SELECT id FROM usuarios WHERE role = 'admin'").get();
if (!adminExists) {
  db.prepare("INSERT INTO usuarios (nome, email, senha, role) VALUES (?, ?, ?, ?)").run(
    "Administrador",
    "admin@lavanderia.com",
    "admin123", // In a real app, hash this
    "admin"
  );
}

// Seed cashier manager if not exists
const cashierExists = db.prepare("SELECT id FROM usuarios WHERE email = ?").get("caixa@lavanderia.com");
if (!cashierExists) {
  db.prepare("INSERT INTO usuarios (nome, email, senha, role) VALUES (?, ?, ?, ?)").run(
    "Gerente de Caixa",
    "caixa@lavanderia.com",
    "caixa123",
    "gerente_caixa"
  );
}

// Seed some initial stock items if empty
const stockCount = db.prepare("SELECT COUNT(*) as count FROM estoque").get() as { count: number };
if (stockCount.count === 0) {
  const insertStock = db.prepare("INSERT INTO estoque (produto, quantidade, unidade, minimo_alerta) VALUES (?, ?, ?, ?)");
  insertStock.run("Sabão em Pó", 50, "kg", 10);
  insertStock.run("Amaciante", 30, "L", 5);
  insertStock.run("Detergente Neutro", 20, "L", 5);
  insertStock.run("Cabides", 500, "un", 100);
}

// Seed initial services if empty
const servicosCount = db.prepare("SELECT COUNT(*) as count FROM servicos").get() as { count: number };
if (servicosCount.count === 0) {
  const insertServico = db.prepare("INSERT INTO servicos (nome, preco, categoria) VALUES (?, ?, ?)");
  insertServico.run("Camisa", 15.00, "Vestuário");
  insertServico.run("Calça", 18.00, "Vestuário");
  insertServico.run("Terno", 45.00, "Vestuário");
  insertServico.run("Vestido", 35.00, "Vestuário");
  insertServico.run("Casaco", 40.00, "Vestuário");
  insertServico.run("Edredom Solteiro", 40.00, "Cama/Banho");
  insertServico.run("Edredom Casal", 60.00, "Cama/Banho");
  insertServico.run("Toalha", 8.00, "Cama/Banho");
  insertServico.run("Lençol", 12.00, "Cama/Banho");
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API ROUTES ---

  // Registration
  app.post("/api/register-lavandaria", (req, res) => {
    const { 
      lavandariaNome, lavandariaNomeComercial, lavandariaEndereco, lavandariaTelefone, 
      lavandariaEmail, lavandariaNif, lavandariaRegistoComercial, lavandariaTipoEmpresa, 
      lavandariaDataConstituicao, lavandariaRegimeFiscal, lavandariaPercentagemIva, 
      lavandariaSujeitoRetencao, lavandariaContaBancaria, lavandariaIban, lavandariaBanco,
      adminNome, adminEmail, adminSenha 
    } = req.body;

    const transaction = db.transaction(() => {
      // 1. Create Laundry
      const lavResult = db.prepare(`
        INSERT INTO lavandarias (
          nome, nome_comercial, endereco, telefone, email, nif, 
          registo_comercial, tipo_empresa, data_constituicao,
          regime_fiscal, percentagem_iva, sujeito_retencao,
          conta_bancaria, iban, banco
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        lavandariaNome, lavandariaNomeComercial, lavandariaEndereco, lavandariaTelefone, 
        lavandariaEmail, lavandariaNif, lavandariaRegistoComercial, lavandariaTipoEmpresa, 
        lavandariaDataConstituicao, lavandariaRegimeFiscal, lavandariaPercentagemIva, 
        lavandariaSujeitoRetencao ? 1 : 0, lavandariaContaBancaria, lavandariaIban, lavandariaBanco
      );
      
      // 2. Create Admin User
      const userResult = db.prepare("INSERT INTO usuarios (nome, email, senha, role) VALUES (?, ?, ?, ?)").run(
        adminNome, adminEmail, adminSenha, 'admin'
      );

      return { userId: userResult.lastInsertRowid };
    });

    try {
      const result = transaction();
      const user = db.prepare("SELECT id, nome, email, role FROM usuarios WHERE id = ?").get(result.userId);
      res.json(user);
    } catch (err: any) {
      if (err.message.includes("UNIQUE constraint failed: usuarios.email")) {
        res.status(400).json({ error: "Este e-mail de administrador já está em uso." });
      } else {
        res.status(500).json({ error: "Erro ao realizar cadastro." });
      }
    }
  });

  // Auth
  app.post("/api/login", (req, res) => {
    const { email, senha } = req.body;
    const user = db.prepare("SELECT id, nome, email, role FROM usuarios WHERE email = ? AND senha = ?").get(email, senha);
    if (user) {
      res.json(user);
    } else {
      res.status(401).json({ error: "Credenciais inválidas" });
    }
  });

  app.post("/api/recover-password", (req, res) => {
    const { email } = req.body;
    const user = db.prepare("SELECT id FROM usuarios WHERE email = ?").get(email);
    if (user) {
      // In a real app, send an email here
      console.log(`Password recovery requested for: ${email}`);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "E-mail não encontrado" });
    }
  });

  // Lavandarias
  app.get("/api/lavandarias", (req, res) => {
    const lavandarias = db.prepare("SELECT * FROM lavandarias ORDER BY nome ASC").all();
    res.json(lavandarias);
  });

  app.post("/api/lavandarias", (req, res) => {
    const { 
      nome, nome_comercial, endereco, telefone, email, nif, 
      registo_comercial, tipo_empresa, data_constituicao,
      regime_fiscal, percentagem_iva, sujeito_retencao,
      conta_bancaria, iban, banco
    } = req.body;
    const result = db.prepare(`
      INSERT INTO lavandarias (
        nome, nome_comercial, endereco, telefone, email, nif, 
        registo_comercial, tipo_empresa, data_constituicao,
        regime_fiscal, percentagem_iva, sujeito_retencao,
        conta_bancaria, iban, banco
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      nome, nome_comercial, endereco, telefone, email, nif, 
      registo_comercial, tipo_empresa, data_constituicao,
      regime_fiscal, percentagem_iva, sujeito_retencao ? 1 : 0,
      conta_bancaria, iban, banco
    );
    res.json({ id: result.lastInsertRowid });
  });

  // Clientes
  app.get("/api/clientes", (req, res) => {
    const clientes = db.prepare("SELECT * FROM clientes ORDER BY nome ASC").all();
    res.json(clientes);
  });

  app.post("/api/clientes", (req, res) => {
    const { nome, telefone, email, endereco } = req.body;
    const result = db.prepare("INSERT INTO clientes (nome, telefone, email, endereco) VALUES (?, ?, ?, ?)").run(nome, telefone, email, endereco);
    res.json({ id: result.lastInsertRowid });
  });

  // Pedidos
  app.get("/api/pedidos", (req, res) => {
    const pedidos = db.prepare(`
      SELECT p.*, c.nome as cliente_nome 
      FROM pedidos p 
      JOIN clientes c ON p.cliente_id = c.id 
      ORDER BY p.data DESC
    `).all();
    res.json(pedidos);
  });

  app.get("/api/pedidos/:id", (req, res) => {
    const pedido = db.prepare(`
      SELECT p.*, c.nome as cliente_nome 
      FROM pedidos p 
      JOIN clientes c ON p.cliente_id = c.id 
      WHERE p.id = ?
    `).get(req.params.id);
    
    if (!pedido) return res.status(404).json({ error: "Pedido não encontrado" });

    const itens = db.prepare("SELECT * FROM itens_pedido WHERE pedido_id = ?").all(req.params.id);
    res.json({ ...pedido, itens });
  });

  app.post("/api/pedidos", (req, res) => {
    const { cliente_id, prazo_entrega, itens, tipo_servico } = req.body;
    
    const transaction = db.transaction(() => {
      const pedidoResult = db.prepare("INSERT INTO pedidos (cliente_id, prazo_entrega, tipo_servico) VALUES (?, ?, ?)").run(cliente_id, prazo_entrega, tipo_servico);
      const pedidoId = pedidoResult.lastInsertRowid;
      
      let total = 0;
      const insertItem = db.prepare("INSERT INTO itens_pedido (pedido_id, tipo_peca, servico, preco, quantidade) VALUES (?, ?, ?, ?, ?)");
      
      for (const item of itens) {
        insertItem.run(pedidoId, item.tipo_peca, item.servico, item.preco, item.quantidade || 1);
        total += item.preco * (item.quantidade || 1);
      }
      
      db.prepare("UPDATE pedidos SET total = ? WHERE id = ?").run(total, pedidoId);
      return pedidoId;
    });

    try {
      const id = transaction();
      res.json({ id });
    } catch (err) {
      res.status(500).json({ error: "Erro ao criar pedido" });
    }
  });

  app.patch("/api/pedidos/:id/status", (req, res) => {
    const { status } = req.body;
    db.prepare("UPDATE pedidos SET status = ? WHERE id = ?").run(status, req.params.id);
    res.json({ success: true });
  });

  // Vendas / Pagamentos
  app.get("/api/vendas", (req, res) => {
    const vendas = db.prepare(`
      SELECT v.*, p.total, p.data as data_pedido, c.nome as cliente_nome 
      FROM vendas v
      JOIN pedidos p ON v.pedido_id = p.id
      JOIN clientes c ON p.cliente_id = c.id
      ORDER BY v.data_pagamento DESC
    `).all();
    res.json(vendas);
  });

  app.post("/api/vendas", (req, res) => {
    const { pedido_id, forma_pagamento, valor_pago, desconto } = req.body;
    
    const transaction = db.transaction(() => {
      db.prepare("INSERT INTO vendas (pedido_id, forma_pagamento, valor_pago, desconto) VALUES (?, ?, ?, ?)").run(pedido_id, forma_pagamento, valor_pago, desconto || 0);
      db.prepare("UPDATE pedidos SET pago = 1 WHERE id = ?").run(pedido_id);
    });

    try {
      transaction();
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Erro ao registrar venda" });
    }
  });

  // Servicos
  app.get("/api/servicos", (req, res) => {
    const servicos = db.prepare("SELECT * FROM servicos ORDER BY nome ASC").all();
    res.json(servicos);
  });

  app.post("/api/servicos", (req, res) => {
    const { nome, preco, categoria } = req.body;
    const result = db.prepare("INSERT INTO servicos (nome, preco, categoria) VALUES (?, ?, ?)").run(nome, preco, categoria || 'Geral');
    res.json({ id: result.lastInsertRowid });
  });

  app.delete("/api/servicos/:id", (req, res) => {
    db.prepare("DELETE FROM servicos WHERE id = ?").run(req.params.id);
    res.json({ success: true });
  });

  // Estoque
  app.get("/api/estoque", (req, res) => {
    const estoque = db.prepare("SELECT * FROM estoque").all();
    res.json(estoque);
  });

  app.patch("/api/estoque/:id", (req, res) => {
    const { quantidade } = req.body;
    db.prepare("UPDATE estoque SET quantidade = ? WHERE id = ?").run(quantidade, req.params.id);
    res.json({ success: true });
  });

  // Relatórios
  app.get("/api/relatorios/vendas", (req, res) => {
    const { periodo } = req.query; // 'dia', 'mes'
    let query = "";
    if (periodo === 'dia') {
      query = "SELECT SUM(valor_pago) as total FROM vendas WHERE date(data_pagamento) = date('now')";
    } else {
      query = "SELECT SUM(valor_pago) as total FROM vendas WHERE strftime('%m', data_pagamento) = strftime('%m', 'now')";
    }
    const result = db.prepare(query).get();
    res.json(result);
  });

  app.get("/api/relatorios/stats", (req, res) => {
    const totalVendas = db.prepare("SELECT SUM(valor_pago) as total FROM vendas").get();
    const totalPedidos = db.prepare("SELECT COUNT(*) as count FROM pedidos").get();
    const pedidosAbertos = db.prepare("SELECT COUNT(*) as count FROM pedidos WHERE status != 'entregue' AND status != 'cancelado'").get();
    const estoqueBaixo = db.prepare("SELECT COUNT(*) as count FROM estoque WHERE quantidade <= minimo_alerta").get();
    
    res.json({
      totalVendas: totalVendas.total || 0,
      totalPedidos: totalPedidos.count,
      pedidosAbertos: pedidosAbertos.count,
      estoqueBaixo: estoqueBaixo.count
    });
  });

  // --- VITE MIDDLEWARE ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
