import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Shirt, 
  Package, 
  BarChart3, 
  LogOut,
  Menu,
  X,
  Bell,
  Search,
  ChevronRight,
  ReceiptText,
  Building2,
  List
} from 'lucide-react';
import { Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { User } from './types';

// Pages
import Dashboard from './pages/Dashboard';
import Clientes from './pages/Clientes';
import Pedidos from './pages/Pedidos';
import Estoque from './pages/Estoque';
import Relatorios from './pages/Relatorios';
import NovoPedido from './pages/NovoPedido';
import Login from './pages/Login';
import Register from './pages/Register';
import Faturacao from './pages/Faturacao';
import Lavandarias from './pages/Lavandarias';
import LandingPage from './pages/LandingPage';
import Servicos from './pages/Servicos';

const SidebarItem = ({ icon: Icon, label, to, active, onClick }: { icon: any, label: string, to: string, active: boolean, onClick?: () => void, key?: string }) => (
  <Link 
    to={to} 
    onClick={onClick}
    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
      active 
        ? 'bg-primary text-white shadow-lg shadow-primary/20' 
        : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900'
    }`}
  >
    <Icon size={20} />
    <span className="font-medium">{label}</span>
  </Link>
);

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUser(null);
    navigate('/');
  };

  if (!user) {
    return (
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<Login onLogin={(u) => { setUser(u); localStorage.setItem('user', JSON.stringify(u)); navigate('/'); }} />} />
        <Route path="/register" element={<Register onRegister={(u) => { setUser(u); localStorage.setItem('user', JSON.stringify(u)); navigate('/'); }} />} />
        <Route path="*" element={<LandingPage />} />
      </Routes>
    );
  }

  const menuItems = [
    ...(user.role !== 'gerente_caixa' ? [{ icon: LayoutDashboard, label: 'Dashboard', to: '/' }] : []),
    { icon: List, label: 'Serviços', to: '/servicos' },
    { icon: Users, label: 'Clientes', to: '/clientes' },
    ...(user.role !== 'admin' ? [{ icon: ReceiptText, label: 'Faturação', to: '/faturacao' }] : []),
    ...(user.role === 'admin' ? [{ icon: Building2, label: 'Perfil da Lavandaria', to: '/lavandarias' }] : []),
    { icon: Package, label: 'Estoque', to: '/estoque' },
    { icon: BarChart3, label: 'Relatórios', to: '/relatorios' },
  ];

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-slate-200 transform transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="h-full flex flex-col p-6">
          <div className="flex items-center gap-3 mb-10 px-2">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold text-xl">
              L
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">Lavanderia<span className="text-accent">Pro</span></h1>
          </div>

          <nav className="flex-1 space-y-2 overflow-y-auto">
            {menuItems.map((item) => (
              <SidebarItem 
                key={item.to}
                icon={item.icon}
                label={item.label}
                to={item.to}
                active={location.pathname === item.to}
                onClick={() => setIsSidebarOpen(false)}
              />
            ))}
          </nav>

          <div className="pt-6 border-t border-slate-100 mt-auto">
            <div className="flex items-center gap-3 px-2 mb-6">
              <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-semibold shrink-0">
                {user.nome.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-900 truncate">{user.nome}</p>
                <p className="text-xs text-slate-500 capitalize">
                  {user.role === 'gerente_caixa' ? 'Gerente de Caixa' : user.role}
                </p>
              </div>
            </div>
            <button 
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-colors"
            >
              <LogOut size={20} />
              <span className="font-medium">Sair</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden pb-16 lg:pb-0">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 shrink-0">
          <div className="flex items-center gap-2 sm:gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="p-2 text-slate-500 hover:bg-slate-100 rounded-lg lg:hidden"
            >
              <Menu size={24} />
            </button>
            <div className="relative hidden sm:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Buscar..."
                className="pl-10 pr-4 py-2 bg-slate-100 border-none rounded-full text-sm w-32 md:w-64 focus:ring-2 focus:ring-primary/20 transition-all"
              />
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-3">
            <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-2 p-2 text-slate-500 hover:bg-red-50 hover:text-red-500 rounded-full transition-all"
              title="Sair do Sistema"
            >
              <LogOut size={20} />
            </button>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto p-4 lg:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="max-w-7xl mx-auto"
            >
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/clientes" element={<Clientes />} />
                <Route path="/pedidos" element={<Pedidos />} />
                <Route path="/pedidos/novo" element={<NovoPedido />} />
                <Route path="/servicos" element={<Servicos />} />
                <Route path="/faturacao" element={<Faturacao user={user} />} />
                <Route path="/lavandarias" element={<Lavandarias />} />
                <Route path="/estoque" element={<Estoque />} />
                <Route path="/relatorios" element={<Relatorios />} />
              </Routes>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Mobile Bottom Navigation */}
        <nav className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 flex items-center justify-around px-2 py-2 z-40">
          {menuItems.slice(0, 5).map((item) => {
            const active = location.pathname === item.to;
            return (
              <Link 
                key={item.to}
                to={item.to}
                className={`flex flex-col items-center gap-1 px-3 py-1 rounded-lg transition-colors ${
                  active ? 'text-primary' : 'text-slate-400'
                }`}
              >
                <item.icon size={20} />
                <span className="text-[10px] font-bold uppercase tracking-tighter">{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </main>
    </div>
  );
}
