import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Download, 
  Calendar, 
  TrendingUp, 
  DollarSign, 
  PieChart,
  ChevronDown
} from 'lucide-react';

export default function Relatorios() {
  const [stats, setStats] = useState<any>(null);
  const [vendaDia, setVendaDia] = useState<any>(null);
  const [vendaMes, setVendaMes] = useState<any>(null);

  useEffect(() => {
    fetch('/api/relatorios/stats').then(res => res.json()).then(setStats);
    fetch('/api/relatorios/vendas?periodo=dia').then(res => res.json()).then(setVendaDia);
    fetch('/api/relatorios/vendas?periodo=mes').then(res => res.json()).then(setVendaMes);
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Relatórios</h2>
          <p className="text-slate-500">Análise financeira e desempenho operacional.</p>
        </div>
        <button className="bg-primary hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-primary/20">
          <Download size={20} />
          Exportar CSV
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 rounded-xl bg-emerald-100 text-emerald-600">
              <DollarSign size={24} />
            </div>
            <span className="text-xs font-bold text-emerald-500 bg-emerald-50 px-2 py-1 rounded-lg">+15%</span>
          </div>
          <p className="text-sm font-medium text-slate-500 mb-1">Vendas Hoje</p>
          <h3 className="text-3xl font-black text-slate-900">{vendaDia?.total?.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }) || (0).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</h3>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 rounded-xl bg-indigo-100 text-indigo-600">
              <TrendingUp size={24} />
            </div>
            <span className="text-xs font-bold text-indigo-500 bg-indigo-50 px-2 py-1 rounded-lg">+22%</span>
          </div>
          <p className="text-sm font-medium text-slate-500 mb-1">Vendas este Mês</p>
          <h3 className="text-3xl font-black text-slate-900">{vendaMes?.total?.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }) || (0).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</h3>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
          <div className="flex items-center justify-between mb-4">
            <div className="p-3 rounded-xl bg-amber-100 text-amber-600">
              <PieChart size={24} />
            </div>
          </div>
          <p className="text-sm font-medium text-slate-500 mb-1">Ticket Médio</p>
          <h3 className="text-3xl font-black text-slate-900">
            {stats?.totalPedidos ? (stats.totalVendas / stats.totalPedidos).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }) : (0).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
          </h3>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 card-shadow">
          <div className="flex items-center justify-between mb-8">
            <h3 className="font-bold text-slate-900 text-lg">Desempenho Mensal</h3>
            <button className="flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-900">
              Este Ano <ChevronDown size={16} />
            </button>
          </div>
          <div className="h-64 flex items-end justify-between gap-2">
            {[40, 65, 45, 90, 55, 70, 85, 60, 75, 50, 65, 80].map((h, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-2 group">
                <div 
                  className="w-full bg-slate-100 group-hover:bg-primary transition-all rounded-t-lg relative"
                  style={{ height: `${h}%` }}
                >
                  <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                    {(h * 100).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                  </div>
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase">{['J','F','M','A','M','J','J','A','S','O','N','D'][i]}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 card-shadow">
          <h3 className="font-bold text-slate-900 text-lg mb-8">Serviços Mais Procurados</h3>
          <div className="space-y-6">
            {[
              { label: 'Lavagem de Camisas', value: 45, color: 'bg-indigo-500' },
              { label: 'Limpeza de Edredons', value: 30, color: 'bg-emerald-500' },
              { label: 'Lavagem a Seco', value: 15, color: 'bg-amber-500' },
              { label: 'Outros', value: 10, color: 'bg-slate-300' }
            ].map((item, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between text-sm font-semibold">
                  <span className="text-slate-700">{item.label}</span>
                  <span className="text-slate-900">{item.value}%</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${item.color} rounded-full`}
                    style={{ width: `${item.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
