import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Trash2, 
  Printer, 
  ShoppingCart, 
  User as UserIcon,
  FileText,
  DollarSign,
  ChevronRight,
  Minus,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Cliente, Lavandaria } from '../types';

interface Servico {
  id: number;
  nome: string;
  preco: number;
  categoria: string;
}

interface ItemFatura {
  id: string;
  servicoId: number;
  nome: string;
  preco: number;
  quantidade: number;
}

export default function Faturacao({ user }: { user: User }) {
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [lavandaria, setLavandaria] = useState<Lavandaria | null>(null);
  
  const [searchServico, setSearchServico] = useState('');
  const [selectedCliente, setSelectedCliente] = useState<Cliente | null>(null);
  const [itens, setItens] = useState<ItemFatura[]>([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [showMobileCart, setShowMobileCart] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [serie, setSerie] = useState('2024');
  const [date, setDate] = useState(new Date().toLocaleDateString('pt-PT'));

  useEffect(() => {
    fetchData();
    setInvoiceNumber(`FT-${Math.floor(1000 + Math.random() * 9000)}`);
  }, []);

  const fetchData = async () => {
    try {
      const [servRes, cliRes, lavRes] = await Promise.all([
        fetch('/api/servicos'),
        fetch('/api/clientes'),
        fetch('/api/lavandarias')
      ]);
      
      const [servData, cliData, lavData] = await Promise.all([
        servRes.json(),
        cliRes.json(),
        lavRes.json()
      ]);
      
      setServicos(servData);
      setClientes(cliData);
      if (lavData.length > 0) setLavandaria(lavData[0]);
    } catch (error) {
      console.error('Erro ao buscar dados:', error);
    }
  };

  const adicionarItem = (servico: Servico) => {
    const itemExistente = itens.find(item => item.servicoId === servico.id);
    
    if (itemExistente) {
      setItens(itens.map(item => 
        item.servicoId === servico.id 
          ? { ...item, quantidade: item.quantidade + 1 } 
          : item
      ));
    } else {
      setItens([...itens, {
        id: Math.random().toString(36).substr(2, 9),
        servicoId: servico.id,
        nome: servico.nome,
        preco: servico.preco,
        quantidade: 1
      }]);
    }
  };

  const removerItem = (id: string) => {
    setItens(itens.filter(item => item.id !== id));
  };

  const alterarQuantidade = (id: string, delta: number) => {
    setItens(itens.map(item => {
      if (item.id === id) {
        const novaQtd = Math.max(1, item.quantidade + delta);
        return { ...item, quantidade: novaQtd };
      }
      return item;
    }));
  };

  const total = itens.reduce((acc, item) => acc + (item.preco * item.quantidade), 0);

  const finalizarFatura = () => {
    if (itens.length === 0) return;
    setShowPreview(true);
  };

  const confirmarFaturacao = async () => {
    setLoading(true);
    // Simulação de salvamento
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
      setShowPreview(false);
      setTimeout(() => {
        setSuccess(false);
        setItens([]);
        setSelectedCliente(null);
      }, 3000);
    }, 1000);
  };

  const filteredServicos = servicos.filter(s => 
    s.nome.toLowerCase().includes(searchServico.toLowerCase()) ||
    s.categoria.toLowerCase().includes(searchServico.toLowerCase())
  );

  return (
    <div className="flex flex-col lg:flex-row gap-8 h-full lg:h-[calc(100vh-160px)] relative">
      {/* Coluna Esquerda: Lista de Serviços */}
      <div className={`flex-1 flex flex-col gap-6 ${showMobileCart ? 'hidden lg:flex' : 'flex'}`}>
        <div className="flex flex-col gap-2">
          <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tighter">Faturação Direta</h2>
          <p className="text-slate-500 font-medium text-sm md:text-base">Selecione os serviços para adicionar à fatura.</p>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="Pesquisar serviço ou categoria..."
            value={searchServico}
            onChange={(e) => setSearchServico(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-medium focus:ring-2 focus:ring-primary/20 outline-none transition-all shadow-sm"
          />
        </div>

        <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 pb-20 lg:pb-0">
            {filteredServicos.map((servico) => (
              <motion.button
                key={servico.id}
                whileHover={{ y: -4 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => adicionarItem(servico)}
                className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm hover:border-primary/50 hover:shadow-md transition-all text-left flex flex-col justify-between h-36 md:h-40 group"
              >
                <div className="flex justify-between items-start">
                  <div className="w-10 h-10 bg-slate-50 text-slate-400 rounded-xl flex items-center justify-center group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                    <Plus size={20} />
                  </div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50 px-2 py-1 rounded-lg">
                    {servico.categoria}
                  </span>
                </div>
                <div>
                  <h4 className="font-black text-slate-900 leading-tight mb-1 text-sm md:text-base">{servico.nome}</h4>
                  <p className="text-primary font-black text-base md:text-lg">
                    {servico.preco.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                  </p>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </div>

      {/* Coluna Direita: Carrinho / Fatura */}
      <div className={`
        fixed inset-0 z-40 bg-slate-50 lg:relative lg:bg-transparent lg:z-0 lg:flex lg:w-[400px] flex-col gap-6
        ${showMobileCart ? 'flex' : 'hidden lg:flex'}
      `}>
        <div className="bg-white rounded-none lg:rounded-[2.5rem] border-0 lg:border border-slate-200 shadow-xl flex flex-col h-full overflow-hidden">
          {/* Header do Carrinho */}
          <div className="p-6 lg:p-8 border-b border-slate-100 bg-slate-50/50">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setShowMobileCart(false)}
                  className="lg:hidden p-2 -ml-2 text-slate-500 hover:bg-slate-100 rounded-lg"
                >
                  <ChevronRight className="rotate-180" size={24} />
                </button>
                <div className="w-10 h-10 bg-primary text-white rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
                  <ShoppingCart size={20} />
                </div>
                <h3 className="text-xl font-black text-slate-900 tracking-tighter">Carrinho</h3>
              </div>
              <span className="bg-slate-900 text-white text-[10px] font-black px-2 py-1 rounded-full">
                {itens.length} ITENS
              </span>
            </div>

            {/* Seleção de Cliente */}
            <div className="relative">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <select 
                className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-900 focus:ring-2 focus:ring-primary/20 outline-none appearance-none cursor-pointer"
                value={selectedCliente?.id || ''}
                onChange={(e) => {
                  const cliente = clientes.find(c => c.id === parseInt(e.target.value));
                  setSelectedCliente(cliente || null);
                }}
              >
                <option value="">Consumidor Final</option>
                {clientes.map(c => (
                  <option key={c.id} value={c.id}>{c.nome}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Lista de Itens no Carrinho */}
          <div className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-4 custom-scrollbar">
            <AnimatePresence initial={false}>
              {itens.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-300 gap-4 py-20">
                  <ShoppingCart size={48} strokeWidth={1} />
                  <p className="font-medium italic text-sm">Carrinho vazio</p>
                </div>
              ) : (
                itens.map((item) => (
                  <motion.div 
                    key={item.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="flex items-center justify-between gap-4 p-4 bg-slate-50 rounded-3xl border border-slate-100 group"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-black text-slate-900 truncate">{item.nome}</p>
                      <p className="text-xs font-bold text-primary">
                        {item.preco.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <div className="flex items-center bg-white rounded-xl border border-slate-200 p-1">
                        <button 
                          onClick={() => alterarQuantidade(item.id, -1)}
                          className="p-1 hover:text-primary transition-colors"
                        >
                          <Minus size={14} />
                        </button>
                        <span className="w-6 text-center text-xs font-black">{item.quantidade}</span>
                        <button 
                          onClick={() => alterarQuantidade(item.id, 1)}
                          className="p-1 hover:text-primary transition-colors"
                        >
                          <Plus size={14} />
                        </button>
                      </div>
                      <button 
                        onClick={() => removerItem(item.id)}
                        className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>

          {/* Footer do Carrinho: Totais e Botão */}
          <div className="p-6 lg:p-8 border-t border-slate-100 bg-white space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-slate-400 text-[10px] font-black uppercase tracking-widest">
                <span>Subtotal</span>
                <span>{total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</span>
              </div>
              <div className="flex justify-between items-center pt-2">
                <span className="text-slate-900 font-black text-lg lg:text-xl tracking-tighter">Total Geral</span>
                <span className="text-2xl lg:text-3xl font-black text-primary tracking-tighter">
                  {total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                </span>
              </div>
            </div>

            <button 
              onClick={finalizarFatura}
              disabled={itens.length === 0 || loading || success}
              className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all flex items-center justify-center gap-2 shadow-xl ${
                success 
                  ? 'bg-emerald-500 text-white shadow-emerald-500/20' 
                  : 'bg-primary text-white shadow-primary/20 hover:bg-slate-800 disabled:opacity-50'
              }`}
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : success ? (
                <>
                  <CheckCircle2 size={20} />
                  Faturado com Sucesso
                </>
              ) : (
                <>
                  <FileText size={20} />
                  Finalizar Fatura
                </>
              )}
            </button>

            <button 
              onClick={() => window.print()}
              disabled={itens.length === 0}
              className="w-full py-3 bg-slate-100 text-slate-600 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
            >
              <Printer size={16} />
              Imprimir Recibo
            </button>
          </div>
        </div>
      </div>

      {/* Floating Action Button for Mobile Cart */}
      {!showMobileCart && itens.length > 0 && (
        <motion.button
          initial={{ scale: 0, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          onClick={() => setShowMobileCart(true)}
          className="lg:hidden fixed bottom-20 right-6 z-50 bg-primary text-white p-4 rounded-full shadow-2xl flex items-center gap-3"
        >
          <div className="relative">
            <ShoppingCart size={24} />
            <span className="absolute -top-2 -right-2 bg-red-500 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-primary">
              {itens.length}
            </span>
          </div>
          <span className="font-black text-sm pr-2">Ver Carrinho</span>
        </motion.button>
      )}

      {/* Modal de Pré-visualização da Fatura */}
      <AnimatePresence>
        {showPreview && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-8">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPreview(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Header do Modal */}
              <div className="p-8 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tighter">Confirmar Faturação</h3>
                  <p className="text-slate-500 font-medium">Reveja os detalhes antes de emitir o documento.</p>
                </div>
                <div className="w-12 h-12 bg-primary/10 text-primary rounded-2xl flex items-center justify-center">
                  <FileText size={24} />
                </div>
              </div>

              {/* Conteúdo da Fatura */}
              <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
                {/* Cabeçalho da Fatura */}
                <div className="flex flex-col md:flex-row justify-between gap-8 pb-8 border-b border-slate-100">
                  <div className="flex gap-4">
                    <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center text-white font-black text-2xl shadow-lg shadow-primary/20">
                      {lavandaria?.nome?.charAt(0) || 'L'}
                    </div>
                    <div className="space-y-1">
                      <h4 className="text-xl font-black text-slate-900 tracking-tighter">{lavandaria?.nome || 'LavanderiaPro'}</h4>
                      <p className="text-xs text-slate-500 font-medium">NIF: {lavandaria?.nif || '---'}</p>
                      <p className="text-xs text-slate-500 font-medium">{lavandaria?.endereco || 'Endereço não configurado'}</p>
                      <p className="text-xs text-slate-500 font-medium">Tel: {lavandaria?.telefone || '---'}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-x-8 gap-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <div className="space-y-0.5">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Nº Fatura</span>
                      <p className="text-xs font-black text-slate-900">{invoiceNumber}</p>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Série</span>
                      <p className="text-xs font-black text-slate-900">{serie}</p>
                    </div>
                    <div className="space-y-0.5">
                      <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Data Emissão</span>
                      <p className="text-xs font-black text-slate-900">{date}</p>
                    </div>
                  </div>
                </div>

                {/* Info Cliente */}
                <div className="space-y-2">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Dados do Cliente</span>
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <p className="font-black text-slate-900">{selectedCliente?.nome || 'Consumidor Final'}</p>
                    {selectedCliente?.telefone && <p className="text-xs text-slate-500 font-medium">Tel: {selectedCliente.telefone}</p>}
                    {selectedCliente?.nif && <p className="text-xs text-slate-500 font-medium">NIF: {selectedCliente.nif}</p>}
                  </div>
                </div>

                {/* Tabela de Itens */}
                <div className="space-y-4">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Itens do Serviço</span>
                  <div className="bg-slate-50 rounded-3xl border border-slate-100 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                          <th className="px-6 py-3">Descrição</th>
                          <th className="px-6 py-3 text-center">Qtd</th>
                          <th className="px-6 py-3 text-right">Total</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {itens.map(item => (
                          <tr key={item.id}>
                            <td className="px-6 py-4 text-sm font-bold text-slate-900">{item.nome}</td>
                            <td className="px-6 py-4 text-sm font-bold text-slate-900 text-center">{item.quantidade}</td>
                            <td className="px-6 py-4 text-sm font-black text-slate-900 text-right">
                              {(item.preco * item.quantidade).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Resumo Financeiro */}
                <div className="bg-slate-900 rounded-3xl p-6 text-white flex justify-between items-center">
                  <span className="font-black uppercase tracking-widest text-xs text-slate-400">Total a Pagar</span>
                  <span className="text-3xl font-black tracking-tighter text-primary">
                    {total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                  </span>
                </div>
              </div>

              {/* Ações do Modal */}
              <div className="p-8 bg-slate-50 border-t border-slate-100 grid grid-cols-2 gap-4">
                <button 
                  onClick={() => setShowPreview(false)}
                  className="py-4 bg-white border border-slate-200 text-slate-600 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-slate-100 transition-all flex items-center justify-center gap-2"
                >
                  <Trash2 size={18} />
                  Editar
                </button>
                <button 
                  onClick={confirmarFaturacao}
                  disabled={loading}
                  className="py-4 bg-primary text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-slate-800 transition-all flex items-center justify-center gap-2 shadow-xl shadow-primary/20"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <CheckCircle2 size={18} />
                      Faturar
                    </>
                  )}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
