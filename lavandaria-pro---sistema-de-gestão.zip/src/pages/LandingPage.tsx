import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { 
  Shirt, 
  CheckCircle2, 
  Zap, 
  ShieldCheck, 
  ArrowRight,
  LayoutDashboard,
  Users,
  ReceiptText
} from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white overflow-hidden selection:bg-primary selection:text-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-primary/20">
              L
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">Lavanderia<span className="text-accent">Pro</span></h1>
          </div>
          <div className="hidden md:flex items-center gap-8 mr-8">
            <a href="#features" className="text-sm font-bold text-slate-500 hover:text-primary transition-colors">Funcionalidades</a>
            <a href="#about" className="text-sm font-bold text-slate-500 hover:text-primary transition-colors">Sobre</a>
            <a href="#contact" className="text-sm font-bold text-slate-500 hover:text-primary transition-colors">Contacto</a>
          </div>
          <div className="flex items-center gap-4">
            <Link 
              to="/login" 
              className="hidden sm:block text-sm font-bold text-slate-600 hover:text-slate-900 transition-colors"
            >
              Fazer Login
            </Link>
            <Link 
              to="/register" 
              className="bg-primary text-white px-6 py-2.5 rounded-full text-sm font-bold hover:bg-slate-800 transition-all shadow-lg shadow-primary/20 active:scale-95"
            >
              Cadastrar Empresa
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 lg:pt-48 lg:pb-40 relative overflow-hidden bg-gradient-to-br from-blue-600 via-blue-700 to-purple-800">
        {/* Animated Background Elements */}
        <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/4 w-[800px] h-[800px] bg-white/10 rounded-full blur-3xl -z-10 animate-pulse" />
        <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[600px] h-[600px] bg-purple-400/10 rounded-full blur-3xl -z-10 animate-pulse" style={{ animationDelay: '1s' }} />
        
        {/* Floating Clothes Animations */}
        <motion.div 
          animate={{ y: [0, -30, 0], rotate: [0, 15, 0], opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-40 left-[5%] text-white hidden xl:block"
        >
          <Shirt size={100} strokeWidth={1} />
        </motion.div>
        <motion.div 
          animate={{ y: [0, 40, 0], rotate: [0, -20, 0], opacity: [0.05, 0.15, 0.05] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute top-80 right-[8%] text-white hidden xl:block"
        >
          <Shirt size={120} strokeWidth={1} />
        </motion.div>
        <motion.div 
          animate={{ x: [0, 20, 0], y: [0, -20, 0], rotate: [0, 360, 0], opacity: [0.05, 0.1, 0.05] }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-20 left-[15%] text-white hidden xl:block"
        >
          <Shirt size={60} strokeWidth={1} />
        </motion.div>
        <motion.div 
          animate={{ y: [0, -50, 0], x: [0, 30, 0], opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 2 }}
          className="absolute bottom-40 right-[20%] text-white hidden xl:block"
        >
          <Shirt size={80} strokeWidth={1} />
        </motion.div>
        
        {/* Bubbles / Water drops effect */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ y: "110%", x: `${10 + i * 15}%`, opacity: 0 }}
            animate={{ 
              y: "-10%", 
              opacity: [0, 0.3, 0],
              x: `${10 + i * 15 + Math.sin(i) * 5}%` 
            }}
            transition={{ 
              duration: 5 + i, 
              repeat: Infinity, 
              delay: i * 0.8,
              ease: "linear" 
            }}
            className="absolute w-4 h-4 rounded-full border border-white/20 bg-white/5 blur-[1px] -z-10"
          />
        ))}

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 py-1.5 px-4 rounded-full bg-white/10 border border-white/20 text-white text-[10px] font-black uppercase tracking-[0.2em] mb-8">
              <span className="w-2 h-2 bg-accent rounded-full animate-ping" />
              Gestão Inteligente para Lavanderias
            </div>
            <h1 className="text-6xl lg:text-8xl font-black tracking-tighter text-white mb-8 leading-[0.85]">
              O Futuro da sua <br />
              <span className="text-accent italic relative">
                Lavanderia
                <svg className="absolute -bottom-2 left-0 w-full h-3 text-white/30" viewBox="0 0 100 10" preserveAspectRatio="none">
                  <path d="M0 5 Q 25 0, 50 5 T 100 5" fill="none" stroke="currentColor" strokeWidth="8" />
                </svg>
              </span> começa aqui.
            </h1>
            <p className="max-w-2xl mx-auto text-xl text-blue-100 mb-12 leading-relaxed font-medium">
              A plataforma definitiva para automatizar processos, controlar faturamento 
              e encantar seus clientes. Simples, potente e 100% focado em resultados.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link 
                to="/register" 
                className="w-full sm:w-auto bg-white text-blue-700 px-12 py-5 rounded-full text-lg font-black hover:bg-blue-50 transition-all shadow-2xl shadow-black/20 flex items-center justify-center gap-3 group active:scale-95"
              >
                Começar Agora Grátis
                <ArrowRight className="group-hover:translate-x-2 transition-transform" />
              </Link>
              <Link 
                to="/login" 
                className="w-full sm:w-auto bg-transparent border-2 border-white/30 text-white px-12 py-5 rounded-full text-lg font-black hover:bg-white/10 transition-all active:scale-95"
              >
                Aceder ao Painel
              </Link>
            </div>
          </motion.div>

          {/* Dashboard Preview */}
          <motion.div 
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="mt-24 relative max-w-5xl mx-auto"
          >
            <div className="relative rounded-[2.5rem] border-[8px] border-slate-900 bg-slate-900 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.3)] overflow-hidden group">
              <img 
                src="https://images.unsplash.com/photo-1517677208171-0bc6725a3e60?auto=format&fit=crop&q=80&w=1600&h=900" 
                alt="Dashboard Preview" 
                className="w-full h-auto opacity-95 group-hover:scale-105 transition-transform duration-1000"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent" />
              
              {/* Play Button Overlay */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white border border-white/30">
                  <Zap size={32} fill="currentColor" />
                </div>
              </div>
            </div>
            
            {/* Floating Stats Card */}
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-12 -right-12 hidden lg:block bg-white p-8 rounded-[2rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.2)] border border-slate-100"
            >
              <div className="flex items-center gap-5">
                <div className="w-14 h-14 bg-accent/10 text-accent rounded-2xl flex items-center justify-center">
                  <Zap size={28} />
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Crescimento Médio</p>
                  <p className="text-3xl font-black text-slate-900">+45.8%</p>
                </div>
              </div>
            </motion.div>

            {/* Floating Users Card */}
            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute top-20 -left-12 hidden lg:block bg-white p-6 rounded-[2rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.2)] border border-slate-100"
            >
              <div className="flex items-center gap-4">
                <div className="flex -space-x-3">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-slate-200 overflow-hidden">
                      <img src={`https://i.pravatar.cc/100?u=${i}`} alt="user" />
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Utilizadores Ativos</p>
                  <p className="text-lg font-black text-slate-900">500+ Empresas</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-32 bg-slate-50 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-20">
            <h2 className="text-4xl lg:text-6xl font-black tracking-tighter text-slate-900 mb-6">
              Tudo o que você precisa para <br /> 
              <span className="text-primary italic">escalar</span> seu negócio.
            </h2>
            <p className="text-slate-500 max-w-xl mx-auto text-lg font-medium">
              Funcionalidades pensadas para simplificar o dia a dia da sua operação 
              e maximizar a rentabilidade.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            {[
              {
                icon: LayoutDashboard,
                title: "Dashboard em Tempo Real",
                desc: "Visualize suas vendas, pedidos e métricas importantes instantaneamente com gráficos intuitivos."
              },
              {
                icon: Shirt,
                title: "Gestão de Serviços",
                desc: "Gerencie cada peça, desde a recepção até a entrega final, com rastreamento completo de status."
              },
              {
                icon: Users,
                title: "Gestão de Clientes",
                desc: "Mantenha um histórico completo de preferências, fidelidade e pedidos de cada cliente."
              },
              {
                icon: ReceiptText,
                title: "Faturação & NIF",
                desc: "Emita faturas profissionais com todos os dados fiscais necessários e suporte a múltiplos regimes."
              },
              {
                icon: ShieldCheck,
                title: "Segurança de Dados",
                desc: "Seus dados e os de seus clientes protegidos com criptografia e backups automáticos."
              },
              {
                icon: Zap,
                title: "Agilidade no Atendimento",
                desc: "Interface otimizada para reduzir o tempo de registo e melhorar a experiência do seu cliente."
              }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-2xl transition-all duration-500 group"
              >
                <div className="w-16 h-16 bg-primary/5 text-primary rounded-2xl flex items-center justify-center mb-8 group-hover:bg-primary group-hover:text-white transition-colors duration-500">
                  <feature.icon size={32} />
                </div>
                <h3 className="text-2xl font-black text-slate-900 mb-4 tracking-tight">{feature.title}</h3>
                <p className="text-slate-500 leading-relaxed font-medium">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 rounded-[4rem] p-12 lg:p-24 text-center relative overflow-hidden shadow-[0_50px_100px_-20px_rgba(15,23,42,0.4)]">
            <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 rounded-full blur-[100px]" />
            <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/20 rounded-full blur-[100px]" />
            
            <div className="relative z-10">
              <h2 className="text-4xl lg:text-7xl font-black text-white tracking-tighter mb-8 leading-tight">
                Pronto para transformar <br /> sua lavanderia?
              </h2>
              <p className="text-slate-400 mb-12 max-w-2xl mx-auto text-xl font-medium">
                Junte-se a centenas de empresas que já otimizaram seus processos 
                e aumentaram sua faturação com o LavanderiaPro.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
                <Link 
                  to="/register" 
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-3 bg-white text-slate-900 px-12 py-5 rounded-full text-xl font-black hover:bg-slate-100 transition-all active:scale-95"
                >
                  Registar Agora
                  <ArrowRight size={24} />
                </Link>
                <Link 
                  to="/login" 
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-3 bg-transparent border-2 border-white/20 text-white px-12 py-5 rounded-full text-xl font-black hover:bg-white/5 transition-all active:scale-95"
                >
                  Fazer Login
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-20 border-t border-slate-100 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-12 mb-16">
            <div className="col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold text-xl">
                  L
                </div>
                <span className="font-black text-2xl text-slate-900 tracking-tighter">LavanderiaPro</span>
              </div>
              <p className="text-slate-500 max-w-xs font-medium leading-relaxed">
                A solução líder em gestão para lavanderias profissionais em Angola. 
                Tecnologia, eficiência e cuidado têxtil.
              </p>
            </div>
            <div>
              <h4 className="font-black text-slate-900 uppercase tracking-widest text-xs mb-6">Produto</h4>
              <ul className="space-y-4">
                <li><a href="#" className="text-slate-500 hover:text-primary font-bold transition-colors">Funcionalidades</a></li>
                <li><a href="#" className="text-slate-500 hover:text-primary font-bold transition-colors">Preços</a></li>
                <li><a href="#" className="text-slate-500 hover:text-primary font-bold transition-colors">Demonstração</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-black text-slate-900 uppercase tracking-widest text-xs mb-6">Suporte</h4>
              <ul className="space-y-4">
                <li><a href="#" className="text-slate-500 hover:text-primary font-bold transition-colors">Centro de Ajuda</a></li>
                <li><a href="#" className="text-slate-500 hover:text-primary font-bold transition-colors">Contacto</a></li>
                <li><a href="#" className="text-slate-500 hover:text-primary font-bold transition-colors">Status</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-12 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
            <p className="text-slate-400 text-sm font-bold">
              © 2026 LavanderiaPro. Todos os direitos reservados.
            </p>
            <div className="flex items-center gap-8">
              <a href="#" className="text-sm text-slate-400 hover:text-slate-900 font-bold transition-colors">Termos</a>
              <a href="#" className="text-sm text-slate-400 hover:text-slate-900 font-bold transition-colors">Privacidade</a>
              <a href="#" className="text-sm text-slate-400 hover:text-slate-900 font-bold transition-colors">Cookies</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
