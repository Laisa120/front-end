import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Minus, 
  AlertTriangle, 
  Package, 
  History,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { ProdutoEstoque } from '../types';

export default function Estoque() {
  const [estoque, setEstoque] = useState<ProdutoEstoque[]>([]);

  useEffect(() => {
    fetchEstoque();
  }, []);

  const fetchEstoque = () => {
    fetch('/api/estoque')
      .then(res => res.json())
      .then(setEstoque);
  };

  const updateQuantidade = async (id: number, novaQtd: number) => {
    await fetch(`/api/estoque/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ quantidade: novaQtd })
    });
    fetchEstoque();
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Estoque</h2>
          <p className="text-slate-500">Controle de insumos e produtos de limpeza.</p>
        </div>
        <button className="bg-slate-900 text-white px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all">
          <Plus size={20} />
          Novo Produto
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {estoque.map((item) => {
          const isLow = item.quantidade <= item.minimo_alerta;
          return (
            <div key={item.id} className={`bg-white p-6 rounded-2xl border ${isLow ? 'border-rose-200 bg-rose-50/30' : 'border-slate-200'} card-shadow relative overflow-hidden`}>
              {isLow && (
                <div className="absolute top-0 right-0 bg-rose-500 text-white px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded-bl-xl">
                  Estoque Baixo
                </div>
              )}
              
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isLow ? 'bg-rose-100 text-rose-600' : 'bg-slate-100 text-slate-600'}`}>
                  <Package size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">{item.produto}</h3>
                  <p className="text-xs text-slate-500">Mínimo: {item.minimo_alerta} {item.unidade}</p>
                </div>
              </div>

              <div className="flex items-center justify-between mb-6">
                <div className="space-y-1">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Quantidade Atual</p>
                  <p className={`text-3xl font-black ${isLow ? 'text-rose-600' : 'text-primary'}`}>
                    {item.quantidade} <span className="text-sm font-medium text-slate-400">{item.unidade}</span>
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <button 
                  onClick={() => updateQuantidade(item.id, Math.max(0, item.quantidade - 1))}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold transition-colors"
                >
                  <Minus size={18} />
                  Saída
                </button>
                <button 
                  onClick={() => updateQuantidade(item.id, item.quantidade + 1)}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-primary text-white rounded-xl font-bold hover:bg-slate-800 transition-colors shadow-lg shadow-primary/20"
                >
                  <Plus size={18} />
                  Entrada
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Stock Alerts Section */}
      <div className="bg-white rounded-2xl border border-slate-200 card-shadow overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 flex items-center gap-2">
            <History size={20} className="text-primary" />
            Histórico de Movimentação
          </h3>
          <button className="text-sm font-semibold text-primary hover:underline">Ver completo</button>
        </div>
        <div className="p-6 space-y-4">
          <div className="flex items-center justify-between py-3 border-b border-slate-50">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center">
                <ArrowUpRight size={16} />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-900">Entrada: Sabão em Pó</p>
                <p className="text-xs text-slate-500">Há 2 horas • Por: Admin</p>
              </div>
            </div>
            <span className="text-sm font-bold text-emerald-600">+ 10 kg</span>
          </div>
          <div className="flex items-center justify-between py-3 border-b border-slate-50">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-600 flex items-center justify-center">
                <ArrowDownRight size={16} />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-900">Saída: Amaciante</p>
                <p className="text-xs text-slate-500">Há 5 horas • Por: Operador</p>
              </div>
            </div>
            <span className="text-sm font-bold text-rose-600">- 2 L</span>
          </div>
        </div>
      </div>
    </div>
  );
}
