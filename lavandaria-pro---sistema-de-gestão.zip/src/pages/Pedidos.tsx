import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Eye, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  CreditCard,
  DollarSign
} from 'lucide-react';
import { Pedido } from '../types';

export default function Pedidos() {
  const [pedidos, setPedidos] = useState<Pedido[]>([]);
  const [search, setSearch] = useState('');
  const [selectedPedido, setSelectedPedido] = useState<any | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [formaPagamento, setFormaPagamento] = useState('Cartão');

  useEffect(() => {
    fetchPedidos();
  }, []);

  const fetchPedidos = () => {
    fetch('/api/pedidos')
      .then(res => res.json())
      .then(setPedidos);
  };

  const updateStatus = async (id: number, status: string) => {
    await fetch(`/api/pedidos/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    fetchPedidos();
    if (selectedPedido && selectedPedido.id === id) {
      viewPedido(id);
    }
  };

  const viewPedido = async (id: number) => {
    const res = await fetch(`/api/pedidos/${id}`);
    const data = await res.json();
    setSelectedPedido(data);
  };

  const handlePayment = async () => {
    if (!selectedPedido) return;
    const res = await fetch('/api/vendas', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pedido_id: selectedPedido.id,
        forma_pagamento: formaPagamento,
        valor_pago: selectedPedido.total
      })
    });
    if (res.ok) {
      setShowPaymentModal(false);
      viewPedido(selectedPedido.id);
      fetchPedidos();
    }
  };

  const filtered = pedidos.filter(p => 
    p.cliente_nome?.toLowerCase().includes(search.toLowerCase()) || 
    p.id.toString().includes(search)
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Serviços</h2>
          <p className="text-slate-500">Acompanhe o status e pagamentos de todos os serviços.</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 card-shadow overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por ID ou cliente..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
            />
          </div>
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-4 py-2 text-slate-600 hover:bg-slate-50 rounded-xl transition-colors border border-slate-200">
              <Filter size={18} />
              <span className="text-sm font-semibold">Filtros</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider font-bold">
                <th className="px-6 py-4">ID</th>
                <th className="px-6 py-4">Cliente</th>
                <th className="px-6 py-4">Serviço</th>
                <th className="px-6 py-4">Data</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Pagamento</th>
                <th className="px-6 py-4 text-right">Total</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((pedido) => (
                <tr key={pedido.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-4 text-sm font-mono text-slate-500">#{pedido.id}</td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-bold text-slate-900">{pedido.cliente_nome}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-1 rounded-lg">
                      {pedido.tipo_servico || 'Normal'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">
                    {new Date(pedido.data).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4">
                    <select 
                      value={pedido.status}
                      onChange={(e) => updateStatus(pedido.id, e.target.value)}
                      className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border-none focus:ring-2 focus:ring-primary/20 outline-none cursor-pointer transition-colors ${
                        pedido.status === 'recebido' ? 'bg-blue-100 text-blue-600' :
                        pedido.status === 'processando' ? 'bg-amber-100 text-amber-600' :
                        pedido.status === 'pronto' ? 'bg-emerald-100 text-emerald-600' :
                        pedido.status === 'entregue' ? 'bg-slate-100 text-slate-600' :
                        'bg-rose-100 text-rose-600'
                      }`}
                    >
                      <option value="recebido">Recebido</option>
                      <option value="processando">Processando</option>
                      <option value="pronto">Pronto</option>
                      <option value="entregue">Entregue</option>
                      <option value="cancelado">Cancelado</option>
                    </select>
                  </td>
                  <td className="px-6 py-4">
                    {pedido.pago ? (
                      <span className="flex items-center gap-1 text-emerald-600 text-xs font-bold">
                        <CheckCircle2 size={14} /> PAGO
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-rose-500 text-xs font-bold">
                        <AlertCircle size={14} /> PENDENTE
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-slate-900 text-right">
                    {pedido.total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => viewPedido(pedido.id)}
                      className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors"
                    >
                      <Eye size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detalhes do Pedido Modal */}
      {selectedPedido && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl">
            <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
              <div>
                <h3 className="text-xl font-bold">Serviço #{selectedPedido.id}</h3>
                <p className="text-slate-400 text-sm">{selectedPedido.cliente_nome}</p>
              </div>
              <div className="text-right">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Prazo</p>
                <p className="text-sm font-bold text-emerald-400">
                  {selectedPedido.prazo_entrega ? new Date(selectedPedido.prazo_entrega).toLocaleDateString() : 'Não definido'}
                </p>
              </div>
            </div>

            <div className="p-8 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Status Atual</h4>
                  <div className="flex flex-wrap gap-2">
                    {['recebido', 'processando', 'pronto', 'entregue', 'cancelado'].map(s => (
                      <button 
                        key={s}
                        onClick={() => updateStatus(selectedPedido.id, s)}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all ${
                          selectedPedido.status === s 
                            ? 'bg-primary text-white scale-105 shadow-lg' 
                            : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                  <div className="mt-4">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Tipo de Serviço</h4>
                    <span className="text-sm font-bold text-slate-700 bg-slate-100 px-3 py-1 rounded-lg">
                      {selectedPedido.tipo_servico || 'Normal'}
                    </span>
                  </div>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Pagamento</h4>
                  {selectedPedido.pago ? (
                    <div className="flex items-center gap-2 text-emerald-600 font-bold">
                      <CheckCircle2 size={20} />
                      Pedido Finalizado e Pago
                    </div>
                  ) : (
                    <button 
                      onClick={() => setShowPaymentModal(true)}
                      className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-xl font-bold text-sm transition-all shadow-lg shadow-emerald-500/20"
                    >
                      <DollarSign size={18} />
                      Registrar Pagamento
                    </button>
                  )}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Itens do Serviço</h4>
                <div className="border border-slate-100 rounded-2xl overflow-hidden">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500 font-bold">
                      <tr>
                        <th className="px-4 py-3">Peça</th>
                        <th className="px-4 py-3">Serviço</th>
                        <th className="px-4 py-3 text-right">Preço</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedPedido.itens?.map((item: any) => (
                        <tr key={item.id}>
                          <td className="px-4 py-3 font-semibold">{item.tipo_peca}</td>
                          <td className="px-4 py-3 text-slate-500">{item.servico}</td>
                          <td className="px-4 py-3 text-right font-bold">{item.preco.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-slate-50 font-bold">
                      <tr>
                        <td colSpan={2} className="px-4 py-4 text-right text-slate-500">Total</td>
                        <td className="px-4 py-4 text-right text-lg text-primary">{selectedPedido.total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>

              <div className="flex justify-between pt-4">
                <button 
                  onClick={() => window.print()}
                  className="px-6 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 transition-colors flex items-center gap-2"
                >
                  <CreditCard size={18} />
                  Imprimir Recibo
                </button>
                <button 
                  onClick={() => setSelectedPedido(null)}
                  className="px-6 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Pagamento */}
      {showPaymentModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[70] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-8 shadow-2xl">
            <h3 className="text-2xl font-bold text-slate-900 mb-6">Registrar Pagamento</h3>
            <div className="bg-slate-50 p-4 rounded-2xl mb-6 flex justify-between items-center">
              <span className="text-slate-500 font-medium">Valor a Pagar</span>
              <span className="text-2xl font-black text-primary">{selectedPedido?.total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</span>
            </div>
            
            <div className="space-y-4 mb-8">
              <label className="block text-sm font-semibold text-slate-700">Forma de Pagamento</label>
              <div className="grid grid-cols-2 gap-3">
                {['Cartão', 'Dinheiro', 'Pix', 'Transferência'].map(f => (
                  <button 
                    key={f}
                    onClick={() => setFormaPagamento(f)}
                    className={`px-4 py-3 rounded-xl font-bold text-sm border-2 transition-all flex items-center justify-center gap-2 ${
                      formaPagamento === f 
                        ? 'border-primary bg-primary/5 text-primary' 
                        : 'border-slate-100 text-slate-500 hover:border-slate-200'
                    }`}
                  >
                    {f === 'Cartão' && <CreditCard size={16} />}
                    {f === 'Dinheiro' && <DollarSign size={16} />}
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <button 
                onClick={() => setShowPaymentModal(false)}
                className="flex-1 px-6 py-3 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Voltar
              </button>
              <button 
                onClick={handlePayment}
                className="flex-1 px-6 py-3 bg-emerald-500 text-white rounded-xl font-bold hover:bg-emerald-600 transition-colors shadow-lg shadow-emerald-500/20"
              >
                Confirmar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
