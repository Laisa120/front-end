import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Plus, 
  Search, 
  MapPin, 
  Phone, 
  Mail, 
  Calendar,
  MoreVertical,
  Edit2,
  Trash2
} from 'lucide-react';
import { motion } from 'motion/react';
import { Lavandaria } from '../types';

export default function Lavandarias() {
  const [lavandarias, setLavandarias] = useState<Lavandaria[]>([]);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    nome: '',
    nome_comercial: '',
    endereco: '',
    telefone: '',
    email: '',
    nif: '',
    registo_comercial: '',
    tipo_empresa: 'Lda',
    data_constituicao: '',
    regime_fiscal: 'Regime Geral',
    percentagem_iva: 14,
    sujeito_retencao: false,
    conta_bancaria: '',
    iban: '',
    banco: ''
  });

  useEffect(() => {
    fetchLavandarias();
  }, []);

  const fetchLavandarias = () => {
    setLoading(true);
    fetch('/api/lavandarias')
      .then(res => res.json())
      .then(data => {
        setLavandarias(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/lavandarias', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if (res.ok) {
        setShowModal(false);
        setFormData({ 
          nome: '', 
          nome_comercial: '',
          endereco: '', 
          telefone: '', 
          email: '',
          nif: '',
          registo_comercial: '',
          tipo_empresa: 'Lda',
          data_constituicao: '',
          regime_fiscal: 'Regime Geral',
          percentagem_iva: 14,
          sujeito_retencao: false,
          conta_bancaria: '',
          iban: '',
          banco: ''
        });
        fetchLavandarias();
      }
    } catch (error) {
      console.error('Erro ao cadastrar lavandaria:', error);
    }
  };

  const filtered = lavandarias.filter(l => 
    l.nome.toLowerCase().includes(search.toLowerCase()) ||
    l.endereco?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Perfil da Lavandaria</h2>
          <p className="text-slate-500 text-lg">Gerencie as informações e unidades da sua lavanderia.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-primary hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-primary/20"
        >
          <Plus size={20} />
          Nova Lavandaria
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 card-shadow overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por nome ou endereço..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
          {filtered.map((lavandaria) => (
            <motion.div 
              key={lavandaria.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="group bg-slate-50 border border-slate-200 rounded-2xl p-6 hover:bg-white hover:border-primary/20 hover:shadow-xl transition-all relative"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 bg-primary/10 text-primary rounded-xl flex items-center justify-center">
                  <Building2 size={24} />
                </div>
                <button className="p-2 text-slate-400 hover:text-slate-900 hover:bg-white rounded-lg transition-colors">
                  <MoreVertical size={18} />
                </button>
              </div>

              <h3 className="text-xl font-bold text-slate-900 mb-1">{lavandaria.nome}</h3>
              {lavandaria.nome_comercial && (
                <p className="text-xs font-bold text-primary mb-4 uppercase tracking-wider">{lavandaria.nome_comercial}</p>
              )}
              
              <div className="space-y-3 text-sm text-slate-600">
                <div className="flex items-start gap-3">
                  <MapPin size={16} className="text-slate-400 mt-0.5 shrink-0" />
                  <span>{lavandaria.endereco || 'Endereço não informado'}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone size={16} className="text-slate-400 shrink-0" />
                  <span>{lavandaria.telefone || 'Sem telefone'}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail size={16} className="text-slate-400 shrink-0" />
                  <span className="truncate">{lavandaria.email || 'Sem e-mail'}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 mt-2">
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">NIF</p>
                    <p className="font-bold text-slate-700">{lavandaria.nif || '---'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Regime</p>
                    <p className="font-bold text-slate-700">{lavandaria.regime_fiscal || '---'}</p>
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-100 mt-2">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Banco / IBAN</p>
                  <p className="font-bold text-slate-700 text-xs truncate">{lavandaria.banco} - {lavandaria.iban || '---'}</p>
                </div>
                <div className="flex items-center gap-3 pt-2 border-t border-slate-200 mt-4">
                  <Calendar size={16} className="text-slate-400 shrink-0" />
                  <span className="text-xs">Cadastrada em: {new Date(lavandaria.data_cadastro).toLocaleDateString()}</span>
                </div>
              </div>

              <div className="mt-6 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="flex-1 py-2 bg-white border border-slate-200 text-slate-600 rounded-lg text-xs font-bold hover:bg-slate-100 transition-colors flex items-center justify-center gap-2">
                  <Edit2 size={14} />
                  Editar
                </button>
                <button className="flex-1 py-2 bg-white border border-red-100 text-red-500 rounded-lg text-xs font-bold hover:bg-red-50 transition-colors flex items-center justify-center gap-2">
                  <Trash2 size={14} />
                  Excluir
                </button>
              </div>
            </motion.div>
          ))}

          {filtered.length === 0 && !loading && (
            <div className="col-span-full py-12 text-center text-slate-400 italic">
              Nenhuma lavandaria encontrada.
            </div>
          )}
        </div>
      </div>

      {/* Modal Cadastro */}
      {showModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl"
          >
            <div className="p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-slate-900">Nova Lavandaria</h3>
                <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-900">
                  <Plus size={24} className="rotate-45" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Nome da Empresa</label>
                    <input 
                      required
                      type="text" 
                      value={formData.nome}
                      onChange={(e) => setFormData({...formData, nome: e.target.value})}
                      placeholder="Ex: Lavanderia Pro, Lda"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Nome Comercial</label>
                    <input 
                      type="text" 
                      value={formData.nome_comercial}
                      onChange={(e) => setFormData({...formData, nome_comercial: e.target.value})}
                      placeholder="Nome fantasia"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">NIF</label>
                    <input 
                      required
                      type="text" 
                      value={formData.nif}
                      onChange={(e) => setFormData({...formData, nif: e.target.value})}
                      placeholder="NIF da Empresa"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Registo Comercial</label>
                    <input 
                      required
                      type="text" 
                      value={formData.registo_comercial}
                      onChange={(e) => setFormData({...formData, registo_comercial: e.target.value})}
                      placeholder="Nº de Registo Comercial"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Tipo de Empresa</label>
                    <select 
                      value={formData.tipo_empresa}
                      onChange={(e) => setFormData({...formData, tipo_empresa: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    >
                      <option value="Empresário em Nome Individual">Empresário em Nome Individual</option>
                      <option value="Sociedade Unipessoal">Sociedade Unipessoal</option>
                      <option value="Lda">Lda</option>
                      <option value="S.A">S.A</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Data de Constituição</label>
                    <input 
                      required
                      type="date" 
                      value={formData.data_constituicao}
                      onChange={(e) => setFormData({...formData, data_constituicao: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Endereço Completo</label>
                  <input 
                    type="text" 
                    value={formData.endereco}
                    onChange={(e) => setFormData({...formData, endereco: e.target.value})}
                    placeholder="Rua, Número, Bairro, Cidade"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                  />
                </div>

                <div className="border-t border-slate-100 pt-4">
                  <h4 className="text-xs font-black text-primary uppercase tracking-widest mb-4">Fiscal & Bancário</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Regime Fiscal</label>
                      <select 
                        value={formData.regime_fiscal}
                        onChange={(e) => setFormData({...formData, regime_fiscal: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                      >
                        <option value="Regime Geral">Regime Geral</option>
                        <option value="Regime Simplificado">Regime Simplificado</option>
                        <option value="Regime de Não Sujeição ao IVA">Regime de Não Sujeição ao IVA</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">IVA (%)</label>
                      <input 
                        type="number" 
                        value={formData.percentagem_iva}
                        onChange={(e) => setFormData({...formData, percentagem_iva: Number(e.target.value)})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 py-3">
                    <input 
                      type="checkbox"
                      id="modal_sujeito_retencao"
                      checked={formData.sujeito_retencao}
                      onChange={(e) => setFormData({...formData, sujeito_retencao: e.target.checked})}
                      className="w-4 h-4 text-primary border-slate-300 rounded"
                    />
                    <label htmlFor="modal_sujeito_retencao" className="text-xs font-bold text-slate-600">Sujeito a retenção?</label>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Banco</label>
                      <input 
                        type="text" 
                        value={formData.banco}
                        onChange={(e) => setFormData({...formData, banco: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Conta</label>
                      <input 
                        type="text" 
                        value={formData.conta_bancaria}
                        onChange={(e) => setFormData({...formData, conta_bancaria: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                      />
                    </div>
                  </div>
                  <div className="space-y-2 mt-4">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">IBAN</label>
                    <input 
                      type="text" 
                      value={formData.iban}
                      onChange={(e) => setFormData({...formData, iban: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Telefone</label>
                    <input 
                      type="tel" 
                      value={formData.telefone}
                      onChange={(e) => setFormData({...formData, telefone: e.target.value})}
                      placeholder="(00) 00000-0000"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">E-mail</label>
                    <input 
                      type="email" 
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      placeholder="unidade@lavanderia.com"
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
                    />
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 py-3 bg-primary text-white rounded-xl font-bold hover:bg-slate-800 transition-colors shadow-lg shadow-primary/20"
                  >
                    Cadastrar Unidade
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
