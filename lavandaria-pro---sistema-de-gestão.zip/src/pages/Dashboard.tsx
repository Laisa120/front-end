import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  ShoppingBag, 
  Clock, 
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  ChevronRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface Stats {
  totalVendas: number;
  totalPedidos: number;
  pedidosAbertos: number;
  estoqueBaixo: number;
}

const StatCard = ({ title, value, icon: Icon, color, trend }: { title: string, value: string | number, icon: any, color: string, trend?: string }) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
    <div className="flex items-start justify-between mb-4">
      <div className={`p-3 rounded-xl ${color}`}>
        <Icon size={24} className="text-white" />
      </div>
      {trend && (
        <div className={`flex items-center gap-1 text-xs font-bold ${trend.startsWith('+') ? 'text-emerald-500' : 'text-rose-500'}`}>
          {trend}
          {trend.startsWith('+') ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
        </div>
      )}
    </div>
    <p className="text-sm font-medium text-slate-500 mb-1">{title}</p>
    <h3 className="text-2xl font-bold text-slate-900">{value}</h3>
  </div>
);

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [recentOrders, setRecentOrders] = useState<any[]>([]);

  const fetchStats = () => {
    fetch('/api/relatorios/stats')
      .then(res => res.json())
      .then(setStats);
  };

  const fetchRecentOrders = () => {
    fetch('/api/pedidos')
      .then(res => res.json())
      .then(data => setRecentOrders(data.slice(0, 5)));
  };

  useEffect(() => {
    fetchStats();
    fetchRecentOrders();
  }, []);

  const updateStatus = async (id: number, status: string) => {
    await fetch(`/api/pedidos/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    fetchRecentOrders();
    fetchStats();
  };

  if (!stats) return <div className="animate-pulse space-y-8">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {[1,2,3,4].map(i => <div key={i} className="h-32 bg-slate-200 rounded-2xl"></div>)}
    </div>
  </div>;

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Dashboard</h2>
        <p className="text-slate-500">Bem-vindo de volta! Aqui está o resumo de hoje.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Vendas Totais" 
          value={`${stats.totalVendas.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}`} 
          icon={TrendingUp} 
          color="bg-indigo-500"
          trend="+12.5%"
        />
        <StatCard 
          title="Total de Pedidos" 
          value={stats.totalPedidos} 
          icon={ShoppingBag} 
          color="bg-emerald-500"
          trend="+8.2%"
        />
        <StatCard 
          title="Pedidos em Aberto" 
          value={stats.pedidosAbertos} 
          icon={Clock} 
          color="bg-amber-500"
        />
        <StatCard 
          title="Estoque Baixo" 
          value={stats.estoqueBaixo} 
          icon={AlertTriangle} 
          color="bg-rose-500"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 card-shadow overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-900">Pedidos Recentes</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                  <th className="px-6 py-4 font-semibold">ID</th>
                  <th className="px-6 py-4 font-semibold">Cliente</th>
                  <th className="px-6 py-4 font-semibold">Data</th>
                  <th className="px-6 py-4 font-semibold">Status</th>
                  <th className="px-6 py-4 font-semibold text-right">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-slate-50 transition-colors cursor-pointer group">
                    <td className="px-6 py-4 text-sm font-mono text-slate-500">#{order.id}</td>
                    <td className="px-6 py-4">
                      <p className="text-sm font-semibold text-slate-900">{order.cliente_nome}</p>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {new Date(order.data).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4">
                      <select 
                        value={order.status}
                        onChange={(e) => updateStatus(order.id, e.target.value)}
                        className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider border-none focus:ring-2 focus:ring-primary/20 outline-none cursor-pointer transition-colors ${
                          order.status === 'recebido' ? 'bg-blue-100 text-blue-600' :
                          order.status === 'processando' ? 'bg-amber-100 text-amber-600' :
                          order.status === 'pronto' ? 'bg-emerald-100 text-emerald-600' :
                          order.status === 'entregue' ? 'bg-slate-100 text-slate-600' :
                          'bg-rose-100 text-rose-600'
                        }`}
                      >
                        <option value="recebido">Recebido</option>
                        <option value="processando">Processando</option>
                        <option value="pronto">Pronto</option>
                        <option value="entregue">Entregue</option>
                        <option value="cancelado">Cancelado</option>
                      </select>
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-slate-900 text-right">
                      {order.total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Actions / Info */}
        <div className="space-y-6">
          <div className="bg-primary text-white p-6 rounded-2xl shadow-xl shadow-primary/20 relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="text-lg font-bold mb-2">Novo Pedido</h3>
              <p className="text-white/70 text-sm mb-6">Inicie um novo atendimento de forma rápida e prática.</p>
              <Link 
                to="/pedidos/novo"
                className="inline-flex items-center gap-2 bg-white text-primary px-6 py-3 rounded-xl font-bold text-sm hover:bg-slate-100 transition-colors"
              >
                Começar Agora
              </Link>
            </div>
            <ShoppingBag className="absolute -right-4 -bottom-4 text-white/10 w-32 h-32 rotate-12" />
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
            <h3 className="font-bold text-slate-900 mb-4">Dica do Dia</h3>
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-xl bg-amber-100 flex items-center justify-center shrink-0">
                <AlertTriangle className="text-amber-600" size={24} />
              </div>
              <div>
                <p className="text-sm text-slate-600 leading-relaxed">
                  Lembre-se de conferir o estoque de amaciante. O consumo aumentou 15% esta semana.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
