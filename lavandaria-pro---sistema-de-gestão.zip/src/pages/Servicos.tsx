import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Trash2, 
  Search, 
  Shirt, 
  Tag, 
  DollarSign
} from 'lucide-react';

interface Servico {
  id: number;
  nome: string;
  preco: number;
  categoria: string;
}

export default function Servicos() {
  const [servicos, setServicos] = useState<Servico[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  
  // New service form
  const [nome, setNome] = useState('');
  const [preco, setPreco] = useState('');
  const [categoria, setCategoria] = useState('Vestuário');

  useEffect(() => {
    fetchServicos();
  }, []);

  const fetchServicos = () => {
    fetch('/api/servicos')
      .then(res => res.json())
      .then(setServicos);
  };

  const handleAddServico = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome || !preco) return;

    setLoading(true);
    try {
      const res = await fetch('/api/servicos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nome,
          preco: parseFloat(preco),
          categoria
        })
      });

      if (res.ok) {
        setNome('');
        setPreco('');
        setCategoria('Vestuário');
        fetchServicos();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir este serviço?')) return;

    try {
      const res = await fetch(`/api/servicos/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchServicos();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const filtered = servicos.filter(s => 
    s.nome.toLowerCase().includes(search.toLowerCase()) || 
    s.categoria.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Catálogo de Serviços</h2>
          <p className="text-slate-500">Gerencie as peças e preços oferecidos pela sua lavanderia.</p>
        </div>
      </div>

      {/* Inline Add Form */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
        <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Plus size={20} className="text-primary" />
          Adicionar Novo Serviço
        </h3>
        <form onSubmit={handleAddServico} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div className="md:col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Nome da Peça</label>
            <input 
              type="text" 
              required
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Ex: Camisa, Edredom..."
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none font-medium text-sm"
            />
          </div>
          <div className="md:col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Categoria</label>
            <select 
              value={categoria}
              onChange={(e) => setCategoria(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none font-medium text-sm"
            >
              <option value="Vestuário">Vestuário</option>
              <option value="Cama/Banho">Cama/Banho</option>
              <option value="Cozinha">Cozinha</option>
              <option value="Especial">Especial</option>
              <option value="Outros">Outros</option>
            </select>
          </div>
          <div className="md:col-span-1">
            <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Preço (AOA)</label>
            <input 
              type="number" 
              step="0.01"
              required
              value={preco}
              onChange={(e) => setPreco(e.target.value)}
              placeholder="0.00"
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none font-bold text-sm"
            />
          </div>
          <button 
            type="submit"
            disabled={loading}
            className="bg-primary text-white px-6 py-2.5 rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg shadow-primary/20 disabled:opacity-50 h-[42px]"
          >
            {loading ? 'Salvando...' : 'Adicionar Serviço'}
          </button>
        </form>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 card-shadow overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar serviço ou categoria..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-primary/20 outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider font-bold">
                <th className="px-6 py-4">Serviço</th>
                <th className="px-6 py-4">Categoria</th>
                <th className="px-6 py-4 text-right">Preço Base</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((servico) => (
                <tr key={servico.id} className="hover:bg-slate-50 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-slate-100 text-slate-500 rounded-xl flex items-center justify-center">
                        <Shirt size={20} />
                      </div>
                      <p className="text-sm font-bold text-slate-900">{servico.nome}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-1 rounded-lg">
                      {servico.categoria}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm font-bold text-slate-900 text-right">
                    {servico.preco.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => handleDelete(servico.id)}
                      className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                      title="Excluir Serviço"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-slate-400 italic">
                    Nenhum serviço encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Adicionar Serviço removed as it's now inline */}
    </div>
  );
}
