import React, { useState } from 'react';
import { Building2, User, Mail, Lock, Phone, MapPin, ArrowRight, ShieldCheck } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import { User as UserType } from '../types';

export default function Register({ onRegister }: { onRegister: (user: UserType) => void }) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // Laundry Data
  const [lavandariaNome, setLavandariaNome] = useState('');
  const [lavandariaNomeComercial, setLavandariaNomeComercial] = useState('');
  const [lavandariaEndereco, setLavandariaEndereco] = useState('');
  const [lavandariaTelefone, setLavandariaTelefone] = useState('');
  const [lavandariaEmail, setLavandariaEmail] = useState('');
  const [lavandariaNif, setLavandariaNif] = useState('');
  const [lavandariaRegistoComercial, setLavandariaRegistoComercial] = useState('');
  const [lavandariaTipoEmpresa, setLavandariaTipoEmpresa] = useState('Lda');
  const [lavandariaDataConstituicao, setLavandariaDataConstituicao] = useState('');
  const [lavandariaRegimeFiscal, setLavandariaRegimeFiscal] = useState('Regime Geral');
  const [lavandariaPercentagemIva, setLavandariaPercentagemIva] = useState('14');
  const [lavandariaSujeitoRetencao, setLavandariaSujeitoRetencao] = useState(false);
  const [lavandariaContaBancaria, setLavandariaContaBancaria] = useState('');
  const [lavandariaIban, setLavandariaIban] = useState('');
  const [lavandariaBanco, setLavandariaBanco] = useState('');

  // Admin Data
  const [adminNome, setAdminNome] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminSenha, setAdminSenha] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/register-lavandaria', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lavandariaNome, lavandariaNomeComercial, lavandariaEndereco, lavandariaTelefone, 
          lavandariaEmail, lavandariaNif, lavandariaRegistoComercial, lavandariaTipoEmpresa, 
          lavandariaDataConstituicao, lavandariaRegimeFiscal, lavandariaPercentagemIva,
          lavandariaSujeitoRetencao, lavandariaContaBancaria, lavandariaIban, lavandariaBanco,
          adminNome, adminEmail, adminSenha
        })
      });

      if (res.ok) {
        const user = await res.json();
        onRegister(user);
        navigate('/');
      } else {
        const data = await res.json();
        setError(data.error || 'Erro ao realizar cadastro.');
      }
    } catch (err) {
      setError('Erro ao conectar com o servidor.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-2xl text-white font-bold text-3xl mb-4 shadow-xl shadow-primary/20">
            L
          </div>
          <h1 className="text-3xl font-bold text-slate-900">Lavanderia<span className="text-accent">Pro</span></h1>
          <p className="text-slate-500 mt-2">Cadastre sua lavanderia e comece a gerir seu negócio</p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 card-shadow">
          {/* Progress Bar */}
          <div className="flex items-center justify-between mb-10 px-4">
            <div className={`flex flex-col items-center gap-2 ${step >= 1 ? 'text-primary' : 'text-slate-300'}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 ${step >= 1 ? 'border-primary bg-primary text-white' : 'border-slate-200'}`}>1</div>
              <span className="text-xs font-bold uppercase tracking-wider">Lavanderia</span>
            </div>
            <div className={`flex-1 h-1 mx-4 rounded-full ${step >= 2 ? 'bg-primary' : 'bg-slate-100'}`}></div>
            <div className={`flex flex-col items-center gap-2 ${step >= 2 ? 'text-primary' : 'text-slate-300'}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold border-2 ${step >= 2 ? 'border-primary bg-primary text-white' : 'border-slate-200'}`}>2</div>
              <span className="text-xs font-bold uppercase tracking-wider">Administrador</span>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {step === 1 ? (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="flex items-center gap-2 mb-4">
                  <Building2 className="text-accent" size={20} />
                  <h2 className="text-lg font-bold text-slate-900">Dados da Lavanderia</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Nome da Lavanderia (Empresa)</label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text" required
                        value={lavandariaNome}
                        onChange={(e) => setLavandariaNome(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="Ex: Lavanderia Brilho, Lda"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Nome Comercial (Opcional)</label>
                    <div className="relative">
                      <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text"
                        value={lavandariaNomeComercial}
                        onChange={(e) => setLavandariaNomeComercial(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="Nome fantasia"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Telefone</label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="tel" required
                        value={lavandariaTelefone}
                        onChange={(e) => setLavandariaTelefone(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="(00) 00000-0000"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">NIF da Empresa</label>
                    <div className="relative">
                      <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text" required
                        value={lavandariaNif}
                        onChange={(e) => setLavandariaNif(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="NIF da Empresa"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Registo Comercial</label>
                    <div className="relative">
                      <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text" required
                        value={lavandariaRegistoComercial}
                        onChange={(e) => setLavandariaRegistoComercial(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="Nº de Registo Comercial"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Tipo de Empresa</label>
                    <select 
                      value={lavandariaTipoEmpresa}
                      onChange={(e) => setLavandariaTipoEmpresa(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                    >
                      <option value="Empresário em Nome Individual">Empresário em Nome Individual</option>
                      <option value="Sociedade Unipessoal">Sociedade Unipessoal</option>
                      <option value="Lda">Lda</option>
                      <option value="S.A">S.A</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Data de Constituição</label>
                    <input 
                      type="date" required
                      value={lavandariaDataConstituicao}
                      onChange={(e) => setLavandariaDataConstituicao(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                    />
                  </div>

                  <div className="md:col-span-2 border-t border-slate-100 pt-6 mt-2">
                    <h4 className="text-sm font-bold text-primary uppercase tracking-wider mb-4">Informações Fiscais</h4>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Regime Fiscal</label>
                    <select 
                      value={lavandariaRegimeFiscal}
                      onChange={(e) => setLavandariaRegimeFiscal(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                    >
                      <option value="Regime Geral">Regime Geral</option>
                      <option value="Regime Simplificado">Regime Simplificado</option>
                      <option value="Regime de Não Sujeição ao IVA">Regime de Não Sujeição ao IVA</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Percentagem de IVA (%)</label>
                    <input 
                      type="number" required
                      value={lavandariaPercentagemIva}
                      onChange={(e) => setLavandariaPercentagemIva(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                      placeholder="Ex: 14"
                    />
                  </div>

                  <div className="flex items-center gap-3 py-3">
                    <input 
                      type="checkbox"
                      id="sujeito_retencao"
                      checked={lavandariaSujeitoRetencao}
                      onChange={(e) => setLavandariaSujeitoRetencao(e.target.checked)}
                      className="w-5 h-5 text-primary border-slate-300 rounded focus:ring-primary"
                    />
                    <label htmlFor="sujeito_retencao" className="text-sm font-semibold text-slate-700 cursor-pointer">
                      Está sujeito a retenção na fonte?
                    </label>
                  </div>

                  <div className="md:col-span-2 border-t border-slate-100 pt-6 mt-2">
                    <h4 className="text-sm font-bold text-primary uppercase tracking-wider mb-4">Dados Bancários</h4>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Banco</label>
                    <input 
                      type="text" required
                      value={lavandariaBanco}
                      onChange={(e) => setLavandariaBanco(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                      placeholder="Nome do Banco"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Número de Conta</label>
                    <input 
                      type="text" required
                      value={lavandariaContaBancaria}
                      onChange={(e) => setLavandariaContaBancaria(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                      placeholder="Nº da Conta"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">IBAN</label>
                    <input 
                      type="text" required
                      value={lavandariaIban}
                      onChange={(e) => setLavandariaIban(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                      placeholder="AO06 0000 0000 0000 0000 0000 0"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">E-mail da Empresa</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="email" required
                        value={lavandariaEmail}
                        onChange={(e) => setLavandariaEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="contato@lavanderia.com"
                      />
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Endereço Completo</label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text" required
                        value={lavandariaEndereco}
                        onChange={(e) => setLavandariaEndereco(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="Rua, Número, Bairro, Cidade"
                      />
                    </div>
                  </div>
                </div>

                <button 
                  type="button"
                  onClick={() => setStep(2)}
                  className="w-full bg-primary hover:bg-slate-800 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-primary/20"
                >
                  Próximo Passo <ArrowRight size={20} />
                </button>
              </div>
            ) : (
              <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="flex items-center gap-2 mb-4">
                  <ShieldCheck className="text-accent" size={20} />
                  <h2 className="text-lg font-bold text-slate-900">Dados do Administrador</h2>
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Nome Completo</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="text" required
                        value={adminNome}
                        onChange={(e) => setAdminNome(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="Seu nome"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">E-mail de Acesso</label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="email" required
                        value={adminEmail}
                        onChange={(e) => setAdminEmail(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="admin@email.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">Senha</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                      <input 
                        type="password" required
                        value={adminSenha}
                        onChange={(e) => setAdminSenha(e.target.value)}
                        className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>
                </div>

                {error && (
                  <div className="p-3 bg-rose-50 text-rose-600 text-sm rounded-lg font-medium">
                    {error}
                  </div>
                )}

                <div className="flex gap-4">
                  <button 
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-600 py-4 rounded-xl font-bold transition-all"
                  >
                    Voltar
                  </button>
                  <button 
                    type="submit"
                    disabled={loading}
                    className="flex-[2] bg-primary hover:bg-slate-800 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-primary/20 disabled:opacity-50"
                  >
                    {loading ? 'Cadastrando...' : 'Finalizar Cadastro'}
                  </button>
                </div>
              </div>
            )}

            <div className="text-center pt-4">
              <p className="text-sm text-slate-500">
                Já tem uma conta? <Link to="/login" className="text-primary font-bold hover:underline">Faça login</Link>
              </p>
            </div>
          </form>
        </div>

        <p className="text-center text-xs text-slate-400 mt-8">
          &copy; 2026 LavanderiaPro. Todos os direitos reservados.
        </p>
      </div>
    </div>
  );
}
