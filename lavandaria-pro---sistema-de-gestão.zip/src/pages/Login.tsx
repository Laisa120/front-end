import React, { useState } from 'react';
import { LogIn, ShieldCheck, Mail, Lock, Building2, Shirt, Waves, Zap } from 'lucide-react';
import { User } from '../types';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';

export default function Login({ onLogin }: { onLogin: (user: User) => void }) {
  const [view, setView] = useState<'login' | 'recovery'>('login');
  const [email, setEmail] = useState('admin@lavanderia.com');
  const [senha, setSenha] = useState('admin123');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    if (view === 'login') {
      try {
        const res = await fetch('/api/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, senha })
        });

        if (res.ok) {
          const user = await res.json();
          onLogin(user);
        } else {
          setError('E-mail ou senha incorretos.');
        }
      } catch (err) {
        setError('Erro ao conectar com o servidor.');
      } finally {
        setLoading(false);
      }
    } else {
      try {
        const res = await fetch('/api/recover-password', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email })
        });

        if (res.ok) {
          setSuccess('Instruções de recuperação enviadas para o seu e-mail.');
          setTimeout(() => setView('login'), 5000);
        } else {
          setError('E-mail não encontrado em nossa base.');
        }
      } catch (err) {
        setError('Erro ao processar solicitação.');
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="min-h-screen flex bg-gradient-to-br from-blue-600 via-indigo-700 to-purple-800 overflow-hidden relative">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          animate={{ 
            y: [0, -20, 0],
            rotate: [0, 5, 0]
          }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[10%] left-[5%] opacity-20"
        >
          <Shirt size={120} className="text-white" />
        </motion.div>
        <motion.div 
          animate={{ 
            y: [0, 20, 0],
            rotate: [0, -5, 0]
          }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute bottom-[15%] left-[10%] opacity-20"
        >
          <Waves size={100} className="text-white" />
        </motion.div>
        <motion.div 
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.1, 0.2, 0.1]
          }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-[20%] right-[15%] opacity-10"
        >
          <Zap size={150} className="text-white" />
        </motion.div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row items-center justify-center p-4 sm:p-8 z-10">
        {/* Left Side: Visuals (Desktop) */}
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="hidden lg:flex flex-col items-start justify-center text-white max-w-xl pr-12"
        >
          <div className="w-20 h-20 bg-white/20 backdrop-blur-md rounded-3xl flex items-center justify-center text-white font-bold text-4xl mb-8 shadow-2xl border border-white/30">
            L
          </div>
          <h1 className="text-6xl font-black tracking-tighter mb-6 leading-tight">
            Cuidamos das suas roupas, <br />
            <span className="text-blue-200">você cuida do seu tempo.</span>
          </h1>
          <p className="text-xl text-blue-100/80 font-medium leading-relaxed mb-8">
            O sistema de gestão mais completo para lavanderias profissionais. 
            Controle tudo, desde a entrada até a entrega final.
          </p>
          
          <div className="grid grid-cols-2 gap-6 w-full">
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-2xl border border-white/10">
              <img 
                src="https://images.unsplash.com/photo-1545173168-9f1947eebb7f?auto=format&fit=crop&q=80&w=300&h=200" 
                alt="Washing Machine" 
                className="w-full h-32 object-cover rounded-xl mb-4"
                referrerPolicy="no-referrer"
              />
              <p className="text-sm font-bold uppercase tracking-widest text-blue-200">Eficiência</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm p-6 rounded-2xl border border-white/10">
              <img 
                src="https://images.unsplash.com/photo-1489274495757-95c7c837b101?auto=format&fit=crop&q=80&w=300&h=200" 
                alt="Ironing" 
                className="w-full h-32 object-cover rounded-xl mb-4"
                referrerPolicy="no-referrer"
              />
              <p className="text-sm font-bold uppercase tracking-widest text-blue-200">Qualidade</p>
            </div>
          </div>
        </motion.div>

        {/* Right Side: Login Form */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-full max-w-md"
        >
          <div className="bg-white/95 backdrop-blur-xl p-8 sm:p-10 rounded-[2.5rem] shadow-2xl border border-white/20">
            <div className="lg:hidden text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-2xl text-white font-bold text-3xl mb-4 shadow-xl shadow-primary/20">
                L
              </div>
              <h1 className="text-3xl font-bold text-slate-900">Lavanderia<span className="text-accent">Pro</span></h1>
            </div>

            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center">
                <ShieldCheck size={24} />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-900 leading-tight">
                  {view === 'login' ? 'Bem-vindo de volta' : 'Recuperar acesso'}
                </h2>
                <p className="text-slate-500 text-sm">
                  {view === 'login' ? 'Entre com suas credenciais' : 'Enviaremos um link para seu e-mail'}
                </p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">E-mail Corporativo</label>
                <div className="relative group">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors" size={20} />
                  <input 
                    type="email" 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none text-slate-900 font-medium"
                    placeholder="seu@email.com"
                  />
                </div>
              </div>

              {view === 'login' && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center ml-1">
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Senha de Acesso</label>
                    <button 
                      type="button"
                      onClick={() => { setView('recovery'); setError(''); setSuccess(''); }}
                      className="text-xs text-primary font-bold hover:text-blue-700 transition-colors"
                    >
                      Esqueceu?
                    </button>
                  </div>
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors" size={20} />
                    <input 
                      type="password" 
                      required={view === 'login'}
                      value={senha}
                      onChange={(e) => setSenha(e.target.value)}
                      className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-primary/10 focus:border-primary transition-all outline-none text-slate-900 font-medium"
                      placeholder="••••••••"
                    />
                  </div>
                </div>
              )}

              <AnimatePresence mode="wait">
                {error && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-4 bg-rose-50 text-rose-600 text-sm rounded-2xl font-bold flex items-center gap-2"
                  >
                    <div className="w-1.5 h-1.5 bg-rose-600 rounded-full animate-pulse" />
                    {error}
                  </motion.div>
                )}

                {success && (
                  <motion.div 
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="p-4 bg-emerald-50 text-emerald-600 text-sm rounded-2xl font-bold flex items-center gap-2"
                  >
                    <div className="w-1.5 h-1.5 bg-emerald-600 rounded-full animate-pulse" />
                    {success}
                  </motion.div>
                )}
              </AnimatePresence>

              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-primary hover:bg-slate-800 text-white py-5 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all shadow-xl shadow-primary/20 disabled:opacity-50 active:scale-[0.98]"
              >
                {loading ? (
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    {view === 'login' ? <LogIn size={22} /> : <Mail size={22} />}
                    <span className="text-lg">{view === 'login' ? 'Entrar no Sistema' : 'Recuperar Senha'}</span>
                  </>
                )}
              </button>

              {view === 'recovery' && (
                <button 
                  type="button"
                  onClick={() => { setView('login'); setError(''); setSuccess(''); }}
                  className="w-full text-sm text-slate-500 font-bold hover:text-slate-900 transition-colors py-2"
                >
                  Voltar para o Login
                </button>
              )}
            </form>
          </div>
          
          <p className="text-center text-xs text-white/60 mt-8 font-medium">
            &copy; 2026 LavanderiaPro. Tecnologia para o cuidado têxtil.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
