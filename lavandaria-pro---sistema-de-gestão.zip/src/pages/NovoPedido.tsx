import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Plus, 
  Trash2, 
  Calculator, 
  Calendar,
  UserPlus,
  CheckCircle2,
  Shirt
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Cliente } from '../types';

interface ServicoCatalog {
  id: number;
  nome: string;
  preco: number;
  categoria: string;
}

const SERVICOS_ADICIONAIS: Record<string, number> = {
  'Lavar e Passar': 0,
  'Apenas Lavar': -5.00,
  'Apenas Passar': -5.00,
  'Lavagem a Seco': 15.00
};

export default function NovoPedido() {
  const navigate = useNavigate();
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [servicosCatalog, setServicosCatalog] = useState<ServicoCatalog[]>([]);
  const [searchCliente, setSearchCliente] = useState('');
  const [selectedCliente, setSelectedCliente] = useState<Cliente | null>(null);
  const [itens, setItens] = useState<any[]>([]);
  const [prazo, setPrazo] = useState('');
  const [loading, setLoading] = useState(false);

  // Form states for new item
  const [tipoPeca, setTipoPeca] = useState('');
  const [servico, setServico] = useState('Lavar e Passar');
  const [tipoServicoGeral, setTipoServicoGeral] = useState('Normal');
  const [quantidade, setQuantidade] = useState(1);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [newServiceName, setNewServiceName] = useState('');
  const [newServicePrice, setNewServicePrice] = useState('');

  useEffect(() => {
    fetch('/api/clientes')
      .then(res => res.json())
      .then(setClientes);
    
    fetch('/api/servicos')
      .then(res => res.json())
      .then(data => {
        setServicosCatalog(data);
        if (data.length > 0) {
          setTipoPeca(data[0].nome);
        }
      });
    
    // Default deadline: 3 days from now
    const d = new Date();
    d.setDate(d.getDate() + 3);
    setPrazo(d.toISOString().split('T')[0]);
  }, []);

  const filteredClientes = clientes.filter(c => 
    c.nome.toLowerCase().includes(searchCliente.toLowerCase()) || 
    c.telefone.includes(searchCliente)
  );

  const addItem = () => {
    const selectedCatalogItem = servicosCatalog.find(s => s.nome === tipoPeca);
    const basePreco = selectedCatalogItem ? selectedCatalogItem.preco : 0;
    const extra = SERVICOS_ADICIONAIS[servico];
    const preco = Math.max(5, basePreco + extra);

    setItens([...itens, {
      id: Date.now(),
      tipo_peca: tipoPeca,
      servico: servico,
      preco: preco,
      quantidade: quantidade
    }]);
  };

  const handleQuickAdd = async () => {
    if (!newServiceName || !newServicePrice) return;
    
    try {
      const res = await fetch('/api/servicos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nome: newServiceName,
          preco: parseFloat(newServicePrice),
          categoria: 'Geral'
        })
      });

      if (res.ok) {
        const data = await res.json();
        const newService = {
          id: data.id,
          nome: newServiceName,
          preco: parseFloat(newServicePrice),
          categoria: 'Geral'
        };
        setServicosCatalog([...servicosCatalog, newService]);
        setTipoPeca(newServiceName);
        setNewServiceName('');
        setNewServicePrice('');
        setShowQuickAdd(false);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const removeItem = (id: number) => {
    setItens(itens.filter(i => i.id !== id));
  };

  const total = itens.reduce((acc, item) => acc + (item.preco * item.quantidade), 0);

  const handleSubmit = async () => {
    if (!selectedCliente || itens.length === 0) return;
    setLoading(true);

    try {
      const res = await fetch('/api/pedidos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cliente_id: selectedCliente.id,
          prazo_entrega: prazo,
          itens: itens,
          tipo_servico: tipoServicoGeral
        })
      });

      if (res.ok) {
        navigate('/pedidos');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Novo Serviço</h2>
          <p className="text-slate-500">Registre as peças e serviços para o cliente.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Customer & Items Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Customer Selection */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
            <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
              <UserPlus size={20} className="text-primary" />
              1. Selecionar Cliente
            </h3>
            
            {!selectedCliente ? (
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input 
                    type="text" 
                    placeholder="Buscar por nome ou telefone..."
                    value={searchCliente}
                    onChange={(e) => setSearchCliente(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none"
                  />
                </div>
                {searchCliente && (
                  <div className="border border-slate-100 rounded-xl overflow-hidden divide-y divide-slate-100 max-h-48 overflow-y-auto">
                    {filteredClientes.map(c => (
                      <button 
                        key={c.id}
                        onClick={() => setSelectedCliente(c)}
                        className="w-full text-left px-4 py-3 hover:bg-slate-50 transition-colors flex items-center justify-between"
                      >
                        <div>
                          <p className="font-semibold text-slate-900">{c.nome}</p>
                          <p className="text-xs text-slate-500">{c.telefone}</p>
                        </div>
                        <Plus size={16} className="text-slate-400" />
                      </button>
                    ))}
                    {filteredClientes.length === 0 && (
                      <div className="p-4 text-center text-sm text-slate-500">Nenhum cliente encontrado.</div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center justify-between bg-emerald-50 border border-emerald-100 p-4 rounded-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-white font-bold">
                    {selectedCliente.nome.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-emerald-900">{selectedCliente.nome}</p>
                    <p className="text-xs text-emerald-600">{selectedCliente.telefone}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setSelectedCliente(null)}
                  className="text-xs font-bold text-emerald-600 hover:underline"
                >
                  Alterar
                </button>
              </div>
            )}
          </div>

          {/* Items Form */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow">
            <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Shirt size={20} className="text-primary" />
              2. Adicionar Peças
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="sm:col-span-1">
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase">Peça</label>
                  <button 
                    onClick={() => setShowQuickAdd(!showQuickAdd)}
                    className="text-[10px] font-bold text-primary hover:underline"
                  >
                    {showQuickAdd ? 'Cancelar' : '+ Nova Peça'}
                  </button>
                </div>
                {showQuickAdd ? (
                  <div className="space-y-2">
                    <input 
                      type="text"
                      placeholder="Nome da peça"
                      value={newServiceName}
                      onChange={(e) => setNewServiceName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none"
                    />
                    <div className="flex gap-2">
                      <input 
                        type="number"
                        placeholder="Preço"
                        value={newServicePrice}
                        onChange={(e) => setNewServicePrice(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm outline-none"
                      />
                      <button 
                        onClick={handleQuickAdd}
                        className="bg-primary text-white px-3 py-2 rounded-xl text-xs font-bold"
                      >
                        OK
                      </button>
                    </div>
                  </div>
                ) : (
                  <select 
                    value={tipoPeca}
                    onChange={(e) => setTipoPeca(e.target.value)}
                    className="w-full px-3 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none"
                  >
                    {servicosCatalog.map(p => <option key={p.id} value={p.nome}>{p.nome}</option>)}
                  </select>
                )}
              </div>
              <div className="sm:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Serviço</label>
                <select 
                  value={servico}
                  onChange={(e) => setServico(e.target.value)}
                  className="w-full px-3 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none"
                >
                  {Object.keys(SERVICOS_ADICIONAIS).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="sm:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Qtd</label>
                <input 
                  type="number" 
                  min="1"
                  value={quantidade}
                  onChange={(e) => setQuantidade(parseInt(e.target.value))}
                  className="w-full px-3 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none"
                />
              </div>
              <div className="flex items-end sm:col-span-1">
                <button 
                  onClick={addItem}
                  className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-colors"
                >
                  <Plus size={18} />
                  Adicionar
                </button>
              </div>
            </div>

            {/* Items List */}
            <div className="border border-slate-100 rounded-xl overflow-x-auto">
              <table className="w-full text-left min-w-[500px]">
                <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase tracking-wider font-bold">
                  <tr>
                    <th className="px-4 py-3">Peça</th>
                    <th className="px-4 py-3">Serviço</th>
                    <th className="px-4 py-3">Qtd</th>
                    <th className="px-4 py-3 text-right">Preço Un.</th>
                    <th className="px-4 py-3 text-right">Subtotal</th>
                    <th className="px-4 py-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {itens.map((item) => (
                    <tr key={item.id} className="text-sm">
                      <td className="px-4 py-3 font-semibold text-slate-900">{item.tipo_peca}</td>
                      <td className="px-4 py-3 text-slate-500">{item.servico}</td>
                      <td className="px-4 py-3 text-slate-500">{item.quantidade}</td>
                      <td className="px-4 py-3 text-right text-slate-500">{item.preco.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</td>
                      <td className="px-4 py-3 text-right font-bold text-slate-900">{(item.preco * item.quantidade).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</td>
                      <td className="px-4 py-3 text-right">
                        <button 
                          onClick={() => removeItem(item.id)}
                          className="p-1 text-rose-500 hover:bg-rose-50 rounded-lg transition-colors"
                        >
                          <Trash2 size={16} />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {itens.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-4 py-8 text-center text-slate-400 italic">
                        Nenhuma peça adicionada ainda.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right Column: Summary & Finalize */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 card-shadow sticky top-8">
            <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Calculator size={20} className="text-primary" />
              Resumo do Serviço
            </h3>
            
            <div className="space-y-4 mb-8">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Tipo de Serviço</label>
                <select 
                  value={tipoServicoGeral}
                  onChange={(e) => setTipoServicoGeral(e.target.value)}
                  className="w-full px-3 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none font-semibold"
                >
                  <option value="Normal">Normal</option>
                  <option value="Express">Express (24h)</option>
                  <option value="Premium">Premium</option>
                  <option value="Especial">Especial</option>
                </select>
              </div>
            </div>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Subtotal</span>
                <span className="font-semibold text-slate-900">{total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Desconto</span>
                <span className="font-semibold text-emerald-500">- { (0).toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' }) }</span>
              </div>
              <div className="pt-4 border-t border-slate-100 flex justify-between items-end">
                <span className="text-slate-900 font-bold">Total</span>
                <span className="text-3xl font-black text-primary">{total.toLocaleString('pt-AO', { style: 'currency', currency: 'AOA' })}</span>
              </div>
            </div>

            <div className="space-y-4 mb-8">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-2 flex items-center gap-1">
                  <Calendar size={14} />
                  Prazo de Entrega
                </label>
                <input 
                  type="date" 
                  value={prazo}
                  onChange={(e) => setPrazo(e.target.value)}
                  className="w-full px-3 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/20 outline-none font-semibold"
                />
              </div>
            </div>

            <button 
              onClick={handleSubmit}
              disabled={loading || !selectedCliente || itens.length === 0}
              className="w-full bg-primary hover:bg-slate-800 text-white py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-lg shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Processando...' : (
                <>
                  <CheckCircle2 size={20} />
                  Finalizar Serviço
                </>
              )}
            </button>
            
            <p className="text-[10px] text-center text-slate-400 mt-4 uppercase tracking-widest font-bold">
              Gera Comprovativo de Serviço Automático
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
