export type UserRole = 'admin' | 'vendedor' | 'operador' | 'cliente' | 'gerente_caixa';

export interface User {
  id: number;
  nome: string;
  email: string;
  role: UserRole;
  telefone?: string;
}

export interface Cliente {
  id: number;
  nome: string;
  telefone: string;
  email?: string;
  endereco?: string;
  nif?: string;
  data_cadastro: string;
}

export type PedidoStatus = 'recebido' | 'processando' | 'pronto' | 'entregue' | 'cancelado';

export interface Pedido {
  id: number;
  cliente_id: number;
  cliente_nome?: string;
  data: string;
  status: PedidoStatus;
  tipo_servico?: string;
  total: number;
  pago: number; // 0 or 1
  prazo_entrega: string;
}

export interface ItemPedido {
  id: number;
  pedido_id: number;
  tipo_peca: string;
  servico: string;
  preco: number;
  quantidade: number;
}

export interface ProdutoEstoque {
  id: number;
  produto: string;
  quantidade: number;
  unidade: string;
  minimo_alerta: number;
}

export interface Lavandaria {
  id: number;
  nome: string;
  nome_comercial?: string;
  endereco?: string;
  telefone?: string;
  email?: string;
  nif?: string;
  registo_comercial?: string;
  tipo_empresa?: string;
  data_constituicao?: string;
  regime_fiscal?: string;
  percentagem_iva?: number;
  sujeito_retencao?: boolean;
  conta_bancaria?: string;
  iban?: string;
  banco?: string;
  data_cadastro: string;
}

export interface Venda {
  id: number;
  pedido_id: number;
  forma_pagamento: string;
  valor_pago: number;
  desconto: number;
  data_pagamento: string;
}
