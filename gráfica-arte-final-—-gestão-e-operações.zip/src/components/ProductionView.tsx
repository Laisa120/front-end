import React, { useState } from 'react';
import {
  Kanban,
  Clock,
  AlertTriangle,
  UserCheck,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  FileText,
  AlertCircle,
  Package,
  Wrench,
  X,
  Plus,
  RefreshCw,
  Printer,
} from 'lucide-react';
import { Order, User, ProductionStageNumber, StockItem } from '../types';
import { formatKz, formatDate, formatDateTime, getDaysRemaining } from '../utils/formatters';
import { PRODUCTION_STAGES } from '../services/mockData';

interface ProductionViewProps {
  orders: Order[];
  users: User[];
  stock: StockItem[];
  currentUser: User;
  onUpdateStage: (orderId: string, stage: ProductionStageNumber, note?: string) => void;
  onAssignOperator: (orderId: string, operatorId: string, operatorName: string) => void;
  onReportIssue: (orderId: string, reason: string, stage: ProductionStageNumber) => void;
  onResolveIssue: (orderId: string, issueId: string, solution: string) => void;
  onDeductStock: (order: Order) => void;
  onSelectOrder: (order: Order) => void;
}

export const ProductionView: React.FC<ProductionViewProps> = ({
  orders,
  users,
  stock,
  currentUser,
  onUpdateStage,
  onAssignOperator,
  onReportIssue,
  onResolveIssue,
  onDeductStock,
  onSelectOrder,
}) => {
  const [selectedStage, setSelectedStage] = useState<ProductionStageNumber | 'all'>('all');
  const [operatorFilter, setOperatorFilter] = useState<string>('all');
  const [issueModalOrder, setIssueModalOrder] = useState<Order | null>(null);
  const [issueReason, setIssueReason] = useState('');

  const operators = users.filter(u => u.role === 'operador' || u.role === 'designer');

  // Filtrar ordens não canceladas
  const productionOrders = orders.filter(o => o.status !== 'cancelado');

  const filteredOrders = productionOrders.filter(order => {
    const matchesStage = selectedStage === 'all' || order.productionStage === selectedStage;
    const matchesOperator =
      operatorFilter === 'all'
        ? true
        : operatorFilter === 'unassigned'
        ? !order.assignedOperatorId
        : order.assignedOperatorId === operatorFilter;
    return matchesStage && matchesOperator;
  });

  const handleOpenIssueModal = (order: Order) => {
    setIssueModalOrder(order);
    setIssueReason('');
  };

  const handleSubmitIssue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!issueModalOrder || !issueReason.trim()) return;
    onReportIssue(issueModalOrder.id, issueReason, issueModalOrder.productionStage);
    setIssueModalOrder(null);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Kanban className="w-6 h-6 text-[#13B8DB]" />
            <span>Centro de Controlo da Produção Gráfica</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Monitorização operacional das 9 fases de fabrico gráfico, atribuição de operadores e gestão de não-conformidades.
          </p>
        </div>

        {/* Estatísticas Rápidas de Produção */}
        <div className="flex items-center gap-3">
          <div className="px-3 py-1.5 rounded-lg bg-sky-50 border border-sky-200 text-xs">
            <span className="text-slate-500 font-semibold">Em Fabricação: </span>
            <span className="font-bold text-[#062E3B]">{orders.filter(o => o.status === 'em_producao').length}</span>
          </div>
          <div className="px-3 py-1.5 rounded-lg bg-red-50 border border-red-200 text-xs">
            <span className="text-red-700 font-semibold">Atrasados: </span>
            <span className="font-bold text-red-700">
              {orders.filter(o => o.status !== 'entregue' && getDaysRemaining(o.deadline).isOverdue).length}
            </span>
          </div>
        </div>
      </div>

      {/* Navegador das 9 Fases Industriais */}
      <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm overflow-x-auto">
        <div className="flex items-center gap-1.5 min-w-[900px]">
          <button
            onClick={() => setSelectedStage('all')}
            className={`px-3 py-2 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
              selectedStage === 'all'
                ? 'bg-[#062E3B] text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Todas as Fases ({productionOrders.length})
          </button>

          {PRODUCTION_STAGES.map(stage => {
            const count = productionOrders.filter(o => o.productionStage === stage.stage && o.status !== 'entregue').length;
            const isSelected = selectedStage === stage.stage;

            return (
              <button
                key={stage.stage}
                onClick={() => setSelectedStage(stage.stage)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  isSelected
                    ? 'bg-[#13B8DB] text-[#062E3B] font-bold shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200'
                }`}
                title={stage.description}
              >
                <span className="w-4 h-4 rounded-full bg-slate-200 text-slate-800 text-[10px] font-black flex items-center justify-center">
                  {stage.stage}
                </span>
                <span className="truncate max-w-[120px]">{stage.name}</span>
                {count > 0 && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    isSelected ? 'bg-[#062E3B] text-white' : 'bg-slate-700 text-white'
                  }`}>
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Filtro por Operador */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs bg-white p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-700">Filtrar por Operador:</span>
          <select
            value={operatorFilter}
            onChange={e => setOperatorFilter(e.target.value)}
            className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded text-xs font-medium"
          >
            <option value="all">Todos os Operadores</option>
            <option value="unassigned">Sem Operador Atribuído</option>
            {operators.map(op => (
              <option key={op.id} value={op.id}>{op.name} ({op.role.toUpperCase()})</option>
            ))}
          </select>
        </div>

        <div className="text-slate-500 font-medium">
          A exibir <span className="font-bold text-slate-900">{filteredOrders.length}</span> trabalhos na linha de produção
        </div>
      </div>

      {/* Cartões de Acompanhamento da Produção */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredOrders.map(order => {
          const { days, isOverdue } = getDaysRemaining(order.deadline);
          const stageInfo = PRODUCTION_STAGES.find(s => s.stage === order.productionStage);
          const isDelivered = order.status === 'entregue';
          const hasIssues = order.issues && order.issues.filter(i => !i.resolved).length > 0;

          return (
            <div
              key={order.id}
              className={`bg-white rounded-xl border p-4.5 shadow-sm transition-all flex flex-col justify-between ${
                isOverdue && !isDelivered
                  ? 'border-red-300 ring-1 ring-red-200'
                  : hasIssues
                  ? 'border-amber-300 ring-1 ring-amber-200'
                  : 'border-slate-200 hover:border-[#13B8DB]'
              }`}
            >
              <div>
                {/* Linha de Cabeçalho do Cartão */}
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div>
                    <span className="font-black text-sm text-slate-900">{order.number}</span>
                    <div className="font-bold text-xs text-[#13B8DB] truncate max-w-[200px]">
                      {order.clientName}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                      order.priority === 'urgente'
                        ? 'bg-red-100 text-red-800'
                        : order.priority === 'alta'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      {order.priority}
                    </span>
                  </div>
                </div>

                {/* Itens do Trabalho */}
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 mb-3 text-xs">
                  <div className="font-semibold text-slate-800">
                    {order.items.map(i => `${i.quantity}x ${i.serviceName}`).join(' · ')}
                  </div>
                  {order.notes && (
                    <div className="text-[11px] text-slate-500 mt-1 italic">
                      "{order.notes}"
                    </div>
                  )}
                </div>

                {/* Fase Industrial Actual */}
                <div className="space-y-1 mb-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                      Fase Industrial ({order.productionStage}/9)
                    </span>
                    <span className="text-[11px] font-bold text-[#062E3B]">
                      {stageInfo?.name}
                    </span>
                  </div>

                  {/* Barra de Progresso das 9 Etapas */}
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden flex">
                    <div
                      className={`h-full transition-all duration-300 ${
                        isDelivered
                          ? 'bg-[#1E7620]'
                          : isOverdue
                          ? 'bg-red-500'
                          : 'bg-[#13B8DB]'
                      }`}
                      style={{ width: `${(order.productionStage / 9) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Prazos e Responsável */}
                <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-100">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Prazo de Entrega</span>
                    {isDelivered ? (
                      <span className="font-bold text-[#1E7620]">Entregue</span>
                    ) : isOverdue ? (
                      <span className="font-bold text-red-600 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Atrasado {days}d
                      </span>
                    ) : (
                      <span className="font-semibold text-slate-700">{formatDate(order.deadline)}</span>
                    )}
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-semibold block">Operador Resp.</span>
                    <select
                      value={order.assignedOperatorId || ''}
                      onChange={e => {
                        const op = operators.find(x => x.id === e.target.value);
                        onAssignOperator(order.id, op?.id || '', op?.name || 'Não atribuído');
                      }}
                      className="w-full text-xs font-semibold text-slate-800 bg-transparent border-b border-slate-200 focus:outline-none"
                    >
                      <option value="">Atribuir operador...</option>
                      {operators.map(op => (
                        <option key={op.id} value={op.id}>{op.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Alerta de Problema / Ocorrência em Aberto */}
                {hasIssues && (
                  <div className="mt-2.5 p-2 rounded bg-amber-50 border border-amber-200 text-[11px] text-amber-900">
                    <span className="font-bold">Ocorrência Registada: </span>
                    {order.issues.find(i => !i.resolved)?.reason}
                  </div>
                )}
              </div>

              {/* Controles de Avanço Sequencial de Etapas */}
              <div className="pt-3 mt-3 border-t border-slate-100 space-y-2">
                <div className="flex items-center justify-between gap-1.5">
                  {/* Voltar Etapa (Correcção / Reprovação) */}
                  <button
                    disabled={order.productionStage <= 1}
                    onClick={() => onUpdateStage(order.id, (order.productionStage - 1) as ProductionStageNumber, 'Devolvido para correcção na etapa anterior')}
                    className="p-1.5 border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-30 rounded text-xs"
                    title="Devolver para etapa anterior"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  {/* Avançar para a Próxima Etapa */}
                  {order.productionStage < 9 ? (
                    <button
                      onClick={() => onUpdateStage(order.id, (order.productionStage + 1) as ProductionStageNumber)}
                      className="flex-1 py-1.5 px-3 bg-[#13B8DB] hover:bg-[#0ea5c4] text-[#062E3B] font-bold text-xs rounded transition-colors flex items-center justify-center gap-1"
                    >
                      <span>Avançar para Etapa {order.productionStage + 1}</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <div className="flex-1 py-1.5 text-center text-xs font-bold text-[#1E7620] bg-green-50 rounded">
                      ✓ Produção & Entrega Concluídas
                    </div>
                  )}

                  {/* Registar Problema / Ocorrência */}
                  <button
                    onClick={() => handleOpenIssueModal(order)}
                    className="p-1.5 border border-amber-200 text-amber-700 hover:bg-amber-50 rounded text-xs"
                    title="Registar problema de qualidade ou material"
                  >
                    <Wrench className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filteredOrders.length === 0 && (
          <div className="col-span-full p-12 text-center text-slate-400 bg-white rounded-xl border border-slate-200">
            Nenhum trabalho encontrado nesta fase ou para o operador selecionado.
          </div>
        )}
      </div>

      {/* Modal de Registo de Problemas / Ocorrências na Produção */}
      {issueModalOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Registar Ocorrência de Produção</h3>
                <p className="text-[11px] text-[#13B8DB]">{issueModalOrder.number} — Fase {issueModalOrder.productionStage}</p>
              </div>
              <button onClick={() => setIssueModalOrder(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitIssue} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Motivo da Ocorrência / Problema Identificado *
                </label>
                <textarea
                  required
                  rows={3}
                  value={issueReason}
                  onChange={e => setIssueReason(e.target.value)}
                  placeholder="ex: Falha de alinhamento no corte, cor cyan com desvio em relação à prova aprovada, falta de vinil em stock..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIssueModalOrder(null)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg shadow-sm"
                >
                  Registar Ocorrência
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
