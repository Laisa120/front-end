import React, { useState } from 'react';
import {
  Wallet,
  Plus,
  ArrowDownLeft,
  ArrowUpRight,
  DollarSign,
  Printer,
  CheckCircle2,
  Lock,
  Unlock,
  AlertTriangle,
  Receipt,
  Search,
  Calendar,
  X,
  CreditCard,
  Building2,
} from 'lucide-react';
import { CashMovement, CashSession, MovementType, PaymentMethod, User, Store, Order, Service } from '../types';
import { formatKz, formatDate, formatDateTime } from '../utils/formatters';

interface CashViewProps {
  cashMovements: CashMovement[];
  cashSession: CashSession;
  orders: Order[];
  services?: Service[];
  stores: Store[];
  activeStoreId: string;
  currentUser: User;
  onAddMovement: (movement: Omit<CashMovement, 'id'>) => void;
  onCloseSession: (actualBalance: number, notes?: string) => void;
  onOpenSession: (initialBalance: number, notes?: string) => void;
  onPrintReceipt: (movement: CashMovement) => void;
}

export const CashView: React.FC<CashViewProps> = ({
  cashMovements,
  cashSession,
  orders,
  services = [],
  stores,
  activeStoreId,
  currentUser,
  onAddMovement,
  onCloseSession,
  onOpenSession,
  onPrintReceipt,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [methodFilter, setMethodFilter] = useState<string>('all');
  const [isNewMovementModalOpen, setIsNewMovementModalOpen] = useState(false);
  const [isCloseSessionModalOpen, setIsCloseSessionModalOpen] = useState(false);
  const [isOpenSessionModalOpen, setIsOpenSessionModalOpen] = useState(false);

  // Form Movimento State
  const [movementType, setMovementType] = useState<MovementType>('entrada');
  const [serviceName, setServiceName] = useState<string>('');
  const [selectedServiceId, setSelectedServiceId] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [unitPrice, setUnitPrice] = useState<number>(0);
  const [amount, setAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('dinheiro');
  const [selectedOrderId, setSelectedOrderId] = useState<string>('');

  // Form Fecho / Abertura de Caixa
  const [countedCash, setCountedCash] = useState<number>(0);
  const [sessionNotes, setSessionNotes] = useState('');
  const [newSessionFloat, setNewSessionFloat] = useState<number>(50000);

  // Filtros de Movimentos
  const filteredMovements = cashMovements.filter(m => {
    const matchesSearch =
      m.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.receiptNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (m.clientName && m.clientName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (m.orderNumber && m.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesType = typeFilter === 'all' || m.type === typeFilter;
    const matchesMethod = methodFilter === 'all' || m.paymentMethod === methodFilter;

    return matchesSearch && matchesType && matchesMethod;
  });

  // Cálculos de Caixa
  const totalEntries = cashMovements
    .filter(m => ['pagamento_encomenda', 'adiantamento', 'pagamento_parcial', 'entrada'].includes(m.type))
    .reduce((sum, m) => sum + m.amount, 0);

  const totalExits = cashMovements
    .filter(m => ['despesa', 'saida'].includes(m.type))
    .reduce((sum, m) => sum + m.amount, 0);

  const currentBalance = (cashSession.initialBalance || 0) + totalEntries - totalExits;

  // Total de Dívidas Pendentes na Carteira
  const totalReceivables = orders
    .filter(o => o.status !== 'cancelado')
    .reduce((sum, o) => sum + o.balanceDue, 0);

  // Discriminado por método
  const multicaixaTotal = cashMovements
    .filter(m => m.paymentMethod === 'multicaixa' && ['pagamento_encomenda', 'adiantamento', 'pagamento_parcial', 'entrada'].includes(m.type))
    .reduce((sum, m) => sum + m.amount, 0);

  const cashPhysicalTotal = cashMovements
    .filter(m => m.paymentMethod === 'dinheiro' && ['pagamento_encomenda', 'adiantamento', 'pagamento_parcial', 'entrada'].includes(m.type))
    .reduce((sum, m) => sum + m.amount, 0);

  const transferTotal = cashMovements
    .filter(m => m.paymentMethod === 'transferencia' && ['pagamento_encomenda', 'adiantamento', 'pagamento_parcial', 'entrada'].includes(m.type))
    .reduce((sum, m) => sum + m.amount, 0);

  const handleOpenNewMovement = () => {
    setMovementType('entrada');
    const firstService = services && services.length > 0 ? services[0] : null;
    if (firstService) {
      setSelectedServiceId(firstService.id);
      setServiceName(firstService.name);
      setUnitPrice(firstService.price);
      setQuantity(1);
      setAmount(firstService.price * 1);
    } else {
      setSelectedServiceId('outro');
      setServiceName('');
      setUnitPrice(10000);
      setQuantity(1);
      setAmount(10000);
    }
    setPaymentMethod('dinheiro');
    setSelectedOrderId('');
    setIsNewMovementModalOpen(true);
  };

  const handleServiceSelect = (serviceId: string) => {
    setSelectedServiceId(serviceId);
    if (serviceId === 'outro') {
      setServiceName('');
      setUnitPrice(0);
      setAmount(0);
    } else {
      const srv = services.find(s => s.id === serviceId);
      if (srv) {
        setServiceName(srv.name);
        setUnitPrice(srv.price);
        const currentQty = quantity > 0 ? quantity : 1;
        setAmount(srv.price * currentQty);
      }
    }
  };

  const handleQuantityChange = (newQty: number) => {
    const qty = Math.max(1, newQty);
    setQuantity(qty);
    setAmount(unitPrice * qty);
  };

  const handleUnitPriceChange = (newPrice: number) => {
    const price = Math.max(0, newPrice);
    setUnitPrice(price);
    const currentQty = quantity > 0 ? quantity : 1;
    setAmount(price * currentQty);
  };

  const handleAmountChange = (newAmount: number) => {
    const total = Math.max(0, newAmount);
    setAmount(total);
    if (quantity > 0) {
      setUnitPrice(Math.round(total / quantity));
    }
  };

  const handleSubmitMovement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serviceName.trim()) {
      alert('Por favor, informe ou selecione o nome do serviço.');
      return;
    }
    if (amount <= 0 || quantity <= 0) {
      alert('Preencha uma quantidade e valor válidos para o movimento.');
      return;
    }

    const order = orders.find(o => o.id === selectedOrderId);
    const generatedDescription = `${quantity}x ${serviceName.trim()}`;

    onAddMovement({
      storeId: activeStoreId === 'all' ? 'store-001' : activeStoreId,
      sessionId: cashSession.id,
      timestamp: new Date().toISOString(),
      type: movementType,
      amount,
      serviceName: serviceName.trim(),
      quantity,
      unitPrice,
      description: generatedDescription,
      paymentMethod,
      orderId: order?.id,
      orderNumber: order?.number,
      clientName: order?.clientName,
      receiptNumber: `REC-${Date.now().toString().slice(-6)}`,
      responsibleUser: currentUser.name,
    });

    setIsNewMovementModalOpen(false);
  };

  const handleConfirmClose = () => {
    onCloseSession(countedCash, sessionNotes);
    setIsCloseSessionModalOpen(false);
  };

  const handleConfirmOpen = () => {
    onOpenSession(newSessionFloat, sessionNotes);
    setIsOpenSessionModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Wallet className="w-6 h-6 text-[#1E7620]" />
            <span>Módulo de Caixa & Tesouraria Diária</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Registo de fluxos financeiros, pagamentos de encomendas, fecho de turnos e controlo de trocos.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {cashSession.status === 'aberto' ? (
            <>
              <button
                onClick={() => {
                  setCountedCash(currentBalance);
                  setIsCloseSessionModalOpen(true);
                }}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-lg shadow-sm transition-colors"
              >
                <Lock className="w-4 h-4 text-amber-400" />
                <span>Fechar Sessão</span>
              </button>

              <button
                onClick={handleOpenNewMovement}
                className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-4 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Lançar Movimento</span>
              </button>
            </>
          ) : (
            <button
              onClick={() => {
                setNewSessionFloat(50000);
                setIsOpenSessionModalOpen(true);
              }}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 bg-[#1E7620] hover:bg-green-700 text-white font-bold text-xs rounded-lg shadow-sm transition-colors"
            >
              <Unlock className="w-4 h-4" />
              <span>Abrir Nova Sessão de Caixa</span>
            </button>
          )}
        </div>
      </div>

      {/* Cartões com Resumo do Caixa (Secção 10) */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Saldo Atual em Caixa */}
        <div className="bg-[#062E3B] text-white rounded-xl p-4 border border-[#0b4556] shadow-sm col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-[#13B8DB] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Saldo em Caixa</span>
            <Wallet className="w-4 h-4 text-[#F7CB18]" />
          </div>
          <div className="text-lg sm:text-xl font-black text-[#F7CB18] tabular-nums">
            {formatKz(currentBalance)}
          </div>
          <div className="text-[10px] text-slate-300 mt-1 flex items-center gap-1">
            <span className={`w-2 h-2 rounded-full ${cashSession.status === 'aberto' ? 'bg-emerald-400' : 'bg-red-400'}`} />
            <span>Sessão: {cashSession.status.toUpperCase()}</span>
          </div>
        </div>

        {/* Total de Entradas */}
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Entradas de Hoje</span>
            <ArrowDownLeft className="w-4 h-4 text-[#1E7620]" />
          </div>
          <div className="text-base sm:text-lg font-black text-[#1E7620] tabular-nums">
            +{formatKz(totalEntries)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            {cashMovements.filter(m => m.type.startsWith('pagamento') || m.type === 'adiantamento').length} pagamentos de clientes
          </div>
        </div>

        {/* Saídas / Despesas */}
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Despesas / Saídas</span>
            <ArrowUpRight className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-base sm:text-lg font-black text-rose-600 tabular-nums">
            -{formatKz(totalExits)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Custos operacionais diários
          </div>
        </div>

        {/* Fundo de Troco Inicial */}
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Fundo de Troco</span>
            <Receipt className="w-4 h-4 text-[#13B8DB]" />
          </div>
          <div className="text-base sm:text-lg font-black text-slate-800 tabular-nums">
            {formatKz(cashSession.initialBalance)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Aberto por {cashSession.openedBy}
          </div>
        </div>

        {/* Saldos por Receber da Carteira */}
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Valores a Receber</span>
            <CreditCard className="w-4 h-4 text-[#E41179]" />
          </div>
          <div className="text-base sm:text-lg font-black text-[#E41179] tabular-nums">
            {formatKz(totalReceivables)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Saldos pendentes de entrega
          </div>
        </div>
      </div>

      {/* Desdobramento por Método de Pagamento */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Multicaixa / TPA</span>
            <span className="font-bold text-slate-900">{formatKz(multicaixaTotal)}</span>
          </div>
          <CreditCard className="w-4 h-4 text-[#13B8DB]" />
        </div>

        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Dinheiro Físico</span>
            <span className="font-bold text-slate-900">{formatKz(cashPhysicalTotal)}</span>
          </div>
          <DollarSign className="w-4 h-4 text-[#1E7620]" />
        </div>

        <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Transferências Bancárias</span>
            <span className="font-bold text-slate-900">{formatKz(transferTotal)}</span>
          </div>
          <Building2 className="w-4 h-4 text-[#062E3B]" />
        </div>
      </div>

      {/* Barra de Filtros e Pesquisa */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pesquisar por recibo, descrição, cliente ou encomenda..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#13B8DB] text-slate-900"
          />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold"
          >
            <option value="all">Todos os Tipos</option>
            <option value="adiantamento">Adiantamentos</option>
            <option value="pagamento_encomenda">Pagamentos Finais</option>
            <option value="despesa">Despesas</option>
            <option value="entrada">Entradas Avulsas</option>
          </select>

          <select
            value={methodFilter}
            onChange={e => setMethodFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold"
          >
            <option value="all">Todos os Métodos</option>
            <option value="multicaixa">Multicaixa</option>
            <option value="dinheiro">Dinheiro</option>
            <option value="transferencia">Transferência</option>
          </select>
        </div>
      </div>

      {/* Tabela de Movimentos de Caixa */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[620px] text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Recibo / Data</th>
                <th className="px-3 py-3">Tipo de Operação</th>
                <th className="px-3 py-3">Descrição & Documento</th>
                <th className="px-3 py-3">Método</th>
                <th className="px-3 py-3">Responsável</th>
                <th className="px-4 py-3 text-right">Montante (Kz)</th>
                <th className="px-4 py-3 text-right">Recibo</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredMovements.map(movement => {
                const isExit = movement.type === 'despesa' || movement.type === 'saida';

                return (
                  <tr key={movement.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="font-bold text-slate-900 font-mono">{movement.receiptNumber}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{formatDateTime(movement.timestamp)}</div>
                    </td>

                    <td className="px-3 py-3.5">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                        isExit ? 'bg-red-100 text-red-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {movement.type.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="px-3 py-3.5 text-slate-800">
                      <div className="font-semibold">{movement.description}</div>
                      {movement.quantity && movement.unitPrice ? (
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                          {movement.quantity} un × {formatKz(movement.unitPrice)}
                        </div>
                      ) : null}
                      {(movement.orderNumber || movement.clientName) && (
                        <div className="text-[10px] text-[#13B8DB] font-medium mt-0.5">
                          {movement.orderNumber && `Encomenda ${movement.orderNumber} · `}
                          {movement.clientName}
                        </div>
                      )}
                    </td>

                    <td className="px-3 py-3.5 uppercase font-mono text-slate-600">
                      {movement.paymentMethod}
                    </td>

                    <td className="px-3 py-3.5 text-slate-600">
                      {movement.responsibleUser}
                    </td>

                    <td className={`px-4 py-3.5 text-right font-black tabular-nums ${
                      isExit ? 'text-rose-600' : 'text-[#1E7620]'
                    }`}>
                      {isExit ? '-' : '+'}{formatKz(movement.amount)}
                    </td>

                    <td className="px-4 py-3.5 text-right">
                      <button
                        onClick={() => onPrintReceipt(movement)}
                        className="p-1.5 text-slate-500 hover:text-[#062E3B] hover:bg-slate-100 rounded"
                        title="Imprimir Recibo de Pagamento"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}

              {filteredMovements.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    Nenhum movimento registado com os critérios selecionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Lançamento de Movimento de Caixa */}
      {isNewMovementModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Lançar Movimento de Caixa</h3>
                <p className="text-[11px] text-[#13B8DB]">Registo financeiro com emissão de recibo</p>
              </div>
              <button onClick={() => setIsNewMovementModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitMovement} className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Tipo de Operação</label>
                <select
                  value={movementType}
                  onChange={e => setMovementType(e.target.value as MovementType)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none"
                >
                  <option value="entrada">Entrada Avulsa em Caixa</option>
                  <option value="pagamento_encomenda">Liquidação Final de Encomenda</option>
                  <option value="adiantamento">Adiantamento de Encomenda</option>
                  <option value="despesa">Despesa Operacional / Saída</option>
                </select>
              </div>

              {/* Nome do Serviço */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nome do Serviço *
                </label>
                {services && services.length > 0 && (
                  <div className="mb-2">
                    <select
                      value={selectedServiceId}
                      onChange={e => handleServiceSelect(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-[#13B8DB] focus:outline-none text-slate-800"
                    >
                      <option value="outro">— Escolher do catálogo de serviços —</option>
                      {services.map(s => (
                        <option key={s.id} value={s.id}>
                          {s.name} ({formatKz(s.price)} / {s.unit})
                        </option>
                      ))}
                    </select>
                  </div>
                )}
                <input
                  type="text"
                  required
                  placeholder="ex: Cartões de Visita, Lona Frontlit 510g, Roll-up..."
                  value={serviceName}
                  onChange={e => {
                    setServiceName(e.target.value);
                    if (selectedServiceId !== 'outro') {
                      setSelectedServiceId('outro');
                    }
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              {/* Quantidade e Preço Unitário */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Quantidade *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={quantity}
                    onChange={e => handleQuantityChange(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Preço Unitário (Kz) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={unitPrice}
                    onChange={e => handleUnitPriceChange(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>
              </div>

              {/* Caixa de Cálculo Automático Consoante a Quantidade e Preço */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span className="font-semibold">Cálculo Automático:</span>
                  <span className="font-mono text-slate-700 font-bold">
                    {quantity} un × {formatKz(unitPrice)}
                  </span>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                  <span className="text-xs font-bold text-slate-900">Montante Total Calculado:</span>
                  <span className="text-sm font-black font-mono text-[#062E3B] tabular-nums">
                    {formatKz(amount)}
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Montante a Movimentar (Kz) *
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={amount}
                  onChange={e => handleAmountChange(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-black text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Forma de Pagamento</label>
                <select
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none"
                >
                  <option value="dinheiro">Dinheiro Físico</option>
                  <option value="multicaixa">Multicaixa (TPA)</option>
                  <option value="transferencia">Transferência Bancária</option>
                  <option value="outro">Outro Meio</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsNewMovementModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
                >
                  Registar Movimento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Fecho de Caixa */}
      {isCloseSessionModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Fecho da Sessão de Caixa</h3>
                <p className="text-[11px] text-amber-300">Conferência final do turno diário</p>
              </div>
              <button onClick={() => setIsCloseSessionModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1">
                <div className="flex justify-between">
                  <span>Fundo Inicial:</span>
                  <span className="font-mono">{formatKz(cashSession.initialBalance)}</span>
                </div>
                <div className="flex justify-between text-emerald-700">
                  <span>Total Entradas:</span>
                  <span className="font-mono font-bold">+{formatKz(totalEntries)}</span>
                </div>
                <div className="flex justify-between text-rose-600">
                  <span>Total Despesas:</span>
                  <span className="font-mono font-bold">-{formatKz(totalExits)}</span>
                </div>
                <div className="flex justify-between font-black text-sm pt-1 border-t border-slate-200 text-[#062E3B]">
                  <span>Saldo Esperado pelo Sistema:</span>
                  <span className="font-mono">{formatKz(currentBalance)}</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Saldo Real Contado em Caixa (Kz) *
                </label>
                <input
                  type="number"
                  value={countedCash}
                  onChange={e => setCountedCash(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-black text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
                {countedCash !== currentBalance && (
                  <div className="text-[11px] font-bold text-amber-700 mt-1 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Diferença apurada: {formatKz(countedCash - currentBalance)}</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Observações do Fecho de Turno
                </label>
                <textarea
                  rows={2}
                  value={sessionNotes}
                  onChange={e => setSessionNotes(e.target.value)}
                  placeholder="Justificação de eventuais quebras de caixa, notas recolhidas para depósito..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCloseSessionModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmClose}
                  className="px-5 py-2 bg-slate-900 hover:bg-black text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5"
                >
                  <Lock className="w-4 h-4 text-amber-400" />
                  <span>Confirmar Fecho</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Abertura de Nova Sessão */}
      {isOpenSessionModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Abertura de Sessão de Caixa</h3>
                <p className="text-[11px] text-[#13B8DB]">Início de novo turno de atendimento</p>
              </div>
              <button onClick={() => setIsOpenSessionModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Fundo de Troco Inicial (Kz) *
                </label>
                <input
                  type="number"
                  min="0"
                  value={newSessionFloat}
                  onChange={e => setNewSessionFloat(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Notas de Abertura
                </label>
                <textarea
                  rows={2}
                  value={sessionNotes}
                  onChange={e => setSessionNotes(e.target.value)}
                  placeholder="ex: Fundo de 50.000 Kz em notas miúdas para trocos no balcão."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsOpenSessionModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmOpen}
                  className="px-5 py-2 bg-[#1E7620] hover:bg-green-700 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5"
                >
                  <Unlock className="w-4 h-4" />
                  <span>Abrir Caixa</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
