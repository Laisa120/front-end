import React, { useState } from 'react';
import {
  ShieldCheck,
  Plus,
  Search,
  UserCheck,
  Lock,
  Building2,
  Mail,
  Phone,
  Clock,
  CheckCircle2,
  XCircle,
  X,
  Edit2,
  Eye,
} from 'lucide-react';
import { User, UserRole, Store } from '../types';
import { formatDate, formatDateTime } from '../utils/formatters';

interface StaffViewProps {
  users: User[];
  stores: Store[];
  currentUser: User;
  onAddUser: (user: Omit<User, 'id' | 'createdAt'>) => void;
  onUpdateUser: (user: User) => void;
  onSwitchUser: (user: User) => void;
}

export const StaffView: React.FC<StaffViewProps> = ({
  users,
  stores,
  currentUser,
  onAddUser,
  onUpdateUser,
  onSwitchUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    username: '',
    role: 'atendente' as UserRole,
    storeId: stores[0]?.id || 'store-001',
    active: true,
  });

  const roleLabels: Record<UserRole, string> = {
    admin: 'Administrador Geral',
    director: 'Directora de Operações',
    gerente: 'Gerente de Loja',
    atendente: 'Atendente Comercial',
    designer: 'Designer Gráfico',
    operador: 'Operador de Produção',
    financeiro: 'Responsável Financeiro',
    consulta: 'Apenas Consulta',
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.phone.includes(searchTerm);
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleOpenAdd = () => {
    setEditingUser(null);
    setFormData({
      name: '',
      email: '',
      phone: '',
      username: '',
      role: 'atendente',
      storeId: stores[0]?.id || 'store-001',
      active: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      name: user.name,
      email: user.email,
      phone: user.phone,
      username: user.username,
      role: user.role,
      storeId: user.storeId,
      active: user.active,
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.email.trim() || !formData.username.trim()) return;

    if (editingUser) {
      onUpdateUser({
        ...editingUser,
        ...formData,
      });
    } else {
      onAddUser(formData);
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-[#13B8DB]" />
            <span>Funcionários, Utilizadores & Perfis de Acesso</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Gestão de contas corporativas, atribuição de lojas físicas e isolamento de privilégios operacionais.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Novo Funcionário</span>
        </button>
      </div>

      {/* Matriz Visual de Perfis de Acesso (RBAC) */}
      <div className="bg-[#062E3B] text-white p-5 rounded-xl border border-[#0b4556] shadow-sm">
        <h3 className="font-bold text-xs uppercase tracking-wider text-[#F7CB18] mb-3 flex items-center gap-2">
          <Lock className="w-4 h-4" />
          <span>Matriz de Controlo de Acesso e Permissões (RBAC)</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-center text-xs">
          {[
            { role: 'admin', label: 'Admin Geral', desc: 'Acesso total irrestrito' },
            { role: 'director', label: 'Directora', desc: 'Supervisão e relatórios' },
            { role: 'gerente', label: 'Gerente', desc: 'Gestão da loja e caixa' },
            { role: 'atendente', label: 'Atendente', desc: 'Clientes e orçamentos' },
            { role: 'designer', label: 'Designer', desc: 'Artes e aprovação' },
            { role: 'operador', label: 'Operador', desc: 'Impressão e acabamento' },
            { role: 'financeiro', label: 'Financeiro', desc: 'Caixa e liquidações' },
            { role: 'consulta', label: 'Consulta', desc: 'Apenas leitura' },
          ].map(p => (
            <div key={p.role} className="p-2.5 rounded-lg bg-[#041d26] border border-[#0b4556]">
              <div className="font-black text-[11px] text-[#13B8DB]">{p.label}</div>
              <div className="text-[10px] text-slate-300 mt-1">{p.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Barra de Filtros e Pesquisa */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pesquisar por nome, email ou utilizador..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] text-slate-900 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={roleFilter}
            onChange={e => setRoleFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold"
          >
            <option value="all">Todos os Perfis</option>
            <option value="admin">Administrador Geral</option>
            <option value="director">Directora de Operações</option>
            <option value="gerente">Gerente</option>
            <option value="atendente">Atendente</option>
            <option value="designer">Designer</option>
            <option value="operador">Operador</option>
            <option value="financeiro">Financeiro</option>
          </select>
        </div>
      </div>

      {/* Tabela de Utilizadores */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[620px] text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Funcionário / Identificador</th>
                <th className="px-3 py-3">Perfil de Acesso</th>
                <th className="px-3 py-3">Loja Associada</th>
                <th className="px-3 py-3">Contactos</th>
                <th className="px-3 py-3 text-center">Estado</th>
                <th className="px-4 py-3 text-right">Acções Operacionais</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.map(user => {
                const isCurrent = user.id === currentUser.id;
                const userStore = stores.find(s => s.id === user.storeId);

                return (
                  <tr key={user.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-[#062E3B] text-[#F7CB18] font-bold text-xs flex items-center justify-center shrink-0">
                          {user.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-bold text-slate-900">{user.name}</div>
                          <div className="text-[10px] text-slate-400 font-mono">@{user.username}</div>
                        </div>
                      </div>
                    </td>

                    <td className="px-3 py-3.5">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded capitalize ${
                        user.role === 'admin'
                          ? 'bg-amber-100 text-amber-800'
                          : user.role === 'operador' || user.role === 'designer'
                          ? 'bg-sky-100 text-sky-800'
                          : user.role === 'financeiro'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-800'
                      }`}>
                        {roleLabels[user.role]}
                      </span>
                    </td>

                    <td className="px-3 py-3.5 text-slate-600">
                      {user.storeId === 'all' ? (
                        <span className="font-bold text-[#062E3B]">Todas as Unidades (Geral)</span>
                      ) : (
                        <span>{userStore?.code} — {userStore?.name}</span>
                      )}
                    </td>

                    <td className="px-3 py-3.5 text-slate-600">
                      <div className="font-mono">{user.phone}</div>
                      <div className="text-[10px] text-slate-400">{user.email}</div>
                    </td>

                    <td className="px-3 py-3.5 text-center">
                      <span className={`w-2 h-2 inline-block rounded-full ${user.active ? 'bg-emerald-500' : 'bg-slate-300'}`} />
                    </td>

                    <td className="px-4 py-3.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-2">
                        {/* Botão de Alternar Perfil */}
                        {!isCurrent ? (
                          <button
                            onClick={() => onSwitchUser(user)}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] rounded transition-colors flex items-center gap-1"
                            title="Alternar para esta conta para testar permissões"
                          >
                            <UserCheck className="w-3.5 h-3.5 text-[#13B8DB]" />
                            <span>Simular Acesso</span>
                          </button>
                        ) : (
                          <span className="text-[10px] text-[#1E7620] font-black bg-emerald-50 px-2 py-0.5 rounded">
                            Sessão Actual
                          </span>
                        )}

                        <button
                          onClick={() => handleOpenEdit(user)}
                          className="p-1 text-slate-400 hover:text-slate-700 rounded"
                          title="Editar Funcionário"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Criar / Editar Funcionário */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">
                  {editingUser ? 'Editar Funcionário' : 'Novo Funcionário'}
                </h3>
                <p className="text-[11px] text-[#13B8DB]">Atribuição de credenciais e perfil de responsabilidade</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nome Completo *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nome de Utilizador *</label>
                  <input
                    type="text"
                    required
                    value={formData.username}
                    onChange={e => setFormData({ ...formData, username: e.target.value })}
                    placeholder="ex: jandira.atend"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Perfil de Acesso (RBAC) *</label>
                  <select
                    value={formData.role}
                    onChange={e => setFormData({ ...formData, role: e.target.value as UserRole })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold"
                  >
                    <option value="atendente">Atendente Comercial</option>
                    <option value="designer">Designer Gráfico</option>
                    <option value="operador">Operador de Produção</option>
                    <option value="financeiro">Responsável Financeiro</option>
                    <option value="gerente">Gerente de Loja</option>
                    <option value="director">Directora de Operações</option>
                    <option value="admin">Administrador Geral</option>
                    <option value="consulta">Apenas Consulta</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Telefone *</label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Email Corporativo *</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>

                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Unidade / Loja Associada</label>
                  <select
                    value={formData.storeId}
                    onChange={e => setFormData({ ...formData, storeId: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold"
                  >
                    <option value="all">Todas as Lojas (Apenas Directoria/Admin)</option>
                    {stores.map(s => (
                      <option key={s.id} value={s.id}>{s.code} — {s.name}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
                >
                  {editingUser ? 'Guardar Alterações' : 'Concluir Registo'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
