import React, { useState } from 'react';
import {
  Settings,
  Building2,
  Image as ImageIcon,
  Sliders,
  Database,
  Plus,
  Save,
  RotateCcw,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  X,
  Phone,
  Mail,
  MapPin,
  CreditCard,
} from 'lucide-react';
import { SystemSettings, Store, User } from '../types';
import { Logo } from './Logo';

interface SettingsViewProps {
  settings: SystemSettings;
  stores: Store[];
  currentUser: User;
  onUpdateSettings: (settings: SystemSettings) => void;
  onAddStore: (store: Omit<Store, 'id' | 'createdAt'>) => void;
  onUpdateStore: (store: Store) => void;
  onExportData: () => void;
  onImportData: (jsonStr: string) => boolean;
  onResetDefaults: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  stores,
  currentUser,
  onUpdateSettings,
  onAddStore,
  onUpdateStore,
  onExportData,
  onImportData,
  onResetDefaults,
}) => {
  const [formData, setFormData] = useState<SystemSettings>({ ...settings });
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isAddStoreModalOpen, setIsAddStoreModalOpen] = useState(false);

  // Form Nova Loja
  const [newStore, setNewStore] = useState({
    code: `LOJA 00${stores.length + 1}`,
    name: '',
    address: '',
    phone: '+244 923 000 000',
    email: '',
    manager: '',
    active: true,
  });

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, logoUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddStoreSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStore.name.trim() || !newStore.code.trim()) return;
    onAddStore(newStore);
    setIsAddStoreModalOpen(false);
    setNewStore({
      code: `LOJA 00${stores.length + 2}`,
      name: '',
      address: '',
      phone: '+244 923 000 000',
      email: '',
      manager: '',
      active: true,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        if (content) {
          const success = onImportData(content);
          if (success) {
            alert('Cópia de segurança importada com sucesso!');
          } else {
            alert('Falha ao importar o ficheiro. Formato JSON inválido.');
          }
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Settings className="w-6 h-6 text-[#13B8DB]" />
            <span>Administração & Configurações da Empresa</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Dados fiscais da gráfica, logótipo da marca, rede multi-lojas e salvaguarda de dados.
          </p>
        </div>

        {saveSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs font-bold animate-fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Configurações guardadas com sucesso!</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Coluna 1 & 2: Formulário de Definições e Multi-loja */}
        <div className="lg:col-span-2 space-y-6">
          {/* Identidade Visual e Logótipo Oficial (Requisito 1) */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
            <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-[#F7CB18]" />
              <span>Logótipo & Identidade da Marca</span>
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Por predefinição, o sistema utiliza o emblema com a mira gráfica CMYK da Gráfica Arte Final. Pode também carregar uma imagem personalizada.
            </p>

            <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-slate-50 rounded-xl border border-slate-200">
              <div className="p-3 bg-[#062E3B] rounded-xl flex items-center justify-center shrink-0">
                <Logo customLogoUrl={formData.logoUrl} />
              </div>

              <div className="space-y-3 w-full">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Carregar Ficheiro de Logótipo (PNG, JPG, SVG)
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="block w-full text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-[#13B8DB] file:text-[#062E3B] hover:file:bg-[#0ea5c4]"
                  />
                </div>

                {formData.logoUrl && (
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, logoUrl: '' })}
                    className="text-xs font-bold text-red-600 hover:underline"
                  >
                    Restaurar Logótipo Original CMYK
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Dados Fiscais e da Empresa */}
          <form onSubmit={handleSaveSettings} className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-[#13B8DB]" />
              <span>Dados Fiscais & Institucionais</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Denominação Social *</label>
                <input
                  type="text"
                  required
                  value={formData.companyName}
                  onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Nome Comercial da Marca *</label>
                <input
                  type="text"
                  required
                  value={formData.commercialName}
                  onChange={e => setFormData({ ...formData, commercialName: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">NIF (Angola) *</label>
                <input
                  type="text"
                  required
                  value={formData.nif}
                  onChange={e => setFormData({ ...formData, nif: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Taxa IVA Padrão (%)</label>
                <input
                  type="number"
                  min="0"
                  max="50"
                  value={formData.taxPercentage}
                  onChange={e => setFormData({ ...formData, taxPercentage: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Telefone Principal *</label>
                <input
                  type="text"
                  required
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Telefone Secundário</label>
                <input
                  type="text"
                  value={formData.phoneSecondary || ''}
                  onChange={e => setFormData({ ...formData, phoneSecondary: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 mb-1">Email Geral</label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 mb-1">Endereço da Sede</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>Guardar Definições</span>
              </button>
            </div>
          </form>

          {/* Gestão Multi-lojas (Arquitectura Multi-loja - Secção 3) */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#1E7620]" />
                  <span>Rede de Lojas & Filiais Físicas</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Lojas interligadas com base de dados central e isolamento operacional.
                </p>
              </div>

              <button
                onClick={() => setIsAddStoreModalOpen(true)}
                className="flex items-center gap-1 px-3 py-1.5 bg-[#062E3B] hover:bg-[#0b4556] text-white font-bold text-xs rounded-lg"
              >
                <Plus className="w-3.5 h-3.5 text-[#F7CB18]" />
                <span>Adicionar Loja</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-100 rounded-lg overflow-hidden">
              {stores.map(store => (
                <div key={store.id} className="p-3.5 flex items-center justify-between hover:bg-slate-50">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-xs text-slate-900">{store.code}</span>
                      <span className="font-bold text-xs text-[#062E3B]">{store.name}</span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${store.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'}`}>
                        {store.active ? 'Activa' : 'Em Preparação'}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">{store.address}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      Gerente: <span className="font-semibold text-slate-700">{store.manager}</span> · Tel: {store.phone}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Coluna 3: Gestão de Dados, Backups e Restauro */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Database className="w-4 h-4 text-[#13B8DB]" />
              <span>Salvaguarda & Backups da Base de Dados</span>
            </h3>
            <p className="text-xs text-slate-500">
              Exportação e importação completa de todos os registos (clientes, orçamentos, encomendas, caixa, stock e funcionários).
            </p>

            <div className="space-y-3 pt-2">
              <button
                onClick={onExportData}
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-lg transition-colors shadow-sm"
              >
                <Download className="w-4 h-4 text-[#F7CB18]" />
                <span>Descarregar Backup Completo (JSON)</span>
              </button>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Restaurar Cópia de Segurança
                </label>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleFileUpload}
                  className="block w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-[#13B8DB] file:text-[#062E3B] hover:file:bg-[#0ea5c4]"
                />
              </div>

              <div className="pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Tem a certeza que deseja restaurar os dados de demonstração iniciais? Todas as alterações actuais serão reiniciadas.')) {
                      onResetDefaults();
                    }
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2 border border-slate-300 hover:bg-red-50 hover:text-red-700 text-slate-600 font-bold text-xs rounded-lg transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Restaurar Dados Iniciais de Demonstração</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Modal Adicionar Loja */}
      {isAddStoreModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Adicionar Nova Loja Física</h3>
                <p className="text-[11px] text-[#13B8DB]">Expansão da rede de balcões da Gráfica Arte Final</p>
              </div>
              <button onClick={() => setIsAddStoreModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddStoreSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Código da Loja *</label>
                <input
                  type="text"
                  required
                  value={newStore.code}
                  onChange={e => setNewStore({ ...newStore, code: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Designação da Unidade *</label>
                <input
                  type="text"
                  required
                  value={newStore.name}
                  onChange={e => setNewStore({ ...newStore, name: e.target.value })}
                  placeholder="ex: Loja 002 — Talatona Plaza"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Endereço Completo</label>
                <input
                  type="text"
                  value={newStore.address}
                  onChange={e => setNewStore({ ...newStore, address: e.target.value })}
                  placeholder="Município, Bairro, Rua..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Telefone da Loja</label>
                <input
                  type="text"
                  value={newStore.phone}
                  onChange={e => setNewStore({ ...newStore, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Gerente Responsável</label>
                <input
                  type="text"
                  value={newStore.manager}
                  onChange={e => setNewStore({ ...newStore, manager: e.target.value })}
                  placeholder="Nome do gerente de loja"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddStoreModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
                >
                  Criar Loja
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
