import React from 'react';

interface LogoProps {
  customLogoUrl?: string;
  className?: string;
  collapsed?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ customLogoUrl, className = '', collapsed = false }) => {
  if (customLogoUrl && customLogoUrl.trim() !== '') {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        <img
          src={customLogoUrl}
          alt="Gráfica Arte Final"
          className="h-10 w-auto object-contain max-w-[180px]"
          referrerPolicy="no-referrer"
        />
        {!collapsed && (
          <div className="flex flex-col">
            <span className="font-extrabold text-sm tracking-wider text-white">GRÁFICA</span>
            <span className="font-black text-xs text-[#F7CB18] tracking-widest">ARTE FINAL</span>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Emblema Gráfico CMYK Oficial com Mira de Registo e Arcos Gráficos */}
      <div className="relative w-10 h-10 shrink-0 flex items-center justify-center rounded-lg bg-[#041D26] border border-[#13B8DB]/30 shadow-inner group-hover:border-[#F7CB18] transition-colors">
        <svg
          viewBox="0 0 100 100"
          className="w-8 h-8 drop-shadow-md"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Círculo exterior e mira gráfica de precisão */}
          <circle cx="50" cy="50" r="44" stroke="#0b4556" strokeWidth="2.5" strokeDasharray="3 3" />
          <line x1="50" y1="2" x2="50" y2="98" stroke="#13B8DB" strokeWidth="1.5" strokeOpacity="0.6" />
          <line x1="2" y1="50" x2="98" y2="50" stroke="#13B8DB" strokeWidth="1.5" strokeOpacity="0.6" />

          {/* Pétalas / Arcos Dinâmicos das Cores de Impressão */}
          {/* Cyan Superior Esquerdo */}
          <path
            d="M50 50 L20 20 C35 10 65 10 80 20 Z"
            fill="#13B8DB"
            opacity="0.95"
          />
          {/* Magenta Superior Direito */}
          <path
            d="M50 50 L80 20 C90 35 90 65 80 80 Z"
            fill="#E41179"
            opacity="0.95"
          />
          {/* Amarelo Principal Inferior Esquerdo */}
          <path
            d="M50 50 L80 80 C65 90 35 90 20 80 Z"
            fill="#F7CB18"
            opacity="0.98"
          />
          {/* Verde & Petrol Inferior Esquerdo */}
          <path
            d="M50 50 L20 80 C10 65 10 35 20 20 Z"
            fill="#1E7620"
            opacity="0.9"
          />

          {/* Núcleo Central de Impressão com Sobreposição */}
          <circle cx="50" cy="50" r="14" fill="#062E3B" stroke="#F7CB18" strokeWidth="2.5" />
          <circle cx="50" cy="50" r="6" fill="#FFFFFF" />
          <circle cx="50" cy="50" r="2.5" fill="#062E3B" />
        </svg>
      </div>

      {!collapsed && (
        <div className="flex flex-col leading-tight">
          <div className="flex items-center gap-1 sm:gap-1.5 whitespace-nowrap">
            <span className="font-extrabold text-xs sm:text-[15px] tracking-wider text-white">GRÁFICA</span>
            <span className="font-black text-xs sm:text-[15px] tracking-wider text-[#F7CB18]">ARTE FINAL</span>
          </div>
          <span className="text-[9px] sm:text-[10px] uppercase font-semibold tracking-wider sm:tracking-widest text-[#13B8DB] hidden xs:block whitespace-nowrap">
            Gestão & Operações
          </span>
        </div>
      )}
    </div>
  );
};
