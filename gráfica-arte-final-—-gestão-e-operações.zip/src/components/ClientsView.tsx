import React, { useState } from 'react';
import {
  Users,
  Search,
  Plus,
  Phone,
  Mail,
  MapPin,
  Building,
  User as UserIcon,
  Briefcase,
  FileText,
  ShoppingBag,
  DollarSign,
  AlertCircle,
  Edit2,
  CheckCircle2,
  X,
  CreditCard,
  PlusCircle,
} from 'lucide-react';
import { Client, ClientType, Quote, Order, Store } from '../types';
import { formatKz, formatDate } from '../utils/formatters';

interface ClientsViewProps {
  clients: Client[];
  quotes: Quote[];
  orders: Order[];
  stores: Store[];
  activeStoreId: string;
  onAddClient: (client: Omit<Client, 'id' | 'createdAt'>) => void;
  onUpdateClient: (client: Client) => void;
  onCreateQuoteForClient: (client: Client) => void;
  onCreateOrderForClient: (client: Client) => void;
}

export const ClientsView: React.FC<ClientsViewProps> = ({
  clients,
  quotes,
  orders,
  stores,
  activeStoreId,
  onAddClient,
  onUpdateClient,
  onCreateQuoteForClient,
  onCreateOrderForClient,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);

  // Formulário State
  const [formData, setFormData] = useState({
    name: '',
    commercialName: '',
    phone: '',
    email: '',
    address: '',
    nif: '',
    type: 'particular' as ClientType,
    storeId: activeStoreId === 'all' ? 'store-001' : activeStoreId,
    notes: '',
    active: true,
  });

  const filteredClients = clients.filter(client => {
    const matchesSearch =
      client.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (client.commercialName && client.commercialName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      client.phone.includes(searchTerm) ||
      (client.nif && client.nif.toLowerCase().includes(searchTerm.toLowerCase())) ||
      client.email.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = selectedType === 'all' || client.type === selectedType;
    return matchesSearch && matchesType;
  });

  const handleOpenAdd = () => {
    setEditingClient(null);
    setFormData({
      name: '',
      commercialName: '',
      phone: '',
      email: '',
      address: '',
      nif: '',
      type: 'empresa',
      storeId: activeStoreId === 'all' ? 'store-001' : activeStoreId,
      notes: '',
      active: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (client: Client) => {
    setEditingClient(client);
    setFormData({
      name: client.name,
      commercialName: client.commercialName || '',
      phone: client.phone,
      email: client.email,
      address: client.address,
      nif: client.nif || '',
      type: client.type,
      storeId: client.storeId,
      notes: client.notes || '',
      active: client.active,
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) {
      alert('Por favor preencha pelo menos o Nome e o Telefone do cliente.');
      return;
    }

    if (editingClient) {
      onUpdateClient({
        ...editingClient,
        ...formData,
      });
      if (selectedClient && selectedClient.id === editingClient.id) {
        setSelectedClient({ ...editingClient, ...formData });
      }
    } else {
      onAddClient(formData);
    }
    setIsModalOpen(false);
  };

  // Histórico do cliente seleccionado
  const clientQuotes = selectedClient ? quotes.filter(q => q.clientId === selectedClient.id) : [];
  const clientOrders = selectedClient ? orders.filter(o => o.clientId === selectedClient.id) : [];
  const clientTotalSpent = clientOrders.reduce((sum, o) => sum + o.paidAmount, 0);
  const clientBalanceDue = clientOrders.reduce((sum, o) => sum + o.balanceDue, 0);

  return (
    <div className="space-y-6">
      {/* Cabeçalho da Vista */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Users className="w-6 h-6 text-[#13B8DB]" />
            <span>Gestão de Clientes</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Registo de clientes particulares, empresas e instituições, fichas individuais e histórico financeiro.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Registar Novo Cliente</span>
        </button>
      </div>

      {/* Barra de Filtros e Pesquisa */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pesquisar por nome, empresa, NIF ou telefone..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#13B8DB] text-slate-900"
          />
        </div>

        {/* Filtro por Tipo */}
        <div className="flex items-center gap-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          {[
            { id: 'all', label: 'Todos os Clientes' },
            { id: 'empresa', label: 'Empresas' },
            { id: 'particular', label: 'Particulares' },
            { id: 'instituicao', label: 'Instituições' },
          ].map(type => (
            <button
              key={type.id}
              onClick={() => setSelectedType(type.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                selectedType === type.id
                  ? 'bg-[#062E3B] text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {type.label}
            </button>
          ))}
        </div>
      </div>

      {/* Layout com Tabela e Ficha Individual */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Lista de Clientes */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[620px] text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Cliente / Designação</th>
                  <th className="px-3 py-3">Tipo</th>
                  <th className="px-3 py-3">Contactos</th>
                  <th className="px-3 py-3">NIF</th>
                  <th className="px-3 py-3 text-center">Estado</th>
                  <th className="px-4 py-3 text-right">Acções</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredClients.map(client => {
                  const isSelected = selectedClient?.id === client.id;

                  return (
                    <tr
                      key={client.id}
                      onClick={() => setSelectedClient(client)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-sky-50 font-medium' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-slate-900">{client.name}</div>
                        {client.commercialName && (
                          <div className="text-[11px] text-[#13B8DB] font-semibold">{client.commercialName}</div>
                        )}
                        <div className="text-[10px] text-slate-400 mt-0.5 truncate max-w-[200px]">{client.address}</div>
                      </td>

                      <td className="px-3 py-3.5">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded capitalize ${
                          client.type === 'empresa'
                            ? 'bg-blue-100 text-blue-800'
                            : client.type === 'instituicao'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}>
                          {client.type}
                        </span>
                      </td>

                      <td className="px-3 py-3.5 text-slate-600">
                        <div className="flex items-center gap-1 font-mono">{client.phone}</div>
                        <div className="text-[10px] text-slate-400 truncate max-w-[150px]">{client.email}</div>
                      </td>

                      <td className="px-3 py-3.5 font-mono text-slate-600">
                        {client.nif || '-'}
                      </td>

                      <td className="px-3 py-3.5 text-center">
                        <span className={`w-2 h-2 inline-block rounded-full ${client.active ? 'bg-emerald-500' : 'bg-slate-300'}`} />
                      </td>

                      <td className="px-4 py-3.5 text-right whitespace-nowrap">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenEdit(client);
                          }}
                          className="p-1.5 text-slate-500 hover:text-[#062E3B] hover:bg-slate-100 rounded"
                          title="Editar Cliente"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}

                {filteredClients.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-400">
                      Nenhum cliente encontrado com os filtros aplicados.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Ficha Individual do Cliente (Secção 5) */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 flex flex-col justify-between">
          {selectedClient ? (
            <div className="space-y-5">
              <div className="flex items-start justify-between pb-3 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-slate-900">{selectedClient.name}</h3>
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 capitalize">
                      {selectedClient.type}
                    </span>
                  </div>
                  {selectedClient.commercialName && (
                    <div className="text-xs font-semibold text-[#13B8DB] mt-0.5">
                      {selectedClient.commercialName}
                    </div>
                  )}
                  <div className="text-[10px] text-slate-400 mt-1">
                    Cliente desde {formatDate(selectedClient.createdAt)}
                  </div>
                </div>

                <button
                  onClick={() => handleOpenEdit(selectedClient)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded"
                  title="Editar"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              </div>

              {/* Informações de Contacto */}
              <div className="space-y-2 text-xs">
                <div className="flex items-center gap-2 text-slate-700">
                  <Phone className="w-3.5 h-3.5 text-[#13B8DB]" />
                  <span className="font-mono">{selectedClient.phone}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <Mail className="w-3.5 h-3.5 text-[#13B8DB]" />
                  <span>{selectedClient.email || 'Não informado'}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <MapPin className="w-3.5 h-3.5 text-[#13B8DB]" />
                  <span>{selectedClient.address || 'Não informado'}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-700">
                  <CreditCard className="w-3.5 h-3.5 text-[#13B8DB]" />
                  <span className="font-mono">NIF: {selectedClient.nif || 'Consumidor Final'}</span>
                </div>
              </div>

              {selectedClient.notes && (
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-xs text-slate-600">
                  <div className="font-bold text-[10px] uppercase tracking-wider text-slate-500 mb-0.5">
                    Observações de Atendimento
                  </div>
                  <p>{selectedClient.notes}</p>
                </div>
              )}

              {/* Resumo Financeiro do Cliente */}
              <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-100">
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Total Pago</span>
                  <div className="text-sm font-black text-slate-900 tabular-nums">
                    {formatKz(clientTotalSpent)}
                  </div>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-slate-500 uppercase">Saldo em Aberto</span>
                  <div className={`text-sm font-black tabular-nums ${clientBalanceDue > 0 ? 'text-[#E41179]' : 'text-emerald-700'}`}>
                    {formatKz(clientBalanceDue)}
                  </div>
                </div>
              </div>

              {/* Histórico Recente de Operações */}
              <div>
                <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Trabalhos & Encomendas ({clientOrders.length})</span>
                </h4>
                <div className="max-h-40 overflow-y-auto divide-y divide-slate-100 border border-slate-100 rounded-lg text-xs">
                  {clientOrders.map(order => (
                    <div key={order.id} className="p-2 flex items-center justify-between hover:bg-slate-50">
                      <div>
                        <div className="font-bold text-slate-900">{order.number}</div>
                        <div className="text-[10px] text-slate-500">{formatDate(order.createdAt)}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold text-slate-900 tabular-nums">{formatKz(order.total)}</div>
                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                          order.status === 'entregue' ? 'bg-green-100 text-green-800' : 'bg-sky-100 text-sky-800'
                        }`}>
                          {order.status}
                        </span>
                      </div>
                    </div>
                  ))}
                  {clientOrders.length === 0 && (
                    <div className="p-3 text-center text-slate-400 text-[11px]">
                      Sem encomendas registadas para este cliente.
                    </div>
                  )}
                </div>
              </div>

              {/* Ações Rápidas para o Cliente */}
              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => onCreateQuoteForClient(selectedClient)}
                  className="w-full flex items-center justify-center gap-2 py-2 bg-[#13B8DB] hover:bg-[#0ea5c4] text-[#062E3B] font-bold text-xs rounded-lg transition-colors"
                >
                  <FileText className="w-4 h-4" />
                  <span>Gerar Orçamento para este Cliente</span>
                </button>

                <button
                  onClick={() => onCreateOrderForClient(selectedClient)}
                  className="w-full flex items-center justify-center gap-2 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg transition-colors"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Criar Encomenda Directa</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center text-slate-400">
              <Users className="w-12 h-12 text-slate-300 mb-3" />
              <div className="font-bold text-sm text-slate-700">Selecione um cliente</div>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                Clique numa linha da tabela para consultar a ficha completa, dados fiscais, dívidas e histórico.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Modal de Criar / Editar Cliente */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-black text-sm uppercase tracking-wider text-white">
                  {editingClient ? 'Editar Ficha do Cliente' : 'Novo Registo de Cliente'}
                </h3>
                <p className="text-[11px] text-[#13B8DB] mt-0.5">
                  Preencha os dados cadastrais da entidade comercial ou particular.
                </p>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nome Completo ou Razão Social *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    placeholder="ex: Sonangol Distribuição ou João Silva"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Designação Comercial (opcional)
                  </label>
                  <input
                    type="text"
                    value={formData.commercialName}
                    onChange={e => setFormData({ ...formData, commercialName: e.target.value })}
                    placeholder="ex: Sonangol EP"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tipo de Cliente
                  </label>
                  <select
                    value={formData.type}
                    onChange={e => setFormData({ ...formData, type: e.target.value as ClientType })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none bg-white"
                  >
                    <option value="particular">Particular</option>
                    <option value="empresa">Empresa</option>
                    <option value="instituicao">Instituição / ONG</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Telefone de Contacto *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="+244 923 000 000"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    NIF (Número de Identificação Fiscal)
                  </label>
                  <input
                    type="text"
                    value={formData.nif}
                    onChange={e => setFormData({ ...formData, nif: e.target.value })}
                    placeholder="ex: 5418001234"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    placeholder="cliente@empresa.ao"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Endereço / Localização
                  </label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={e => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Rua, Bairro, Município, Luanda"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Observações Comerciais ou Requisitos Especiais
                  </label>
                  <textarea
                    rows={2}
                    value={formData.notes}
                    onChange={e => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="ex: Preferência por papel mate, entrega com recibo em papel timbrado..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
                >
                  {editingClient ? 'Guardar Alterações' : 'Concluir Registo'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
