import React, { useState, useRef, useEffect } from 'react';
import {
  LayoutDashboard,
  Users,
  Layers,
  FileText,
  ShoppingBag,
  Kanban,
  Wallet,
  Package,
  Truck,
  ShieldCheck,
  BarChart3,
  Settings,
  Bell,
  ChevronDown,
  Building2,
  LogOut,
  UserCheck,
  AlertTriangle,
  Clock,
  Sparkles,
  Menu,
  X,
  ChevronRight,
} from 'lucide-react';
import { Logo } from './Logo';
import { Store, User, UserRole, Order, StockItem, Quote } from '../types';
import { formatKz } from '../utils/formatters';

export type ActiveTab =
  | 'dashboard'
  | 'clientes'
  | 'servicos'
  | 'orcamentos'
  | 'encomendas'
  | 'producao'
  | 'caixa'
  | 'stock'
  | 'fornecedores'
  | 'funcionarios'
  | 'relatorios'
  | 'configuracoes';

interface TopNavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  stores: Store[];
  activeStoreId: string;
  onStoreChange: (storeId: string) => void;
  currentUser: User;
  allUsers: User[];
  onSwitchUser: (user: User) => void;
  customLogoUrl?: string;
  delayedOrdersCount: number;
  lowStockCount: number;
  pendingQuotesCount: number;
  delayedOrders: Order[];
  lowStockItems: StockItem[];
  pendingQuotes: Quote[];
  onOpenOrderModal?: (orderId: string) => void;
}

export const TopNavbar: React.FC<TopNavbarProps> = ({
  activeTab,
  onTabChange,
  stores,
  activeStoreId,
  onStoreChange,
  currentUser,
  allUsers,
  onSwitchUser,
  customLogoUrl,
  delayedOrdersCount,
  lowStockCount,
  pendingQuotesCount,
  delayedOrders,
  lowStockItems,
  pendingQuotes,
}) => {
  const [storeDropdownOpen, setStoreDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const storeMenuRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notifMenuRef = useRef<HTMLDivElement>(null);

  const totalNotifications = delayedOrdersCount + lowStockCount + pendingQuotesCount;

  // Fechar dropdowns ao clicar fora
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (storeMenuRef.current && !storeMenuRef.current.contains(event.target as Node)) {
        setStoreDropdownOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setUserDropdownOpen(false);
      }
      if (notifMenuRef.current && !notifMenuRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Prevenir scroll do body quando o drawer mobile está aberto
  useEffect(() => {
    if (mobileDrawerOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [mobileDrawerOpen]);

  const currentStore = stores.find(s => s.id === activeStoreId) || stores[0];

  const navItems: { id: ActiveTab; label: string; icon: React.ElementType; restrictedRoles?: UserRole[] }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'clientes', label: 'Clientes', icon: Users },
    { id: 'servicos', label: 'Serviços', icon: Layers },
    { id: 'orcamentos', label: 'Orçamentos', icon: FileText, restrictedRoles: ['operador'] },
    { id: 'encomendas', label: 'Encomendas', icon: ShoppingBag },
    { id: 'producao', label: 'Produção', icon: Kanban },
    { id: 'caixa', label: 'Caixa', icon: Wallet, restrictedRoles: ['operador', 'designer'] },
    { id: 'stock', label: 'Stock', icon: Package },
    { id: 'fornecedores', label: 'Fornecedores', icon: Truck, restrictedRoles: ['operador', 'designer'] },
    { id: 'funcionarios', label: 'Funcionários', icon: ShieldCheck, restrictedRoles: ['atendente', 'operador', 'designer'] },
    { id: 'relatorios', label: 'Relatórios', icon: BarChart3, restrictedRoles: ['operador', 'designer'] },
  ];

  const roleLabels: Record<UserRole, string> = {
    admin: 'Administrador Geral',
    director: 'Directora de Operações',
    gerente: 'Gerente de Loja',
    atendente: 'Atendente Comercial',
    designer: 'Designer Gráfico',
    operador: 'Operador de Produção',
    financeiro: 'Responsável Financeiro',
    consulta: 'Apenas Consulta',
  };

  const handleSelectTab = (tab: ActiveTab) => {
    onTabChange(tab);
    setMobileDrawerOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#062E3B] text-white border-b border-[#0b4556] shadow-lg select-none">
        {/* Barra Superior Principal */}
        <div className="max-w-[1720px] mx-auto px-3 sm:px-6 flex items-center justify-between h-16 gap-2 sm:gap-3">
          {/* Lado Esquerdo: Botão Menu Mobile + Logótipo Original */}
          <div className="flex items-center gap-1.5 sm:gap-3">
            {/* Botão Hambúrguer para Telas Pequenas */}
            <button
              onClick={() => setMobileDrawerOpen(true)}
              className="lg:hidden p-2 rounded-lg bg-[#041d26] hover:bg-[#0b4556] border border-[#13B8DB]/30 text-white min-w-[40px] min-h-[40px] flex items-center justify-center transition-colors"
              aria-label="Abrir menu de navegação"
            >
              <Menu className="w-5 h-5 text-[#F7CB18]" />
            </button>

            {/* Logótipo Original clicável para voltar ao Dashboard */}
            <button
              onClick={() => handleSelectTab('dashboard')}
              className="flex items-center gap-2 sm:gap-3 p-1 rounded-lg hover:bg-[#0b4556]/60 transition-colors focus:outline-none focus:ring-2 focus:ring-[#F7CB18]"
              title="Regressar ao Dashboard Operacional"
            >
              <Logo customLogoUrl={customLogoUrl} />
            </button>
          </div>

          {/* Lado Direito: Seletor de Loja, Notificações, Configurações e Perfil */}
          <div className="flex items-center gap-1.5 sm:gap-3">
            {/* Seletor de Loja Física (Multi-loja) */}
            <div className="relative" ref={storeMenuRef}>
              <button
                onClick={() => setStoreDropdownOpen(!storeDropdownOpen)}
                className="flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 rounded-md bg-[#041d26] hover:bg-[#0b4556] border border-[#13B8DB]/30 text-xs font-semibold tracking-wide transition-colors min-h-[38px]"
              >
                <Building2 className="w-3.5 h-3.5 text-[#13B8DB] shrink-0" />
                <div className="text-left hidden md:block">
                  <span className="block text-[10px] text-slate-400 uppercase leading-none">Unidade</span>
                  <span className="text-white font-bold leading-tight truncate max-w-[130px]">
                    {activeStoreId === 'all' ? 'Todas as Lojas' : currentStore?.code}
                  </span>
                </div>
                <span className="md:hidden font-bold text-[11px]">{currentStore?.code?.replace('LOJA ', 'L.') || 'L.001'}</span>
                <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
              </button>

              {storeDropdownOpen && (
                <div className="absolute right-0 mt-2 w-[calc(100vw-2rem)] sm:w-72 max-w-xs bg-[#041d26] border border-[#0b4556] rounded-lg shadow-2xl py-2 z-50 text-xs">
                  <div className="px-3 py-1.5 border-b border-[#0b4556] text-[11px] font-semibold text-[#13B8DB] uppercase tracking-wider">
                    Rede de Lojas & Filiais
                  </div>
                  {currentUser.role === 'admin' || currentUser.role === 'director' ? (
                    <button
                      onClick={() => {
                        onStoreChange('all');
                        setStoreDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-[#062E3B] ${
                        activeStoreId === 'all' ? 'bg-[#062E3B] text-[#F7CB18] font-bold' : 'text-slate-200'
                      }`}
                    >
                      <span>Todas as Lojas (Consolidado)</span>
                      {activeStoreId === 'all' && <span className="w-1.5 h-1.5 rounded-full bg-[#F7CB18]" />}
                    </button>
                  ) : null}

                  {stores.map(store => (
                    <button
                      key={store.id}
                      onClick={() => {
                        onStoreChange(store.id);
                        setStoreDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2.5 flex items-center justify-between hover:bg-[#062E3B] border-t border-[#0b4556]/40 ${
                        activeStoreId === store.id ? 'bg-[#062E3B] text-[#F7CB18] font-bold' : 'text-slate-200'
                      }`}
                    >
                      <div className="min-w-0 pr-2">
                        <div className="font-medium text-white truncate">{store.code} — {store.name}</div>
                        <div className="text-[10px] text-slate-400 truncate">{store.address}</div>
                      </div>
                      {activeStoreId === store.id && (
                        <span className="w-2 h-2 rounded-full bg-[#F7CB18] shrink-0" />
                      )}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Central de Notificações Operacionais */}
            <div className="relative" ref={notifMenuRef}>
              <button
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="relative p-2 rounded-md bg-[#041d26] hover:bg-[#0b4556] border border-[#13B8DB]/20 text-slate-300 hover:text-white transition-colors min-w-[38px] min-h-[38px] flex items-center justify-center"
                title="Notificações e Alertas"
              >
                <Bell className="w-4 h-4" />
                {totalNotifications > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#E41179] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border-2 border-[#062E3B]">
                    {totalNotifications}
                  </span>
                )}
              </button>

              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-[calc(100vw-2rem)] sm:w-84 max-w-sm bg-[#041d26] border border-[#0b4556] rounded-lg shadow-2xl py-2 z-50 text-xs">
                  <div className="px-4 py-2 border-b border-[#0b4556] flex items-center justify-between">
                    <span className="font-bold text-white text-xs uppercase tracking-wider">Alertas Operacionais</span>
                    <span className="text-[11px] text-[#13B8DB] font-semibold">{totalNotifications} pendências</span>
                  </div>

                  <div className="max-h-80 overflow-y-auto divide-y divide-[#0b4556]/50">
                    {delayedOrdersCount > 0 && (
                      <div className="p-3 bg-red-950/20 hover:bg-red-950/30">
                        <div className="flex items-center gap-2 text-rose-400 font-bold mb-1">
                          <AlertTriangle className="w-4 h-4 shrink-0" />
                          <span>{delayedOrdersCount} Encomenda(s) Atrasada(s)</span>
                        </div>
                        <p className="text-[11px] text-slate-300">
                          Existem trabalhos cujo prazo de entrega já foi ultrapassado.
                        </p>
                        <button
                          onClick={() => {
                            handleSelectTab('producao');
                            setNotificationsOpen(false);
                          }}
                          className="mt-2 text-[11px] text-[#F7CB18] font-bold hover:underline"
                        >
                          Ver na Produção →
                        </button>
                      </div>
                    )}

                    {lowStockCount > 0 && (
                      <div className="p-3 bg-amber-950/20 hover:bg-amber-950/30">
                        <div className="flex items-center gap-2 text-amber-300 font-bold mb-1">
                          <Package className="w-4 h-4 shrink-0" />
                          <span>{lowStockCount} Material(ais) em Limite Crítico</span>
                        </div>
                        <p className="text-[11px] text-slate-300">
                          {lowStockItems.slice(0, 2).map(i => i.name).join(', ')} abaixo do limite.
                        </p>
                        <button
                          onClick={() => {
                            handleSelectTab('stock');
                            setNotificationsOpen(false);
                          }}
                          className="mt-2 text-[11px] text-[#F7CB18] font-bold hover:underline"
                        >
                          Repor Stock →
                        </button>
                      </div>
                    )}

                    {pendingQuotesCount > 0 && (
                      <div className="p-3 hover:bg-[#062E3B]/60">
                        <div className="flex items-center gap-2 text-[#13B8DB] font-bold mb-1">
                          <Clock className="w-4 h-4 shrink-0" />
                          <span>{pendingQuotesCount} Orçamento(s) Pendente(s)</span>
                        </div>
                        <p className="text-[11px] text-slate-300">
                          Aguardando confirmação de clientes para avançar com a produção.
                        </p>
                        <button
                          onClick={() => {
                            handleSelectTab('orcamentos');
                            setNotificationsOpen(false);
                          }}
                          className="mt-2 text-[11px] text-[#F7CB18] font-bold hover:underline"
                        >
                          Consultar Orçamentos →
                        </button>
                      </div>
                    )}

                    {totalNotifications === 0 && (
                      <div className="p-6 text-center text-slate-400">
                        <Sparkles className="w-6 h-6 mx-auto mb-2 text-[#1E7620]" />
                        <span>Todas as operações estão em dia!</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Atalho Configurações / Administração */}
            <button
              onClick={() => handleSelectTab('configuracoes')}
              className={`p-2 rounded-md border text-xs transition-colors min-w-[38px] min-h-[38px] flex items-center justify-center ${
                activeTab === 'configuracoes'
                  ? 'bg-[#F7CB18] text-[#062E3B] border-[#F7CB18] font-bold'
                  : 'bg-[#041d26] hover:bg-[#0b4556] border-[#13B8DB]/20 text-slate-300 hover:text-white'
              }`}
              title="Administração e Configurações da Empresa"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Perfil do Utilizador Autenticado & Alternador de Perfil */}
            <div className="relative" ref={userMenuRef}>
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 px-2 sm:px-3 py-1.5 rounded-md bg-[#041d26] hover:bg-[#0b4556] border border-[#13B8DB]/30 transition-colors min-h-[38px]"
              >
                <div className="w-7 h-7 rounded-full bg-[#13B8DB]/20 border border-[#13B8DB] text-[#F7CB18] font-black text-xs flex items-center justify-center shrink-0">
                  {currentUser.name.charAt(0)}
                </div>
                <div className="text-left hidden lg:block">
                  <div className="text-xs font-bold text-white leading-tight truncate max-w-[120px]">
                    {currentUser.name}
                  </div>
                  <div className="text-[10px] text-[#13B8DB] font-semibold leading-none">
                    {roleLabels[currentUser.role]}
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0 hidden sm:block" />
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-[calc(100vw-2rem)] sm:w-80 max-w-sm bg-[#041d26] border border-[#0b4556] rounded-lg shadow-2xl py-2 z-50 text-xs">
                  <div className="px-4 py-3 border-b border-[#0b4556]">
                    <div className="text-sm font-bold text-white">{currentUser.name}</div>
                    <div className="text-slate-400 text-[11px] truncate">{currentUser.email}</div>
                    <div className="mt-1.5 inline-flex items-center px-2 py-0.5 rounded bg-[#13B8DB]/20 text-[#13B8DB] font-bold text-[10px]">
                      Perfil: {roleLabels[currentUser.role]}
                    </div>
                  </div>

                  <div className="px-3 py-2 border-b border-[#0b4556] text-[11px] font-semibold text-[#F7CB18] uppercase tracking-wider flex items-center justify-between">
                    <span>Alternar Perfil para Teste</span>
                    <UserCheck className="w-3.5 h-3.5" />
                  </div>

                  <div className="max-h-56 overflow-y-auto">
                    {allUsers.map(user => (
                      <button
                        key={user.id}
                        onClick={() => {
                          onSwitchUser(user);
                          setUserDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-[#062E3B] transition-colors ${
                          user.id === currentUser.id ? 'bg-[#062E3B] text-[#F7CB18] font-bold' : 'text-slate-200'
                        }`}
                      >
                        <div>
                          <div className="font-medium text-white">{user.name}</div>
                          <div className="text-[10px] text-slate-400">{roleLabels[user.role]}</div>
                        </div>
                        {user.id === currentUser.id && (
                          <span className="text-[10px] text-[#1E7620] font-bold bg-green-950/60 px-1.5 py-0.5 rounded">
                            Activo
                          </span>
                        )}
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-[#0b4556] px-2">
                    <button
                      onClick={() => {
                        handleSelectTab('configuracoes');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded text-slate-300 hover:text-white hover:bg-[#062E3B] flex items-center gap-2"
                    >
                      <Settings className="w-3.5 h-3.5 text-[#13B8DB]" />
                      <span>Configurações da Conta</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Menu Horizontal Superior Dinâmico com suporte a Swipe / Scroll suave */}
        <div className="bg-[#041D26] border-t border-[#0b4556]/60">
          <div className="max-w-[1720px] mx-auto px-2 sm:px-4">
            <nav className="flex items-center gap-1 overflow-x-auto py-1.5 scrollbar-none" aria-label="Navegação dos Módulos">
              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                const isRestricted = item.restrictedRoles && item.restrictedRoles.includes(currentUser.role);

                if (isRestricted) {
                  return null;
                }

                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`group relative flex items-center gap-2 px-3 py-1.5 sm:px-3.5 sm:py-2 text-xs font-semibold rounded-md transition-all whitespace-nowrap shrink-0 min-h-[36px] ${
                      isActive
                        ? 'bg-[#F7CB18] text-[#062E3B] font-bold shadow-md'
                        : 'text-slate-300 hover:text-white hover:bg-[#062E3B]'
                    }`}
                  >
                    <Icon
                      className={`w-3.5 h-3.5 shrink-0 transition-colors ${
                        isActive ? 'text-[#062E3B]' : 'text-[#13B8DB] group-hover:text-[#F7CB18]'
                      }`}
                    />
                    <span>{item.label}</span>

                    {item.id === 'producao' && delayedOrdersCount > 0 && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                        isActive ? 'bg-[#E41179] text-white' : 'bg-red-500 text-white'
                      }`}>
                        {delayedOrdersCount}
                      </span>
                    )}

                    {item.id === 'orcamentos' && pendingQuotesCount > 0 && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                        isActive ? 'bg-[#062E3B] text-white' : 'bg-[#13B8DB] text-slate-900'
                      }`}>
                        {pendingQuotesCount}
                      </span>
                    )}

                    {item.id === 'stock' && lowStockCount > 0 && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                        isActive ? 'bg-[#E41179] text-white' : 'bg-amber-500 text-slate-900'
                      }`}>
                        !
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      </header>

      {/* Drawer Móvel Deslizante (Menu Completo para Dispositivos Móveis e Tablets) */}
      {mobileDrawerOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          {/* Backdrop Escurecido com Fecho ao Clicar */}
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity"
            onClick={() => setMobileDrawerOpen(false)}
          />

          {/* Painel do Menu Lateral */}
          <div className="relative w-full max-w-xs bg-[#041D26] text-white h-full shadow-2xl flex flex-col z-10 border-r border-[#0b4556]">
            {/* Cabeçalho do Drawer */}
            <div className="p-4 bg-[#062E3B] border-b border-[#0b4556] flex items-center justify-between">
              <Logo customLogoUrl={customLogoUrl} />
              <button
                onClick={() => setMobileDrawerOpen(false)}
                className="p-2 text-slate-300 hover:text-white rounded-lg hover:bg-[#0b4556] transition-colors"
                aria-label="Fechar menu"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Identificação de Loja e Utilizador Activo */}
            <div className="p-3.5 bg-[#03171e] border-b border-[#0b4556]/60 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-400">Loja Activa:</span>
                <span className="font-bold text-[#F7CB18]">{currentStore?.name}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase font-bold text-slate-400">Utilizador:</span>
                <span className="font-semibold text-white truncate max-w-[160px]">{currentUser.name}</span>
              </div>
              <div className="text-[10px] text-[#13B8DB] font-semibold">
                Perfil: {roleLabels[currentUser.role]}
              </div>
            </div>

            {/* Lista dos 11 Módulos com Toque Generoso (min 44px) */}
            <div className="flex-1 overflow-y-auto p-3 space-y-1">
              <div className="text-[10px] uppercase font-bold text-slate-400 px-3 py-1 tracking-wider">
                Módulos do Sistema
              </div>

              {navItems.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                const isRestricted = item.restrictedRoles && item.restrictedRoles.includes(currentUser.role);

                if (isRestricted) return null;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm font-semibold transition-colors min-h-[44px] ${
                      isActive
                        ? 'bg-[#F7CB18] text-[#062E3B] font-bold shadow-sm'
                        : 'text-slate-200 hover:bg-[#062E3B] hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon className={`w-5 h-5 ${isActive ? 'text-[#062E3B]' : 'text-[#13B8DB]'}`} />
                      <span>{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {item.id === 'producao' && delayedOrdersCount > 0 && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#E41179] text-white">
                          {delayedOrdersCount}
                        </span>
                      )}
                      {item.id === 'orcamentos' && pendingQuotesCount > 0 && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#13B8DB] text-[#062E3B]">
                          {pendingQuotesCount}
                        </span>
                      )}
                      {item.id === 'stock' && lowStockCount > 0 && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-amber-500 text-[#062E3B]">
                          !
                        </span>
                      )}
                      <ChevronRight className={`w-4 h-4 ${isActive ? 'text-[#062E3B]' : 'text-slate-500'}`} />
                    </div>
                  </button>
                );
              })}

              <div className="pt-2">
                <button
                  onClick={() => handleSelectTab('configuracoes')}
                  className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg text-sm font-semibold transition-colors min-h-[44px] ${
                    activeTab === 'configuracoes'
                      ? 'bg-[#F7CB18] text-[#062E3B] font-bold shadow-sm'
                      : 'text-slate-200 hover:bg-[#062E3B]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Settings className={`w-5 h-5 ${activeTab === 'configuracoes' ? 'text-[#062E3B]' : 'text-[#13B8DB]'}`} />
                    <span>Configurações & Backups</span>
                  </div>
                  <ChevronRight className={`w-4 h-4 ${activeTab === 'configuracoes' ? 'text-[#062E3B]' : 'text-slate-500'}`} />
                </button>
              </div>
            </div>

            {/* Rodapé do Menu Mobile */}
            <div className="p-3 bg-[#03171e] border-t border-[#0b4556] text-[11px] text-slate-400 text-center">
              Gráfica Arte Final — Portal Operacional
            </div>
          </div>
        </div>
      )}
    </>
  );
};
