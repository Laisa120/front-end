import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  Printer,
  ArrowRight,
  Trash2,
  PlusCircle,
  Building,
  User as UserIcon,
  ShoppingBag,
  DollarSign,
  AlertCircle,
  X,
  CreditCard,
} from 'lucide-react';
import { Quote, QuoteItem, Service, Client, Store, User, PaymentMethod } from '../types';
import { formatKz, formatDate } from '../utils/formatters';

interface QuotesViewProps {
  quotes: Quote[];
  clients: Client[];
  services: Service[];
  stores: Store[];
  activeStoreId: string;
  currentUser: User;
  onAddQuote: (quote: Omit<Quote, 'id' | 'number' | 'createdAt'>) => void;
  onUpdateQuote: (quote: Quote) => void;
  onConvertToOrder: (quoteId: string, initialDeposit: number, paymentMethod: PaymentMethod) => void;
  onPrintQuote: (quote: Quote) => void;
  preselectedClient?: Client | null;
}

export const QuotesView: React.FC<QuotesViewProps> = ({
  quotes,
  clients,
  services,
  stores,
  activeStoreId,
  currentUser,
  onAddQuote,
  onUpdateQuote,
  onConvertToOrder,
  onPrintQuote,
  preselectedClient,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [convertModalQuote, setConvertModalQuote] = useState<Quote | null>(null);
  const [convertDeposit, setConvertDeposit] = useState<number>(0);
  const [convertPaymentMethod, setConvertPaymentMethod] = useState<PaymentMethod>('multicaixa');

  // Form State para Novo Orçamento
  const [clientId, setClientId] = useState<string>(preselectedClient?.id || clients[0]?.id || '');
  const [items, setItems] = useState<QuoteItem[]>([]);
  const [selectedServiceId, setSelectedServiceId] = useState<string>(services[0]?.id || '');
  const [itemQty, setItemQty] = useState<number>(1);
  const [itemCustomWidth, setItemCustomWidth] = useState<number>(1);
  const [itemCustomHeight, setItemCustomHeight] = useState<number>(1);
  const [itemCustomMaterial, setItemCustomMaterial] = useState<string>('');
  const [itemCustomFinishing, setItemCustomFinishing] = useState<string>('');
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [validityDays, setValidityDays] = useState<number>(15);
  const [notes, setNotes] = useState<string>('');

  const filteredQuotes = quotes.filter(quote => {
    const matchesSearch =
      quote.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      quote.clientName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || quote.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleOpenAdd = () => {
    setClientId(clients[0]?.id || '');
    setItems([]);
    setDiscountPercent(0);
    setValidityDays(15);
    setNotes('');
    setIsModalOpen(true);
  };

  const handleAddItem = () => {
    const service = services.find(s => s.id === selectedServiceId);
    if (!service) return;

    let unitPrice = service.price;
    let subtotal = 0;

    if (service.unit === 'm2') {
      const area = Math.max(0.01, itemCustomWidth * itemCustomHeight);
      unitPrice = service.price * area;
      subtotal = unitPrice * itemQty;
    } else {
      subtotal = unitPrice * itemQty;
    }

    const newItem: QuoteItem = {
      id: `item-${Date.now()}`,
      serviceId: service.id,
      serviceName: service.name,
      description: service.description,
      quantity: itemQty,
      unitPrice,
      customSpecs:
        service.unit === 'm2' || itemCustomMaterial || itemCustomFinishing
          ? {
              width: itemCustomWidth,
              height: itemCustomHeight,
              material: itemCustomMaterial || undefined,
              finishing: itemCustomFinishing || undefined,
            }
          : undefined,
      subtotal,
    };

    setItems([...items, newItem]);
    setItemQty(1);
    setItemCustomMaterial('');
    setItemCustomFinishing('');
  };

  const handleRemoveItem = (itemId: string) => {
    setItems(items.filter(i => i.id !== itemId));
  };

  // Cálculos financeiros do formulário
  const formSubtotal = items.reduce((sum, item) => sum + item.subtotal, 0);
  const formDiscountAmount = (formSubtotal * discountPercent) / 100;
  const formTotal = Math.max(0, formSubtotal - formDiscountAmount);
  const formDepositRequired = formTotal * 0.5; // 50%
  const formRemaining = formTotal - formDepositRequired;

  const handleSubmitQuote = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) {
      alert('Por favor adicione pelo menos um serviço ao orçamento.');
      return;
    }

    const client = clients.find(c => c.id === clientId);
    if (!client) {
      alert('Selecione um cliente válido.');
      return;
    }

    const expires = new Date();
    expires.setDate(expires.getDate() + validityDays);

    onAddQuote({
      clientId: client.id,
      clientName: client.name,
      clientPhone: client.phone,
      clientNif: client.nif,
      storeId: activeStoreId === 'all' ? 'store-001' : activeStoreId,
      items,
      subtotal: formSubtotal,
      discount: discountPercent,
      discountType: 'percentage',
      discountAmount: formDiscountAmount,
      total: formTotal,
      depositRequired: formDepositRequired,
      remainingBalance: formRemaining,
      validityDays,
      expiresAt: expires.toISOString(),
      status: 'pendente',
      notes,
      createdBy: currentUser.name,
    });

    setIsModalOpen(false);
  };

  const handleOpenConvert = (quote: Quote) => {
    setConvertModalQuote(quote);
    setConvertDeposit(quote.depositRequired);
    setConvertPaymentMethod('multicaixa');
  };

  const handleConfirmConvert = () => {
    if (!convertModalQuote) return;
    onConvertToOrder(convertModalQuote.id, convertDeposit, convertPaymentMethod);
    setConvertModalQuote(null);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-6 h-6 text-[#13B8DB]" />
            <span>Gestão de Orçamentos Comerciais</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Elaboração de propostas, personalização de preços, aprovações e conversão automática em encomendas.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Elaborar Novo Orçamento</span>
        </button>
      </div>

      {/* Barra de Filtros e Pesquisa */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pesquisar por número do orçamento ou cliente..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#13B8DB] text-slate-900"
          />
        </div>

        {/* Filtros de Estado */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          {[
            { id: 'all', label: 'Todos' },
            { id: 'pendente', label: 'Pendentes' },
            { id: 'aprovado', label: 'Aprovados' },
            { id: 'enviado', label: 'Enviados' },
            { id: 'rascunho', label: 'Rascunhos' },
          ].map(st => (
            <button
              key={st.id}
              onClick={() => setStatusFilter(st.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                statusFilter === st.id
                  ? 'bg-[#062E3B] text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tabela de Orçamentos */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[650px] text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Número / Emissão</th>
                <th className="px-3 py-3">Cliente</th>
                <th className="px-3 py-3">Serviços Orçados</th>
                <th className="px-3 py-3 text-right">Total Global</th>
                <th className="px-3 py-3 text-right">Sinal (50%)</th>
                <th className="px-3 py-3 text-center">Estado</th>
                <th className="px-4 py-3 text-right">Acções Operacionais</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredQuotes.map(quote => {
                const isApproved = quote.status === 'aprovado';
                const isConverted = !!quote.convertedToOrderId;

                return (
                  <tr key={quote.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="font-bold text-slate-900 text-xs">{quote.number}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        {formatDate(quote.createdAt)} · Validade {quote.validityDays}d
                      </div>
                    </td>

                    <td className="px-3 py-3.5">
                      <div className="font-bold text-slate-900">{quote.clientName}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{quote.clientPhone}</div>
                    </td>

                    <td className="px-3 py-3.5 text-slate-700">
                      <div className="font-medium truncate max-w-[220px]">
                        {quote.items.map(i => i.serviceName).join(', ')}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {quote.items.length} itens orçados
                      </div>
                    </td>

                    <td className="px-3 py-3.5 text-right font-black text-slate-900 tabular-nums">
                      {formatKz(quote.total)}
                      {quote.discountAmount > 0 && (
                        <div className="text-[10px] text-emerald-600 font-semibold">
                          Desc. -{formatKz(quote.discountAmount)}
                        </div>
                      )}
                    </td>

                    <td className="px-3 py-3.5 text-right font-semibold text-[#13B8DB] tabular-nums">
                      {formatKz(quote.depositRequired)}
                    </td>

                    <td className="px-3 py-3.5 text-center">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                        quote.status === 'aprovado'
                          ? 'bg-emerald-100 text-emerald-800'
                          : quote.status === 'pendente'
                          ? 'bg-amber-100 text-amber-800'
                          : quote.status === 'enviado'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {quote.status}
                      </span>
                    </td>

                    <td className="px-4 py-3.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Imprimir Orçamento */}
                        <button
                          onClick={() => onPrintQuote(quote)}
                          className="p-1.5 text-slate-600 hover:text-[#062E3B] hover:bg-slate-100 rounded"
                          title="Imprimir / Ver Proposta A4"
                        >
                          <Printer className="w-4 h-4" />
                        </button>

                        {/* Converter em Encomenda (CRITICAL REQUIREMENT 7) */}
                        {!isConverted ? (
                          <button
                            onClick={() => handleOpenConvert(quote)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-[#1E7620] hover:bg-green-700 text-white font-bold text-[11px] rounded transition-colors"
                            title="Aprovar e Converter em Encomenda"
                          >
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>Converter Encomenda</span>
                          </button>
                        ) : (
                          <span className="text-[10px] text-[#1E7620] font-bold bg-green-50 border border-green-200 px-2 py-1 rounded">
                            Encomenda Gerada
                          </span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredQuotes.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    Nenhum orçamento encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Criação de Novo Orçamento */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-4xl my-auto max-h-[94vh] flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-black text-sm uppercase tracking-wider text-white">
                  Elaborar Nova Proposta Comercial
                </h3>
                <p className="text-[11px] text-[#13B8DB] mt-0.5">
                  Adicione serviços, aplique regras de preços e descontos comerciais autorizados.
                </p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitQuote} className="p-4 sm:p-6 space-y-4 sm:space-y-5 overflow-y-auto">
              {/* Seleção do Cliente e Parâmetros */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Cliente Solicitante *
                  </label>
                  <select
                    value={clientId}
                    onChange={e => setClientId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  >
                    {clients.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name} {c.commercialName ? `(${c.commercialName})` : ''} — {c.phone}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Validade da Proposta
                  </label>
                  <select
                    value={validityDays}
                    onChange={e => setValidityDays(parseInt(e.target.value) || 15)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  >
                    <option value="7">7 Dias</option>
                    <option value="15">15 Dias (Recomendado)</option>
                    <option value="30">30 Dias</option>
                  </select>
                </div>
              </div>

              {/* Seção de Adicionar Itens / Serviços */}
              <div className="p-4 bg-sky-50/50 rounded-xl border border-sky-200 space-y-3">
                <div className="font-bold text-xs uppercase tracking-wider text-[#062E3B] flex items-center gap-1.5">
                  <PlusCircle className="w-4 h-4 text-[#13B8DB]" />
                  <span>Adicionar Serviço ao Orçamento</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Serviço Gráfico
                    </label>
                    <select
                      value={selectedServiceId}
                      onChange={e => setSelectedServiceId(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                    >
                      {services.filter(s => s.active).map(s => (
                        <option key={s.id} value={s.id}>
                          {s.name} — {formatKz(s.price)} / {s.unit}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                      Quantidade
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={itemQty}
                      onChange={e => setItemQty(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                    />
                  </div>

                  <div className="flex items-end">
                    <button
                      type="button"
                      onClick={handleAddItem}
                      className="w-full py-2 bg-[#13B8DB] hover:bg-[#0ea5c4] text-[#062E3B] font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Inserir Item</span>
                    </button>
                  </div>
                </div>

                {/* Campos opcionais de personalização (dimensões / acabamento) */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-sky-100">
                  <div className="flex gap-2">
                    <input
                      type="number"
                      step="0.05"
                      min="0.1"
                      placeholder="Largura (m)"
                      value={itemCustomWidth}
                      onChange={e => setItemCustomWidth(parseFloat(e.target.value) || 1)}
                      className="w-1/2 px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs"
                    />
                    <input
                      type="number"
                      step="0.05"
                      min="0.1"
                      placeholder="Altura (m)"
                      value={itemCustomHeight}
                      onChange={e => setItemCustomHeight(parseFloat(e.target.value) || 1)}
                      className="w-1/2 px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs"
                    />
                  </div>

                  <input
                    type="text"
                    placeholder="Material especificado (ex: Couché 350g, Vinil fosco...)"
                    value={itemCustomMaterial}
                    onChange={e => setItemCustomMaterial(e.target.value)}
                    className="px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs"
                  />

                  <input
                    type="text"
                    placeholder="Acabamentos (ex: Plastificação mate, ilhoses...)"
                    value={itemCustomFinishing}
                    onChange={e => setItemCustomFinishing(e.target.value)}
                    className="px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs"
                  />
                </div>
              </div>

              {/* Tabela de Itens Inseridos */}
              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2.5">Serviço</th>
                      <th className="px-3 py-2.5 text-center">Qtd</th>
                      <th className="px-4 py-2.5 text-right">Unitário</th>
                      <th className="px-4 py-2.5 text-right">Subtotal</th>
                      <th className="px-3 py-2.5 text-center">Remover</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {items.map(item => (
                      <tr key={item.id} className="hover:bg-slate-50">
                        <td className="px-4 py-2.5">
                          <div className="font-bold text-slate-900">{item.serviceName}</div>
                          {item.customSpecs && (
                            <div className="text-[10px] text-slate-500">
                              {item.customSpecs.width && `${item.customSpecs.width}m × ${item.customSpecs.height}m · `}
                              {item.customSpecs.material}
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-2.5 text-center font-mono">{item.quantity}</td>
                        <td className="px-4 py-2.5 text-right font-mono tabular-nums">{formatKz(item.unitPrice)}</td>
                        <td className="px-4 py-2.5 text-right font-mono font-bold text-slate-900 tabular-nums">
                          {formatKz(item.subtotal)}
                        </td>
                        <td className="px-3 py-2.5 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(item.id)}
                            className="p-1 text-slate-400 hover:text-red-600 rounded"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                    {items.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-6 text-center text-slate-400">
                          Nenhum item adicionado ainda. Escolha um serviço acima e clique em "Inserir Item".
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Totais, Desconto e Observações */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-start">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Observações e Requisitos Técnicos
                  </label>
                  <textarea
                    rows={3}
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="Instruções para o cliente, forma de entrega, prazos de aprovação de prova..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal:</span>
                    <span className="font-mono tabular-nums">{formatKz(formSubtotal)}</span>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-600">Desconto (%):</span>
                    <input
                      type="number"
                      min="0"
                      max="30"
                      value={discountPercent}
                      onChange={e => setDiscountPercent(parseFloat(e.target.value) || 0)}
                      className="w-20 px-2 py-1 bg-white border border-slate-300 rounded text-right font-mono text-xs"
                    />
                  </div>

                  <div className="flex justify-between text-sm font-black text-slate-900 pt-2 border-t border-slate-200">
                    <span>Total do Orçamento:</span>
                    <span className="tabular-nums text-[#062E3B]">{formatKz(formTotal)}</span>
                  </div>

                  <div className="flex justify-between text-[#13B8DB] font-bold">
                    <span>Sinal Exigido (50%):</span>
                    <span className="font-mono tabular-nums">{formatKz(formDepositRequired)}</span>
                  </div>

                  <div className="flex justify-between text-slate-500 font-semibold">
                    <span>Saldo na Entrega:</span>
                    <span className="font-mono tabular-nums">{formatKz(formRemaining)}</span>
                  </div>
                </div>
              </div>

              {/* Botões de Ação */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={items.length === 0}
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] disabled:opacity-50 text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
                >
                  Registar & Emitir Orçamento
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Conversão Automática de Orçamento em Encomenda */}
      {convertModalQuote && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">
                  Aprovar & Converter em Encomenda
                </h3>
                <p className="text-[11px] text-[#13B8DB]">
                  Orçamento: {convertModalQuote.number} ({convertModalQuote.clientName})
                </p>
              </div>
              <button onClick={() => setConvertModalQuote(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900">
                <div className="font-bold">Total do Trabalho: {formatKz(convertModalQuote.total)}</div>
                <div className="text-[11px] text-amber-800 mt-1">
                  Recomenda-se registar o adiantamento de 50% ({formatKz(convertModalQuote.depositRequired)}) para dar entrada na linha de produção.
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Valor do Adiantamento Recebido (Kz)
                </label>
                <input
                  type="number"
                  min="0"
                  max={convertModalQuote.total}
                  value={convertDeposit}
                  onChange={e => setConvertDeposit(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Método de Pagamento do Adiantamento
                </label>
                <select
                  value={convertPaymentMethod}
                  onChange={e => setConvertPaymentMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                >
                  <option value="multicaixa">Multicaixa (TPA)</option>
                  <option value="dinheiro">Dinheiro Físico</option>
                  <option value="transferencia">Transferência Bancária</option>
                  <option value="outro">Outro</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setConvertModalQuote(null)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmConvert}
                  className="px-5 py-2 bg-[#1E7620] hover:bg-green-700 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirmar e Gerar Encomenda</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
