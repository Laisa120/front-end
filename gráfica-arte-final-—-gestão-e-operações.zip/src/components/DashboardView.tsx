import React from 'react';
import {
  DollarSign,
  ShoppingBag,
  Clock,
  AlertTriangle,
  Package,
  Kanban,
  PlusCircle,
  FileText,
  UserPlus,
  ArrowRight,
  TrendingUp,
  CheckCircle2,
  Calendar,
  Layers,
} from 'lucide-react';
import { Order, Quote, CashMovement, StockItem, User, Client, Store } from '../types';
import { formatKz, formatDate, formatDateTime, getDaysRemaining } from '../utils/formatters';
import { PRODUCTION_STAGES } from '../services/mockData';
import { ActiveTab } from './TopNavbar';

interface DashboardViewProps {
  orders: Order[];
  quotes: Quote[];
  cashMovements: CashMovement[];
  stock: StockItem[];
  clients: Client[];
  activeStore: Store | null;
  currentUser: User;
  onNavigate: (tab: ActiveTab) => void;
  onSelectOrder: (order: Order) => void;
  onSelectQuote: (quote: Quote) => void;
  onNewOrder: () => void;
  onNewQuote: () => void;
  onNewCashMovement: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  orders,
  quotes,
  cashMovements,
  stock,
  clients,
  activeStore,
  currentUser,
  onNavigate,
  onSelectOrder,
  onSelectQuote,
  onNewOrder,
  onNewQuote,
  onNewCashMovement,
}) => {
  // 1. Cálculos de Vendas do Dia e Caixa
  const todayStr = new Date().toISOString().split('T')[0];
  const todayMovements = cashMovements.filter(m => m.timestamp.startsWith(todayStr));
  const todaySales = todayMovements
    .filter(m => ['pagamento_encomenda', 'adiantamento', 'pagamento_parcial', 'entrada'].includes(m.type))
    .reduce((sum, m) => sum + m.amount, 0);

  // 2. Encomendas Activas (não entregues e não canceladas)
  const activeOrders = orders.filter(o => !['entregue', 'cancelado'].includes(o.status));

  // 3. Valores por Receber (Dívidas de encomendas activas)
  const totalBalanceDue = orders
    .filter(o => o.status !== 'cancelado')
    .reduce((sum, o) => sum + o.balanceDue, 0);

  // 4. Trabalhos Atrasados
  const delayedOrders = orders.filter(o => {
    if (['entregue', 'cancelado'].includes(o.status)) return false;
    const { isOverdue } = getDaysRemaining(o.deadline);
    return isOverdue;
  });

  // 5. Alertas de Stock Crítico
  const lowStockItems = stock.filter(item => item.availableQty <= item.minQty);

  // 6. Orçamentos Pendentes
  const pendingQuotes = quotes.filter(q => q.status === 'pendente' || q.status === 'enviado');

  // 7. Contagem de Encomendas por Etapa de Produção
  const stageCounts = PRODUCTION_STAGES.map(stageInfo => {
    const count = orders.filter(o => o.productionStage === stageInfo.stage && o.status !== 'cancelado').length;
    return {
      ...stageInfo,
      count,
    };
  });

  return (
    <div className="space-y-6">
      {/* Faixa de Boas-Vindas e Ações Rápidas Operacionais */}
      <div className="bg-gradient-to-r from-[#062E3B] via-[#083d4e] to-[#041D26] rounded-xl p-5 sm:p-6 text-white shadow-md border border-[#0b4556] flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#F7CB18] uppercase tracking-wider mb-1">
            <span>Centro de Operações Integradas</span>
            <span>·</span>
            <span>{activeStore ? activeStore.name : 'Todas as Unidades'}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            Painel Operacional — Gráfica Arte Final
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            Acompanhamento em tempo real da carteira de encomendas, fases de produção, fluxos de caixa e alertas operacionais.
          </p>
        </div>

        {/* Ações Rápidas Responsivas */}
        <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center gap-2 sm:gap-3 shrink-0 w-full lg:w-auto">
          <button
            onClick={onNewQuote}
            className="flex items-center justify-center gap-2 px-3.5 py-2.5 sm:py-2 bg-[#13B8DB] hover:bg-[#0fa4c4] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors whitespace-nowrap min-h-[40px]"
          >
            <FileText className="w-4 h-4 shrink-0" />
            <span>Criar Orçamento</span>
          </button>

          <button
            onClick={onNewOrder}
            className="flex items-center justify-center gap-2 px-3.5 py-2.5 sm:py-2 bg-[#F7CB18] hover:bg-[#e0b710] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors whitespace-nowrap min-h-[40px]"
          >
            <PlusCircle className="w-4 h-4 shrink-0" />
            <span>Nova Encomenda</span>
          </button>

          {currentUser.role !== 'operador' && currentUser.role !== 'designer' && (
            <button
              onClick={onNewCashMovement}
              className="flex items-center justify-center gap-2 px-3.5 py-2.5 sm:py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-lg shadow-sm transition-colors whitespace-nowrap min-h-[40px]"
            >
              <DollarSign className="w-4 h-4 shrink-0" />
              <span>Registar Entrada/Pagamento</span>
            </button>
          )}
        </div>
      </div>

      {/* Resumo Operacional — Indicadores Compactos (Secção 4 do Requisito) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Vendas do Dia */}
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Entradas Hoje</span>
            <DollarSign className="w-4 h-4 text-[#1E7620]" />
          </div>
          <div className="text-base sm:text-lg font-black text-slate-900 tabular-nums">
            {formatKz(todaySales)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span>{todayMovements.length} movimentos registados</span>
          </div>
        </div>

        {/* Encomendas Activas */}
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Trabalhos Activos</span>
            <ShoppingBag className="w-4 h-4 text-[#13B8DB]" />
          </div>
          <div className="text-base sm:text-lg font-black text-slate-900 tabular-nums">
            {activeOrders.length}
          </div>
          <div className="text-[11px] text-[#13B8DB] font-semibold mt-1">
            {orders.filter(o => o.status === 'em_producao').length} em máquinas
          </div>
        </div>

        {/* Valores por Receber */}
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Valores a Receber</span>
            <TrendingUp className="w-4 h-4 text-[#E41179]" />
          </div>
          <div className="text-base sm:text-lg font-black text-[#E41179] tabular-nums">
            {formatKz(totalBalanceDue)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Saldos pendentes de entrega
          </div>
        </div>

        {/* Trabalhos Atrasados */}
        <div className={`rounded-xl p-4 border shadow-sm ${
          delayedOrders.length > 0 ? 'bg-red-50 border-red-200' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-rose-800">Trabalhos Atrasados</span>
            <Clock className={`w-4 h-4 ${delayedOrders.length > 0 ? 'text-red-600' : 'text-slate-400'}`} />
          </div>
          <div className={`text-base sm:text-lg font-black tabular-nums ${
            delayedOrders.length > 0 ? 'text-red-700' : 'text-slate-900'
          }`}>
            {delayedOrders.length}
          </div>
          <div className="text-[11px] text-rose-700 font-semibold mt-1">
            {delayedOrders.length > 0 ? 'Atenção urgente exigida' : 'Nenhum atraso'}
          </div>
        </div>

        {/* Alertas de Stock */}
        <div className={`rounded-xl p-4 border shadow-sm ${
          lowStockItems.length > 0 ? 'bg-amber-50 border-amber-200' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900">Alertas de Stock</span>
            <Package className={`w-4 h-4 ${lowStockItems.length > 0 ? 'text-amber-600' : 'text-slate-400'}`} />
          </div>
          <div className={`text-base sm:text-lg font-black tabular-nums ${
            lowStockItems.length > 0 ? 'text-amber-700' : 'text-slate-900'
          }`}>
            {lowStockItems.length}
          </div>
          <div className="text-[11px] text-amber-800 font-semibold mt-1">
            {lowStockItems.length > 0 ? 'Abaixo do limite mínimo' : 'Níveis normais'}
          </div>
        </div>

        {/* Orçamentos Pendentes */}
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Orçamentos Pendentes</span>
            <FileText className="w-4 h-4 text-[#F7CB18]" />
          </div>
          <div className="text-base sm:text-lg font-black text-slate-900 tabular-nums">
            {pendingQuotes.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            À espera de aprovação
          </div>
        </div>
      </div>

      {/* Monitorização da Produção por Fases (Pipeline de 9 Etapas) */}
      <div className="bg-white rounded-xl p-5 border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Kanban className="w-4 h-4 text-[#13B8DB]" />
              <span>Monitorização da Linha de Produção Gráfica</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Fluxo sequencial das encomendas em cada uma das etapas industriais.
            </p>
          </div>
          <button
            onClick={() => onNavigate('producao')}
            className="text-xs font-bold text-[#062E3B] hover:text-[#13B8DB] flex items-center gap-1 transition-colors"
          >
            <span>Ver Quadro de Produção Completo</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-2">
          {stageCounts.map(stage => {
            const isFinished = stage.stage === 9;
            const isReady = stage.stage === 8;
            const isProducing = stage.stage === 5;

            return (
              <div
                key={stage.stage}
                onClick={() => onNavigate('producao')}
                className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-sm ${
                  isProducing
                    ? 'bg-sky-50/70 border-sky-300'
                    : isReady
                    ? 'bg-amber-50/70 border-amber-300'
                    : isFinished
                    ? 'bg-emerald-50/60 border-emerald-200'
                    : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-bold text-slate-500">
                    Fase {stage.stage}
                  </span>
                  <span className={`text-xs font-black tabular-nums px-1.5 py-0.5 rounded ${
                    stage.count > 0
                      ? isProducing
                        ? 'bg-[#13B8DB] text-[#062E3B]'
                        : isReady
                        ? 'bg-[#F7CB18] text-[#062E3B]'
                        : isFinished
                        ? 'bg-[#1E7620] text-white'
                        : 'bg-slate-700 text-white'
                      : 'bg-slate-200 text-slate-500'
                  }`}>
                    {stage.count}
                  </span>
                </div>
                <div className="text-xs font-bold text-slate-800 leading-snug line-clamp-2">
                  {stage.name}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid Principal de Operações: Encomendas Recentes & Alertas Operacionais */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Coluna 1 e 2: Encomendas e Trabalhos Recentes */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-[#F7CB18]" />
                  <span>Trabalhos & Encomendas em Andamento</span>
                </h3>
                <span className="text-xs text-slate-500">Últimos pedidos registados e status de execução</span>
              </div>
              <button
                onClick={() => onNavigate('encomendas')}
                className="text-xs font-bold text-[#13B8DB] hover:underline"
              >
                Todas Encomendas ({orders.length}) →
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[580px] text-xs text-left">
                <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">Número / Cliente</th>
                    <th className="px-3 py-3">Serviços</th>
                    <th className="px-3 py-3">Etapa de Produção</th>
                    <th className="px-3 py-3">Prazo</th>
                    <th className="px-3 py-3 text-right">Total</th>
                    <th className="px-3 py-3 text-right">Saldo Devedor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {orders.slice(0, 5).map(order => {
                    const { days, isOverdue } = getDaysRemaining(order.deadline);
                    const isDelivered = order.status === 'entregue';
                    const stageInfo = PRODUCTION_STAGES.find(s => s.stage === order.productionStage);

                    return (
                      <tr
                        key={order.id}
                        onClick={() => onSelectOrder(order)}
                        className="hover:bg-slate-50/80 cursor-pointer transition-colors"
                      >
                        <td className="px-4 py-3">
                          <div className="font-bold text-slate-900">{order.number}</div>
                          <div className="text-slate-600 truncate max-w-[180px]">{order.clientName}</div>
                        </td>

                        <td className="px-3 py-3 text-slate-700">
                          <div className="font-medium truncate max-w-[200px]">
                            {order.items.map(i => i.serviceName).join(', ')}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {order.items.reduce((s, i) => s + i.quantity, 0)} itens
                          </div>
                        </td>

                        <td className="px-3 py-3">
                          <div className="font-semibold text-slate-800">
                            {stageInfo?.name || `Fase ${order.productionStage}`}
                          </div>
                          <div className="text-[10px] text-[#13B8DB] font-medium">
                            Resp: {order.assignedOperatorName || 'Não atribuído'}
                          </div>
                        </td>

                        <td className="px-3 py-3 whitespace-nowrap">
                          {isDelivered ? (
                            <span className="text-[11px] text-[#1E7620] font-bold">
                              Entregue
                            </span>
                          ) : isOverdue ? (
                            <span className="text-[11px] text-red-600 font-bold flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              Atrasado {days}d
                            </span>
                          ) : (
                            <span className="text-[11px] text-slate-600">
                              {formatDate(order.deadline)}
                            </span>
                          )}
                        </td>

                        <td className="px-3 py-3 text-right font-bold text-slate-900 tabular-nums">
                          {formatKz(order.total)}
                        </td>

                        <td className="px-3 py-3 text-right tabular-nums">
                          {order.balanceDue > 0 ? (
                            <span className="text-[#E41179] font-bold">
                              {formatKz(order.balanceDue)}
                            </span>
                          ) : (
                            <span className="text-[#1E7620] font-bold">
                              Liquidado
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Últimos Orçamentos Emitidos */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <FileText className="w-4 h-4 text-[#13B8DB]" />
                  <span>Últimos Orçamentos Comerciais</span>
                </h3>
                <span className="text-xs text-slate-500">Propostas emitidas e status de validação</span>
              </div>
              <button
                onClick={() => onNavigate('orcamentos')}
                className="text-xs font-bold text-[#13B8DB] hover:underline"
              >
                Ver Todos ({quotes.length}) →
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {quotes.slice(0, 4).map(quote => (
                <div
                  key={quote.id}
                  onClick={() => onSelectQuote(quote)}
                  className="p-3.5 px-4 flex items-center justify-between hover:bg-slate-50 cursor-pointer transition-colors"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900">{quote.number}</span>
                      <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        quote.status === 'aprovado'
                          ? 'bg-emerald-100 text-emerald-800'
                          : quote.status === 'pendente'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {quote.status}
                      </span>
                    </div>
                    <div className="text-xs text-slate-700 mt-0.5">{quote.clientName}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">
                      Emitido em {formatDate(quote.createdAt)} · Validade: {quote.validityDays} dias
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-xs font-black text-slate-900 tabular-nums">
                      {formatKz(quote.total)}
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      Sinal: {formatKz(quote.depositRequired)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Coluna 3: Alertas Operacionais e Resumo Financeiro de Caixa */}
        <div className="space-y-6">
          {/* Caixa de Alertas Operacionais */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
            <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>Alertas & Notificações Operacionais</span>
            </h3>

            <div className="space-y-3">
              {delayedOrders.length > 0 && (
                <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-900">
                  <div className="font-bold flex items-center gap-1.5 text-red-700">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{delayedOrders.length} Encomenda(s) Atrasada(s)</span>
                  </div>
                  <p className="mt-1 text-[11px] text-red-800">
                    {delayedOrders.map(o => o.number).join(', ')} ultrapassaram a data prometida ao cliente.
                  </p>
                  <button
                    onClick={() => onNavigate('producao')}
                    className="mt-2 text-[11px] font-bold text-red-800 underline block"
                  >
                    Aceder à Produção para Priorizar
                  </button>
                </div>
              )}

              {lowStockItems.length > 0 && (
                <div className="p-3 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900">
                  <div className="font-bold flex items-center gap-1.5 text-amber-800">
                    <Package className="w-3.5 h-3.5" />
                    <span>Stock Abaixo do Mínimo</span>
                  </div>
                  <ul className="mt-1 space-y-1 text-[11px] text-amber-900">
                    {lowStockItems.map(item => (
                      <li key={item.id} className="flex justify-between">
                        <span>{item.name}</span>
                        <span className="font-bold">{item.availableQty} {item.unit} (Mín: {item.minQty})</span>
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => onNavigate('stock')}
                    className="mt-2 text-[11px] font-bold text-amber-900 underline block"
                  >
                    Fazer Pedido a Fornecedores
                  </button>
                </div>
              )}

              {pendingQuotes.length > 0 && (
                <div className="p-3 rounded-lg bg-sky-50 border border-sky-200 text-xs text-sky-900">
                  <div className="font-bold flex items-center gap-1.5 text-sky-800">
                    <FileText className="w-3.5 h-3.5" />
                    <span>{pendingQuotes.length} Proposta(s) em Negociação</span>
                  </div>
                  <p className="mt-1 text-[11px] text-sky-800">
                    Contactar clientes para obter visto e fechar encomenda.
                  </p>
                </div>
              )}

              {delayedOrders.length === 0 && lowStockItems.length === 0 && pendingQuotes.length === 0 && (
                <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 text-center">
                  <CheckCircle2 className="w-5 h-5 mx-auto mb-1 text-emerald-600" />
                  <span className="font-bold">Tudo em conformidade!</span>
                  <p className="text-[11px] text-emerald-700 mt-0.5">Sem alertas críticos no momento.</p>
                </div>
              )}
            </div>
          </div>

          {/* Últimos Movimentos de Caixa */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#1E7620]" />
                <span>Movimentos Financeiros Recentes</span>
              </h3>
              <button
                onClick={() => onNavigate('caixa')}
                className="text-xs font-bold text-[#13B8DB] hover:underline"
              >
                Caixa →
              </button>
            </div>

            <div className="space-y-2.5">
              {cashMovements.slice(0, 5).map(mov => {
                const isOut = mov.type === 'despesa' || mov.type === 'saida';

                return (
                  <div
                    key={mov.id}
                    className="p-2.5 rounded-lg border border-slate-100 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-semibold text-slate-800 truncate max-w-[170px]">
                        {mov.description}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {formatDateTime(mov.timestamp)} · {mov.paymentMethod.toUpperCase()}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className={`font-black tabular-nums ${
                        isOut ? 'text-rose-600' : 'text-[#1E7620]'
                      }`}>
                        {isOut ? '-' : '+'}{formatKz(mov.amount)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {mov.receiptNumber}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
