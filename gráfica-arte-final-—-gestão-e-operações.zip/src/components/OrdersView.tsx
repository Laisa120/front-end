import React, { useState } from 'react';
import {
  ShoppingBag,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Printer,
  DollarSign,
  UserCheck,
  Send,
  Eye,
  ArrowRight,
  History,
  FileCheck,
  X,
  PlusCircle,
  Truck,
} from 'lucide-react';
import { Order, OrderStatus, Client, Service, Store, User, PaymentMethod, ProductionStageNumber } from '../types';
import { formatKz, formatDate, formatDateTime, getDaysRemaining } from '../utils/formatters';
import { PRODUCTION_STAGES } from '../services/mockData';

interface OrdersViewProps {
  orders: Order[];
  clients: Client[];
  services: Service[];
  stores: Store[];
  users: User[];
  activeStoreId: string;
  currentUser: User;
  onAddOrder: (order: Omit<Order, 'id' | 'number' | 'createdAt' | 'history' | 'issues'>) => void;
  onUpdateOrder: (order: Order) => void;
  onUpdateStage: (orderId: string, stage: ProductionStageNumber, note?: string) => void;
  onRegisterPayment: (orderId: string, amount: number, paymentMethod: PaymentMethod) => void;
  onPrintOrder: (order: Order) => void;
  preselectedOrder?: Order | null;
  preselectedClient?: Client | null;
}

export const OrdersView: React.FC<OrdersViewProps> = ({
  orders,
  clients,
  services,
  stores,
  users,
  activeStoreId,
  currentUser,
  onAddOrder,
  onUpdateOrder,
  onUpdateStage,
  onRegisterPayment,
  onPrintOrder,
  preselectedOrder,
  preselectedClient,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(preselectedOrder || null);
  const [isNewOrderModalOpen, setIsNewOrderModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isDeliveryModalOpen, setIsDeliveryModalOpen] = useState(false);

  // Pagamento State
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('multicaixa');

  // Entrega State
  const [deliveryRecipient, setDeliveryRecipient] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');

  // Formulário Nova Encomenda
  const [newClientId, setNewClientId] = useState<string>(preselectedClient?.id || clients[0]?.id || '');
  const [newServiceId, setNewServiceId] = useState<string>(services[0]?.id || '');
  const [newQty, setNewQty] = useState<number>(1);
  const [newTotal, setNewTotal] = useState<number>(1000);
  const [newInitialPaid, setNewInitialPaid] = useState<number>(0);
  const [newPriority, setNewPriority] = useState<'baixa' | 'normal' | 'alta' | 'urgente'>('normal');
  const [newDaysToDeliver, setNewDaysToDeliver] = useState<number>(3);
  const [newAssignedId, setNewAssignedId] = useState<string>('');
  const [newNotes, setNewNotes] = useState<string>('');

  const filteredOrders = orders.filter(order => {
    const matchesSearch =
      order.number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.clientName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus =
      statusFilter === 'all'
        ? true
        : statusFilter === 'atrasadas'
        ? getDaysRemaining(order.deadline).isOverdue && order.status !== 'entregue'
        : order.status === statusFilter;

    const matchesPriority = priorityFilter === 'all' || order.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const handleOpenAdd = () => {
    setNewClientId(clients[0]?.id || '');
    setNewServiceId(services[0]?.id || '');
    setNewQty(1);
    const s = services[0];
    const initialPrice = s ? s.price : 1000;
    setNewTotal(initialPrice);
    setNewInitialPaid(initialPrice * 0.5);
    setNewPriority('normal');
    setNewDaysToDeliver(3);
    setNewNotes('');
    setIsNewOrderModalOpen(true);
  };

  const handleSubmitNewOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find(c => c.id === newClientId);
    const service = services.find(s => s.id === newServiceId);
    if (!client || !service) return;

    const deadline = new Date();
    deadline.setDate(deadline.getDate() + newDaysToDeliver);

    const assignedUser = users.find(u => u.id === newAssignedId);

    onAddOrder({
      clientId: client.id,
      clientName: client.name,
      clientPhone: client.phone,
      storeId: activeStoreId === 'all' ? 'store-001' : activeStoreId,
      items: [
        {
          id: `item-${Date.now()}`,
          serviceId: service.id,
          serviceName: service.name,
          description: service.description,
          quantity: newQty,
          unitPrice: service.price,
          subtotal: newTotal,
        },
      ],
      total: newTotal,
      paidAmount: newInitialPaid,
      balanceDue: Math.max(0, newTotal - newInitialPaid),
      status: newInitialPaid >= newTotal ? 'em_preparacao' : (newInitialPaid > 0 ? 'em_preparacao' : 'aguarda_pagamento'),
      productionStage: 1,
      assignedOperatorId: assignedUser?.id,
      assignedOperatorName: assignedUser?.name,
      priority: newPriority,
      deadline: deadline.toISOString(),
      createdBy: currentUser.name,
      notes: newNotes,
    });

    setIsNewOrderModalOpen(false);
  };

  const handleOpenPayment = (order: Order) => {
    setSelectedOrder(order);
    setPaymentAmount(order.balanceDue);
    setPaymentMethod('multicaixa');
    setIsPaymentModalOpen(true);
  };

  const handleConfirmPayment = () => {
    if (!selectedOrder || paymentAmount <= 0) return;
    onRegisterPayment(selectedOrder.id, paymentAmount, paymentMethod);
    setIsPaymentModalOpen(false);
    // Atualiza selecionado
    const updated = {
      ...selectedOrder,
      paidAmount: selectedOrder.paidAmount + paymentAmount,
      balanceDue: Math.max(0, selectedOrder.total - (selectedOrder.paidAmount + paymentAmount)),
    };
    setSelectedOrder(updated);
  };

  const handleOpenDelivery = (order: Order) => {
    setSelectedOrder(order);
    setDeliveryRecipient(order.clientName);
    setDeliveryNotes('Trabalho verificado e entregue com talão assinado.');
    setIsDeliveryModalOpen(true);
  };

  const handleConfirmDelivery = () => {
    if (!selectedOrder) return;
    onUpdateStage(selectedOrder.id, 9, `Entrega concluída. Levantado por: ${deliveryRecipient}. ${deliveryNotes}`);
    setIsDeliveryModalOpen(false);
    setSelectedOrder({
      ...selectedOrder,
      status: 'entregue',
      productionStage: 9,
      deliveredAt: new Date().toISOString(),
      deliveryNotes: `Levantado por: ${deliveryRecipient}. ${deliveryNotes}`,
    });
  };

  const operators = users.filter(u => u.role === 'operador' || u.role === 'designer');

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <ShoppingBag className="w-6 h-6 text-[#13B8DB]" />
            <span>Gestão Central de Encomendas</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Acompanhamento de trabalhos gráficos em carteira, saldos devedores, prazos e registo de entregas.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Nova Encomenda Directa</span>
        </button>
      </div>

      {/* Barra de Filtros e Pesquisa */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pesquisar por número ENC-XXXX ou cliente..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#13B8DB] text-slate-900"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          {[
            { id: 'all', label: 'Todas as Encomendas' },
            { id: 'em_producao', label: 'Em Produção' },
            { id: 'pronto_entrega', label: 'Prontas p/ Entrega' },
            { id: 'atrasadas', label: 'Atrasadas (!)' },
            { id: 'entregue', label: 'Entregues' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setStatusFilter(f.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                statusFilter === f.id
                  ? 'bg-[#062E3B] text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Grid com Tabela e Detalhes da Encomenda Selecionada */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tabela de Encomendas */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[650px] text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">Número / Cliente</th>
                  <th className="px-3 py-3">Etapa Actual</th>
                  <th className="px-3 py-3">Prazo</th>
                  <th className="px-3 py-3 text-right">Total</th>
                  <th className="px-3 py-3 text-right">Dívida / Saldo</th>
                  <th className="px-3 py-3 text-center">Estado</th>
                  <th className="px-4 py-3 text-right">Acções</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOrders.map(order => {
                  const { days, isOverdue } = getDaysRemaining(order.deadline);
                  const isSelected = selectedOrder?.id === order.id;
                  const isDelivered = order.status === 'entregue';
                  const stageInfo = PRODUCTION_STAGES.find(s => s.stage === order.productionStage);

                  return (
                    <tr
                      key={order.id}
                      onClick={() => setSelectedOrder(order)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-sky-50 font-medium' : 'hover:bg-slate-50'
                      }`}
                    >
                      <td className="px-4 py-3.5">
                        <div className="font-bold text-slate-900">{order.number}</div>
                        <div className="text-slate-600 truncate max-w-[170px]">{order.clientName}</div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          {order.items.map(i => i.serviceName).join(', ')}
                        </div>
                      </td>

                      <td className="px-3 py-3.5">
                        <div className="font-bold text-slate-800">
                          {stageInfo ? `${order.productionStage}. ${stageInfo.name}` : `Fase ${order.productionStage}`}
                        </div>
                        <div className="text-[10px] text-[#13B8DB] font-semibold mt-0.5">
                          {order.assignedOperatorName || 'Sem operador'}
                        </div>
                      </td>

                      <td className="px-3 py-3.5 whitespace-nowrap">
                        {isDelivered ? (
                          <span className="text-[11px] text-[#1E7620] font-bold">
                            Entregue {formatDate(order.deliveredAt)}
                          </span>
                        ) : isOverdue ? (
                          <span className="text-[11px] text-red-600 font-bold flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            Atrasado {days}d
                          </span>
                        ) : (
                          <span className="text-[11px] text-slate-700">
                            {formatDate(order.deadline)}
                          </span>
                        )}
                      </td>

                      <td className="px-3 py-3.5 text-right font-black text-slate-900 tabular-nums">
                        {formatKz(order.total)}
                      </td>

                      <td className="px-3 py-3.5 text-right tabular-nums">
                        {order.balanceDue > 0 ? (
                          <span className="text-[#E41179] font-bold">
                            {formatKz(order.balanceDue)}
                          </span>
                        ) : (
                          <span className="text-[#1E7620] font-bold">
                            Liquidado
                          </span>
                        )}
                      </td>

                      <td className="px-3 py-3.5 text-center">
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                          order.status === 'entregue'
                            ? 'bg-emerald-100 text-emerald-800'
                            : order.status === 'pronto_entrega'
                            ? 'bg-amber-100 text-amber-800'
                            : order.status === 'em_producao'
                            ? 'bg-sky-100 text-sky-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}>
                          {order.status}
                        </span>
                      </td>

                      <td className="px-4 py-3.5 text-right whitespace-nowrap">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onPrintOrder(order);
                          }}
                          className="p-1.5 text-slate-500 hover:text-[#062E3B] hover:bg-slate-100 rounded"
                          title="Imprimir Talão"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}

                {filteredOrders.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">
                      Nenhuma encomenda encontrada com os filtros actuais.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Ficha da Encomenda Selecionada (Secção 8) */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 flex flex-col justify-between">
          {selectedOrder ? (
            <div className="space-y-4">
              <div className="flex items-start justify-between pb-3 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-black text-base text-slate-900">{selectedOrder.number}</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-[#062E3B] uppercase">
                      Fase {selectedOrder.productionStage}/9
                    </span>
                  </div>
                  <div className="font-bold text-xs text-[#13B8DB] mt-0.5">{selectedOrder.clientName}</div>
                  <div className="text-[10px] text-slate-400">Criada em {formatDateTime(selectedOrder.createdAt)}</div>
                </div>

                <button
                  onClick={() => onPrintOrder(selectedOrder)}
                  className="p-1.5 text-slate-400 hover:text-slate-800 rounded"
                  title="Imprimir Guia de Produção"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </div>

              {/* Informações Financeiras da Encomenda */}
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Valor Total:</span>
                  <span className="font-bold text-slate-900 tabular-nums">{formatKz(selectedOrder.total)}</span>
                </div>
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Valor Já Liquidado:</span>
                  <span className="font-mono tabular-nums">{formatKz(selectedOrder.paidAmount)}</span>
                </div>
                <div className="flex justify-between font-black text-slate-900 pt-1 border-t border-slate-200">
                  <span className={selectedOrder.balanceDue > 0 ? 'text-[#E41179]' : 'text-emerald-700'}>
                    Saldo Pendente:
                  </span>
                  <span className={`tabular-nums ${selectedOrder.balanceDue > 0 ? 'text-[#E41179]' : 'text-emerald-700'}`}>
                    {formatKz(selectedOrder.balanceDue)}
                  </span>
                </div>
              </div>

              {/* Botão para Liquidar Saldo se houver dívida */}
              {selectedOrder.balanceDue > 0 && (
                <button
                  onClick={() => handleOpenPayment(selectedOrder)}
                  className="w-full flex items-center justify-center gap-2 py-2 bg-[#1E7620] hover:bg-green-700 text-white font-bold text-xs rounded-lg transition-colors"
                >
                  <DollarSign className="w-4 h-4" />
                  <span>Registar Pagamento de Saldo ({formatKz(selectedOrder.balanceDue)})</span>
                </button>
              )}

              {/* Atribuição de Operador e Avanço de Etapa */}
              <div className="space-y-2">
                <label className="block text-[11px] font-bold text-slate-700 uppercase">
                  Atribuir Operador de Produção
                </label>
                <select
                  value={selectedOrder.assignedOperatorId || ''}
                  onChange={e => {
                    const op = operators.find(o => o.id === e.target.value);
                    onUpdateOrder({
                      ...selectedOrder,
                      assignedOperatorId: op?.id,
                      assignedOperatorName: op?.name,
                    });
                  }}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold focus:outline-none"
                >
                  <option value="">Nenhum operador atribuído</option>
                  {operators.map(op => (
                    <option key={op.id} value={op.id}>
                      {op.name} ({op.role.toUpperCase()})
                    </option>
                  ))}
                </select>
              </div>

              {/* Avanço Rápido de Fase */}
              {selectedOrder.status !== 'entregue' && (
                <div className="p-3 bg-sky-50 rounded-lg border border-sky-200">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-bold text-[#062E3B]">Avançar Linha de Produção</span>
                    <span className="text-[10px] text-slate-500">Etapa actual: {selectedOrder.productionStage}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {selectedOrder.productionStage < 8 && (
                      <button
                        onClick={() => onUpdateStage(selectedOrder.id, (selectedOrder.productionStage + 1) as ProductionStageNumber)}
                        className="py-1.5 px-2 bg-[#13B8DB] hover:bg-[#0ea5c4] text-[#062E3B] font-bold text-xs rounded transition-colors text-center"
                      >
                        Avançar p/ Fase {selectedOrder.productionStage + 1} →
                      </button>
                    )}

                    {selectedOrder.productionStage >= 7 && (
                      <button
                        onClick={() => handleOpenDelivery(selectedOrder)}
                        className="col-span-2 py-2 px-3 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Truck className="w-4 h-4" />
                        <span>Registar Entrega ao Cliente (Fase 9)</span>
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Histórico de Auditoria */}
              <div>
                <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider block mb-1">
                  Histórico de Alterações & Auditoria ({selectedOrder.history.length})
                </span>
                <div className="max-h-36 overflow-y-auto space-y-1.5 border border-slate-100 rounded-lg p-2 text-[11px]">
                  {selectedOrder.history.map(h => (
                    <div key={h.id} className="pb-1.5 border-b border-slate-100 last:border-none">
                      <div className="flex items-center justify-between font-semibold text-slate-800">
                        <span>{h.user}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{formatDateTime(h.timestamp)}</span>
                      </div>
                      <p className="text-slate-600 mt-0.5">{h.action}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center text-slate-400">
              <ShoppingBag className="w-12 h-12 text-slate-300 mb-3" />
              <div className="font-bold text-sm text-slate-700">Selecione uma encomenda</div>
              <p className="text-xs text-slate-500 mt-1 max-w-xs">
                Clique numa linha da tabela para ver a ficha completa, saldo em dívida, histórico de alterações ou registar pagamento e entrega.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Modal de Pagamento de Saldo */}
      {isPaymentModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Registar Pagamento de Saldo</h3>
                <p className="text-[11px] text-[#13B8DB]">{selectedOrder.number} — {selectedOrder.clientName}</p>
              </div>
              <button onClick={() => setIsPaymentModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex justify-between">
                <span>Saldo Actual em Falta:</span>
                <span className="font-black text-[#E41179] tabular-nums">{formatKz(selectedOrder.balanceDue)}</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Valor a Pagar Agora (Kz) *
                </label>
                <input
                  type="number"
                  min="1"
                  max={selectedOrder.balanceDue}
                  value={paymentAmount}
                  onChange={e => setPaymentAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Método de Liquidação
                </label>
                <select
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                >
                  <option value="multicaixa">Multicaixa (TPA)</option>
                  <option value="dinheiro">Dinheiro Físico</option>
                  <option value="transferencia">Transferência Bancária</option>
                  <option value="outro">Outro</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmPayment}
                  className="px-5 py-2 bg-[#1E7620] hover:bg-green-700 text-white font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirmar & Emitir Recibo de Caixa</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Registo de Entrega */}
      {isDeliveryModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Registar Entrega ao Cliente</h3>
                <p className="text-[11px] text-[#13B8DB]">{selectedOrder.number} — {selectedOrder.clientName}</p>
              </div>
              <button onClick={() => setIsDeliveryModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {selectedOrder.balanceDue > 0 && (
                <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-900">
                  <div className="font-bold flex items-center gap-1">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>Atenção: Existe Saldo Pendente ({formatKz(selectedOrder.balanceDue)})</span>
                  </div>
                  <p className="mt-1 text-[11px]">
                    Certifique-se de cobrar o valor no caixa antes de entregar o material ou registe a autorização da gerência.
                  </p>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nome de Quem Levantou o Material *
                </label>
                <input
                  type="text"
                  required
                  value={deliveryRecipient}
                  onChange={e => setDeliveryRecipient(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Observações da Entrega
                </label>
                <textarea
                  rows={2}
                  value={deliveryNotes}
                  onChange={e => setDeliveryNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsDeliveryModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelivery}
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Concluir Entrega (Etapa 9)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Nova Encomenda Direta */}
      {isNewOrderModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Criar Nova Encomenda Directa</h3>
                <p className="text-[11px] text-[#13B8DB]">Abertura de ordem de produção para balcão</p>
              </div>
              <button onClick={() => setIsNewOrderModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitNewOrder} className="p-4 sm:p-5 space-y-4 overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Cliente *</label>
                <select
                  value={newClientId}
                  onChange={e => setNewClientId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                >
                  {clients.map(c => (
                    <option key={c.id} value={c.id}>{c.name} — {c.phone}</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Serviço Gráfico Principal *</label>
                  <select
                    value={newServiceId}
                    onChange={e => {
                      setNewServiceId(e.target.value);
                      const s = services.find(x => x.id === e.target.value);
                      if (s) {
                        const t = s.price * newQty;
                        setNewTotal(t);
                        setNewInitialPaid(t * 0.5);
                      }
                    }}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  >
                    {services.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({formatKz(s.price)}/{s.unit})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Quantidade</label>
                  <input
                    type="number"
                    min="1"
                    value={newQty}
                    onChange={e => {
                      const q = parseInt(e.target.value) || 1;
                      setNewQty(q);
                      const s = services.find(x => x.id === newServiceId);
                      if (s) {
                        const t = s.price * q;
                        setNewTotal(t);
                        setNewInitialPaid(t * 0.5);
                      }
                    }}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Prazo (Dias)</label>
                  <input
                    type="number"
                    min="1"
                    value={newDaysToDeliver}
                    onChange={e => setNewDaysToDeliver(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Valor Total (Kz) *</label>
                  <input
                    type="number"
                    min="1"
                    value={newTotal}
                    onChange={e => setNewTotal(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Adiantamento Inicial (Kz)</label>
                  <input
                    type="number"
                    min="0"
                    max={newTotal}
                    value={newInitialPaid}
                    onChange={e => setNewInitialPaid(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-emerald-700"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Prioridade</label>
                  <select
                    value={newPriority}
                    onChange={e => setNewPriority(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="baixa">Baixa</option>
                    <option value="normal">Normal</option>
                    <option value="alta">Alta</option>
                    <option value="urgente">Urgente (!)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Atribuir Operador</label>
                  <select
                    value={newAssignedId}
                    onChange={e => setNewAssignedId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="">Por atribuir</option>
                    {operators.map(op => (
                      <option key={op.id} value={op.id}>{op.name}</option>
                    ))}
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Instruções de Produção</label>
                  <textarea
                    rows={2}
                    value={newNotes}
                    onChange={e => setNewNotes(e.target.value)}
                    placeholder="Especificações de sangria, tipo de corte, prazo acordado..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsNewOrderModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
                >
                  Abrir Encomenda & Iniciar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
