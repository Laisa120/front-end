import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Search,
  Printer,
  Sparkles,
  Megaphone,
  Calendar,
  Scissors,
  Palette,
  CheckCircle2,
  Clock,
  Calculator,
  ArrowRight,
  Edit3,
  X,
} from 'lucide-react';
import { Service, ServiceCategory, PricingModel } from '../types';
import { formatKz } from '../utils/formatters';

interface ServicesViewProps {
  services: Service[];
  onAddService: (service: Omit<Service, 'id'>) => void;
  onUpdateService: (service: Service) => void;
  onSelectServiceForQuote?: (service: Service, quantity: number, calculatedPrice: number) => void;
}

export const ServicesView: React.FC<ServicesViewProps> = ({
  services,
  onAddService,
  onUpdateService,
  onSelectServiceForQuote,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<Service | null>(null);

  // Simulador de Balcão
  const [calcServiceId, setCalcServiceId] = useState<string>(services[0]?.id || '');
  const [calcQty, setCalcQty] = useState<number>(1);
  const [calcWidth, setCalcWidth] = useState<number>(1);
  const [calcHeight, setCalcHeight] = useState<number>(1);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    category: 'impressao' as ServiceCategory,
    description: '',
    price: 1000,
    unit: 'unidade' as Service['unit'],
    estimatedHours: 4,
    pricingModel: 'fixo' as PricingModel,
    active: true,
  });

  const categories: { id: string; label: string; icon: React.ElementType }[] = [
    { id: 'all', label: 'Todos os Serviços', icon: Layers },
    { id: 'impressao', label: 'Impressão & Cópias', icon: Printer },
    { id: 'identidade', label: 'Identidade Corporativa', icon: Sparkles },
    { id: 'publicidade', label: 'Publicidade & Grande Formato', icon: Megaphone },
    { id: 'eventos', label: 'Eventos & Brindes', icon: Calendar },
    { id: 'acabamentos', label: 'Acabamentos Gráficos', icon: Scissors },
    { id: 'design', label: 'Design Gráfico & Pré-Impressão', icon: Palette },
  ];

  const filteredServices = services.filter(service => {
    const matchesCategory = selectedCategory === 'all' || service.category === selectedCategory;
    const matchesSearch =
      service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleOpenAdd = () => {
    setEditingService(null);
    setFormData({
      name: '',
      category: 'impressao',
      description: '',
      price: 2500,
      unit: 'unidade',
      estimatedHours: 12,
      pricingModel: 'fixo',
      active: true,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (service: Service) => {
    setEditingService(service);
    setFormData({
      name: service.name,
      category: service.category,
      description: service.description,
      price: service.price,
      unit: service.unit,
      estimatedHours: service.estimatedHours,
      pricingModel: service.pricingModel,
      active: service.active,
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    if (editingService) {
      onUpdateService({
        ...editingService,
        ...formData,
      });
    } else {
      onAddService(formData);
    }
    setIsModalOpen(false);
  };

  // Cálculo do simulador de balcão
  const calcSelectedService = services.find(s => s.id === calcServiceId) || services[0];
  let calculatedSubtotal = 0;
  if (calcSelectedService) {
    if (calcSelectedService.unit === 'm2') {
      const area = Math.max(0.1, calcWidth * calcHeight);
      calculatedSubtotal = area * calcSelectedService.price * calcQty;
    } else {
      calculatedSubtotal = calcSelectedService.price * calcQty;
    }
  }

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="w-6 h-6 text-[#13B8DB]" />
            <span>Catálogo de Serviços Gráficos</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Tabela de preços oficiais, unidades de cobrança, modelos de cálculo e prazos de produção da Gráfica Arte Final.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Novo Serviço</span>
        </button>
      </div>

      {/* Simulador / Calculadora de Preço Rápido de Balcão */}
      <div className="bg-gradient-to-r from-[#062E3B] to-[#0b4556] rounded-xl p-4 sm:p-5 text-white border border-[#13B8DB]/30 shadow-md">
        <div className="flex items-center gap-2 text-xs font-bold text-[#F7CB18] uppercase tracking-wider mb-2">
          <Calculator className="w-4 h-4 text-[#F7CB18]" />
          <span>Calculadora de Orçamento Rápido de Balcão</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end">
          <div className="lg:col-span-2">
            <label className="block text-[11px] font-semibold text-slate-300 mb-1">
              Serviço Gráfico
            </label>
            <select
              value={calcServiceId}
              onChange={e => setCalcServiceId(e.target.value)}
              className="w-full px-3 py-2 bg-[#041d26] border border-[#13B8DB]/40 rounded-lg text-xs font-medium text-white focus:outline-none focus:ring-2 focus:ring-[#F7CB18]"
            >
              {services.filter(s => s.active).map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({formatKz(s.price)} / {s.unit})
                </option>
              ))}
            </select>
          </div>

          {calcSelectedService?.unit === 'm2' ? (
            <>
              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Largura (metros)
                </label>
                <input
                  type="number"
                  step="0.05"
                  min="0.1"
                  value={calcWidth}
                  onChange={e => setCalcWidth(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-[#041d26] border border-[#13B8DB]/40 rounded-lg text-xs font-mono text-white focus:outline-none focus:ring-2 focus:ring-[#F7CB18]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                  Altura (metros)
                </label>
                <input
                  type="number"
                  step="0.05"
                  min="0.1"
                  value={calcHeight}
                  onChange={e => setCalcHeight(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-[#041d26] border border-[#13B8DB]/40 rounded-lg text-xs font-mono text-white focus:outline-none focus:ring-2 focus:ring-[#F7CB18]"
                />
              </div>
            </>
          ) : (
            <div>
              <label className="block text-[11px] font-semibold text-slate-300 mb-1">
                Quantidade ({calcSelectedService?.unit})
              </label>
              <input
                type="number"
                min="1"
                value={calcQty}
                onChange={e => setCalcQty(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 bg-[#041d26] border border-[#13B8DB]/40 rounded-lg text-xs font-mono text-white focus:outline-none focus:ring-2 focus:ring-[#F7CB18]"
              />
            </div>
          )}

          <div className="bg-[#041d26] p-2.5 rounded-lg border border-[#F7CB18]/40 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold block">Preço Calculado</span>
              <span className="text-sm sm:text-base font-black text-[#F7CB18] tabular-nums">
                {formatKz(calculatedSubtotal)}
              </span>
            </div>

            {onSelectServiceForQuote && (
              <button
                onClick={() => onSelectServiceForQuote(calcSelectedService, calcQty, calculatedSubtotal)}
                className="px-2.5 py-1.5 bg-[#13B8DB] hover:bg-[#0ea5c4] text-[#062E3B] text-[11px] font-bold rounded flex items-center gap-1 transition-colors"
                title="Lançar este cálculo em novo orçamento"
              >
                <span>Usar</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Categorias & Barra de Pesquisa */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="relative w-full md:w-96">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Pesquisar por nome ou especificação do serviço..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#13B8DB] text-slate-900"
            />
          </div>

          <div className="text-xs text-slate-500 font-medium">
            {filteredServices.length} serviços disponíveis
          </div>
        </div>

        {/* Tabs de Categoria */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {categories.map(cat => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;

            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                  isSelected
                    ? 'bg-[#062E3B] text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-[#F7CB18]' : 'text-slate-500'}`} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Grade de Serviços Gráficos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredServices.map(service => (
          <div
            key={service.id}
            className={`bg-white rounded-xl border p-4.5 shadow-sm hover:border-[#13B8DB] transition-all flex flex-col justify-between ${
              service.active ? 'border-slate-200' : 'border-slate-200 opacity-60 bg-slate-50'
            }`}
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                  {service.category}
                </span>

                <button
                  onClick={() => handleOpenEdit(service)}
                  className="p-1 text-slate-400 hover:text-slate-800 rounded transition-colors"
                  title="Editar serviço"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
              </div>

              <h3 className="font-bold text-sm text-slate-900 leading-snug">
                {service.name}
              </h3>
              <p className="text-xs text-slate-500 mt-1.5 line-clamp-2">
                {service.description}
              </p>
            </div>

            <div className="pt-4 mt-3 border-t border-slate-100 flex items-end justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Preço Base</span>
                <div className="text-base font-black text-[#062E3B] tabular-nums">
                  {formatKz(service.price)}
                  <span className="text-xs font-normal text-slate-500 ml-1">/ {service.unit}</span>
                </div>
              </div>

              <div className="text-right">
                <div className="flex items-center gap-1 text-[11px] text-slate-500 font-medium">
                  <Clock className="w-3 h-3 text-[#13B8DB]" />
                  <span>~{service.estimatedHours}h estimadas</span>
                </div>
                <span className="text-[10px] font-semibold text-slate-400 capitalize block mt-0.5">
                  Modelo: {service.pricingModel}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal de Criação / Edição de Serviço */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 sm:p-5 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-black text-sm uppercase tracking-wider text-white">
                  {editingService ? 'Editar Serviço Gráfico' : 'Registar Novo Serviço'}
                </h3>
                <p className="text-[11px] text-[#13B8DB] mt-0.5">
                  Configure especificações, modelo de cobrança e preço em Kwanzas.
                </p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 sm:p-5 space-y-4 overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nome do Serviço Gráfico *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="ex: Roll-up 85x200cm ou Lona 510g"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Categoria
                  </label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value as ServiceCategory })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  >
                    <option value="impressao">Impressão & Cópias</option>
                    <option value="identidade">Identidade Corporativa</option>
                    <option value="publicidade">Publicidade & Grande Formato</option>
                    <option value="eventos">Eventos & Brindes</option>
                    <option value="acabamentos">Acabamentos</option>
                    <option value="design">Design Gráfico</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Unidade de Cobrança
                  </label>
                  <select
                    value={formData.unit}
                    onChange={e => setFormData({ ...formData, unit: e.target.value as Service['unit'] })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  >
                    <option value="unidade">Unidade</option>
                    <option value="m2">Metro Quadrado (m²)</option>
                    <option value="cento">Cento (100un)</option>
                    <option value="milheiro">Milheiro (1000un)</option>
                    <option value="folha">Folha</option>
                    <option value="hora">Hora Técnica</option>
                    <option value="pacote">Pacote</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Preço Base Oficial (Kz) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={formData.price}
                    onChange={e => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Prazo Estimado (Horas)
                  </label>
                  <input
                    type="number"
                    min="0.5"
                    step="0.5"
                    value={formData.estimatedHours}
                    onChange={e => setFormData({ ...formData, estimatedHours: parseFloat(e.target.value) || 1 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Modelo de Preço
                  </label>
                  <select
                    value={formData.pricingModel}
                    onChange={e => setFormData({ ...formData, pricingModel: e.target.value as PricingModel })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  >
                    <option value="fixo">Preço Fixo</option>
                    <option value="quantidade">Preço por Quantidade</option>
                    <option value="personalizado">Preço Personalizado (Dimensões/Material)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Estado do Serviço
                  </label>
                  <select
                    value={formData.active ? 'true' : 'false'}
                    onChange={e => setFormData({ ...formData, active: e.target.value === 'true' })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                  >
                    <option value="true">Activo no Catálogo</option>
                    <option value="false">Desactivado / Indisponível</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Descrição Técnica e Requisitos
                </label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  placeholder="ex: Impressão 4/4 cores, papel couché 350g, laminação mate..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
                >
                  {editingService ? 'Guardar Alterações' : 'Adicionar ao Catálogo'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
