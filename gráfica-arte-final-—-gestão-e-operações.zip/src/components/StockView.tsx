import React, { useState } from 'react';
import {
  Package,
  Plus,
  Search,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  ArrowLeftRight,
  SlidersHorizontal,
  History,
  Building2,
  CheckCircle2,
  X,
  Truck,
  Edit2,
} from 'lucide-react';
import { StockItem, StockMovement, StockCategory, Supplier, Store, User } from '../types';
import { formatKz, formatDate, formatDateTime } from '../utils/formatters';

interface StockViewProps {
  stock: StockItem[];
  movements: StockMovement[];
  suppliers: Supplier[];
  stores: Store[];
  activeStoreId: string;
  currentUser: User;
  onAddStockItem: (item: Omit<StockItem, 'id' | 'updatedAt'>) => void;
  onUpdateStockItem: (item: StockItem) => void;
  onAdjustStock: (
    itemId: string,
    quantityChange: number,
    type: 'entrada' | 'saida' | 'ajuste' | 'transferencia' | 'consumo_encomenda',
    reason: string
  ) => void;
}

export const StockView: React.FC<StockViewProps> = ({
  stock,
  movements,
  suppliers,
  stores,
  activeStoreId,
  currentUser,
  onAddStockItem,
  onUpdateStockItem,
  onAdjustStock,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);
  const [isNewItemModalOpen, setIsNewItemModalOpen] = useState(false);
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState(false);
  const [selectedStockItem, setSelectedStockItem] = useState<StockItem | null>(null);

  // Form Ajuste / Entrada State
  const [adjustType, setAdjustType] = useState<'entrada' | 'saida' | 'ajuste'>('entrada');
  const [adjustQty, setAdjustQty] = useState<number>(1);
  const [adjustReason, setAdjustReason] = useState('');

  // Form Novo Produto State
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    category: 'papeis' as StockCategory,
    unit: 'resmas',
    availableQty: 10,
    minQty: 5,
    unitCost: 5000,
    supplierId: suppliers[0]?.id || '',
    storeId: activeStoreId === 'all' ? 'store-001' : activeStoreId,
    location: '',
  });

  const categories: { id: string; label: string }[] = [
    { id: 'all', label: 'Todos os Materiais' },
    { id: 'papeis', label: 'Papéis & Cartolinas' },
    { id: 'tintas_toner', label: 'Tintas & Toners' },
    { id: 'lonas_vinil', label: 'Lonas & Vinil' },
    { id: 'acabamentos', label: 'Acabamentos & Espirais' },
    { id: 'consumiveis', label: 'Estruturas & Acessórios' },
  ];

  const filteredStock = stock.filter(item => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.code.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || item.category === categoryFilter;
    const matchesLowStock = !showLowStockOnly || item.availableQty <= item.minQty;
    return matchesSearch && matchesCategory && matchesLowStock;
  });

  const lowStockCount = stock.filter(item => item.availableQty <= item.minQty).length;
  const totalStockValue = stock.reduce((sum, item) => sum + item.availableQty * item.unitCost, 0);

  const handleOpenAdjust = (item: StockItem, type: 'entrada' | 'saida' | 'ajuste') => {
    setSelectedStockItem(item);
    setAdjustType(type);
    setAdjustQty(1);
    setAdjustReason(type === 'entrada' ? 'Recepção de encomenda de fornecedor' : 'Consumo interno de produção');
    setIsAdjustModalOpen(true);
  };

  const handleConfirmAdjust = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStockItem || adjustQty <= 0) return;

    const change = adjustType === 'entrada' ? adjustQty : -adjustQty;
    onAdjustStock(selectedStockItem.id, change, adjustType, adjustReason);
    setIsAdjustModalOpen(false);
  };

  const handleSubmitNewItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.code.trim()) return;

    const sup = suppliers.find(s => s.id === formData.supplierId);

    onAddStockItem({
      ...formData,
      supplierName: sup?.name,
      status: formData.availableQty <= formData.minQty ? 'baixo' : 'normal',
    });

    setIsNewItemModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Package className="w-6 h-6 text-[#F7CB18]" />
            <span>Gestão de Stock & Materiais de Produção</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Inventário de matérias-primas, papéis, tintas, bobinas de lona e alertas de reposição mínima.
          </p>
        </div>

        <button
          onClick={() => {
            setFormData({
              code: `STK-${Date.now().toString().slice(-4)}`,
              name: '',
              category: 'papeis',
              unit: 'resmas',
              availableQty: 10,
              minQty: 5,
              unitCost: 5000,
              supplierId: suppliers[0]?.id || '',
              storeId: activeStoreId === 'all' ? 'store-001' : activeStoreId,
              location: 'Armazém Central',
            });
            setIsNewItemModalOpen(true);
          }}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm transition-colors shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Cadastrar Novo Material</span>
        </button>
      </div>

      {/* Cartões de Indicadores de Stock */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Total de Artigos</span>
          <div className="text-xl font-black text-slate-900 mt-1 tabular-nums">{stock.length} itens</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Disponíveis no inventário da loja</div>
        </div>

        <div className={`rounded-xl p-4 border shadow-sm ${
          lowStockCount > 0 ? 'bg-amber-50 border-amber-200' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900">Em Alerta Crítico</span>
            <AlertTriangle className={`w-4 h-4 ${lowStockCount > 0 ? 'text-amber-600' : 'text-slate-400'}`} />
          </div>
          <div className={`text-xl font-black mt-1 tabular-nums ${lowStockCount > 0 ? 'text-amber-700' : 'text-slate-900'}`}>
            {lowStockCount} materiais
          </div>
          <button
            onClick={() => setShowLowStockOnly(!showLowStockOnly)}
            className="text-[11px] text-amber-800 font-bold underline mt-0.5 block"
          >
            {showLowStockOnly ? 'Mostrar Todos os Artigos' : 'Filtrar apenas artigos críticos'}
          </button>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Valorização de Stock</span>
          <div className="text-xl font-black text-[#062E3B] mt-1 tabular-nums">{formatKz(totalStockValue)}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Custo acumulado de aquisição</div>
        </div>
      </div>

      {/* Filtros e Pesquisa */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Pesquisar por código STK-... ou nome do material..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:ring-2 focus:ring-[#13B8DB] text-slate-900 focus:outline-none"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                categoryFilter === cat.id
                  ? 'bg-[#062E3B] text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tabela de Stock */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[650px] text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Código / Material</th>
                <th className="px-3 py-3">Categoria</th>
                <th className="px-3 py-3 text-center">Disponível</th>
                <th className="px-3 py-3 text-center">Stock Mínimo</th>
                <th className="px-3 py-3 text-right">Custo Unitário</th>
                <th className="px-3 py-3">Fornecedor</th>
                <th className="px-4 py-3 text-right">Acções Operacionais</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStock.map(item => {
                const isLow = item.availableQty <= item.minQty;

                return (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="font-bold text-slate-900">{item.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        {item.code} {item.location ? `· ${item.location}` : ''}
                      </div>
                    </td>

                    <td className="px-3 py-3.5 capitalize text-slate-600">
                      {item.category.replace('_', ' ')}
                    </td>

                    <td className="px-3 py-3.5 text-center">
                      <span className={`font-mono text-xs font-black px-2.5 py-1 rounded-full ${
                        isLow ? 'bg-red-100 text-red-700' : 'bg-emerald-50 text-emerald-800'
                      }`}>
                        {item.availableQty} {item.unit}
                      </span>
                    </td>

                    <td className="px-3 py-3.5 text-center font-mono text-slate-500">
                      {item.minQty} {item.unit}
                    </td>

                    <td className="px-3 py-3.5 text-right font-mono tabular-nums text-slate-800 font-semibold">
                      {formatKz(item.unitCost)}
                    </td>

                    <td className="px-3 py-3.5 text-slate-600 truncate max-w-[150px]">
                      {item.supplierName || 'Fornecedor padrão'}
                    </td>

                    <td className="px-4 py-3.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenAdjust(item, 'entrada')}
                          className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-[#1E7620] font-bold text-[11px] rounded flex items-center gap-1 transition-colors"
                          title="Registar Entrada de Stock"
                        >
                          <ArrowDownLeft className="w-3.5 h-3.5" />
                          <span>Entrada</span>
                        </button>

                        <button
                          onClick={() => handleOpenAdjust(item, 'saida')}
                          className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-[11px] rounded flex items-center gap-1 transition-colors"
                          title="Registar Saída / Consumo"
                        >
                          <ArrowUpRight className="w-3.5 h-3.5" />
                          <span>Saída</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredStock.length === 0 && (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    Nenhum material encontrado com os filtros aplicados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Histórico Recente de Movimentos de Stock */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
        <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-3 flex items-center gap-2">
          <History className="w-4 h-4 text-[#13B8DB]" />
          <span>Últimas Movimentações de Stock & Matérias-Primas</span>
        </h3>

        <div className="space-y-2">
          {movements.slice(0, 5).map(m => (
            <div key={m.id} className="p-2.5 rounded-lg border border-slate-100 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-slate-900">{m.stockItemName}</span>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {formatDateTime(m.timestamp)} · Operador: {m.user} · Motivo: {m.reason}
                </div>
              </div>

              <div className="text-right">
                <span className={`font-mono font-black ${
                  m.type === 'entrada' ? 'text-[#1E7620]' : 'text-rose-600'
                }`}>
                  {m.type === 'entrada' ? '+' : '-'}{m.quantity}
                </span>
                <span className="text-[10px] text-slate-400 block uppercase">{m.type}</span>
              </div>
            </div>
          ))}

          {movements.length === 0 && (
            <div className="p-4 text-center text-slate-400 text-xs">
              Sem movimentações recentes registadas.
            </div>
          )}
        </div>
      </div>

      {/* Modal de Entrada / Saída de Stock */}
      {isAdjustModalOpen && selectedStockItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">
                  {adjustType === 'entrada' ? 'Registar Entrada de Stock' : 'Registar Saída de Stock'}
                </h3>
                <p className="text-[11px] text-[#13B8DB]">{selectedStockItem.name}</p>
              </div>
              <button onClick={() => setIsAdjustModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConfirmAdjust} className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs flex justify-between">
                <span>Stock Actual Disponível:</span>
                <span className="font-mono font-bold text-slate-900">{selectedStockItem.availableQty} {selectedStockItem.unit}</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Quantidade ({selectedStockItem.unit}) *
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={adjustQty}
                  onChange={e => setAdjustQty(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Motivo da Movimentação *
                </label>
                <input
                  type="text"
                  required
                  value={adjustReason}
                  onChange={e => setAdjustReason(e.target.value)}
                  placeholder="ex: Factura de fornecedor nº 382, consumo em encomenda, refugo..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAdjustModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 font-bold text-xs rounded-lg shadow-sm ${
                    adjustType === 'entrada'
                      ? 'bg-[#1E7620] hover:bg-green-700 text-white'
                      : 'bg-rose-600 hover:bg-rose-700 text-white'
                  }`}
                >
                  Confirmar Movimentação
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal de Cadastrar Novo Material */}
      {isNewItemModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg my-auto max-h-[92vh] flex flex-col overflow-hidden">
            <div className="p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
              <div>
                <h3 className="font-bold text-sm uppercase tracking-wider text-white">Cadastrar Novo Material de Stock</h3>
                <p className="text-[11px] text-[#13B8DB]">Adicionar consumível ao inventário</p>
              </div>
              <button onClick={() => setIsNewItemModalOpen(false)} className="text-slate-400 hover:text-white p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitNewItem} className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Código do Artigo *</label>
                  <input
                    type="text"
                    required
                    value={formData.code}
                    onChange={e => setFormData({ ...formData, code: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Categoria *</label>
                  <select
                    value={formData.category}
                    onChange={e => setFormData({ ...formData, category: e.target.value as StockCategory })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                  >
                    <option value="papeis">Papéis & Cartolinas</option>
                    <option value="tintas_toner">Tintas & Toners</option>
                    <option value="lonas_vinil">Lonas & Vinil</option>
                    <option value="acabamentos">Acabamentos & Espirais</option>
                    <option value="consumiveis">Estruturas & Acessórios</option>
                  </select>
                </div>

                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nome do Material *</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    placeholder="ex: Lona Frontlit 510g Rolo 3.20m"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Unidade</label>
                  <input
                    type="text"
                    value={formData.unit}
                    onChange={e => setFormData({ ...formData, unit: e.target.value })}
                    placeholder="resmas, rolo, litro, unidade..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Custo de Aquisição (Kz)</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.unitCost}
                    onChange={e => setFormData({ ...formData, unitCost: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Quantidade Inicial</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.availableQty}
                    onChange={e => setFormData({ ...formData, availableQty: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Stock Mínimo (Alerta)</label>
                  <input
                    type="number"
                    min="1"
                    value={formData.minQty}
                    onChange={e => setFormData({ ...formData, minQty: parseFloat(e.target.value) || 1 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono text-amber-700 font-bold"
                  />
                </div>

                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Fornecedor Principal</label>
                  <select
                    value={formData.supplierId}
                    onChange={e => setFormData({ ...formData, supplierId: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                  >
                    {suppliers.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({s.company})</option>
                    ))}
                  </select>
                </div>

                <div className="col-span-1 sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Localização no Armazém</label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={e => setFormData({ ...formData, location: e.target.value })}
                    placeholder="Prateleira 3, Armário Químicos, Armazém B..."
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsNewItemModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 font-bold text-xs rounded-lg hover:bg-slate-50"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg shadow-sm"
                >
                  Cadastrar Material
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
