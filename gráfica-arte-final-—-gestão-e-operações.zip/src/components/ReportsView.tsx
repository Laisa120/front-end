import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  Download,
  Printer,
  TrendingUp,
  DollarSign,
  ShoppingBag,
  Clock,
  Package,
  Layers,
  FileSpreadsheet,
  FileDown,
  CheckCircle2,
  Filter,
} from 'lucide-react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Order, Quote, CashMovement, StockItem, Store, Client, Service } from '../types';
import { formatKz, formatDate } from '../utils/formatters';

interface ReportsViewProps {
  orders: Order[];
  quotes: Quote[];
  cashMovements: CashMovement[];
  stock: StockItem[];
  stores: Store[];
  clients: Client[];
  services: Service[];
  activeStoreId: string;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  orders,
  quotes,
  cashMovements,
  stock,
  stores,
  clients,
  services,
  activeStoreId,
}) => {
  const [period, setPeriod] = useState<'today' | '7days' | 'month' | 'year' | 'all'>('month');
  const [selectedReportTab, setSelectedReportTab] = useState<'vendas' | 'producao' | 'financeiro' | 'stock'>('vendas');
  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const [pdfSuccess, setPdfSuccess] = useState(false);

  // Cálculos de Período
  const now = new Date();
  const filteredMovements = cashMovements.filter(m => {
    if (period === 'all') return true;
    const d = new Date(m.timestamp);
    if (period === 'today') {
      return d.toDateString() === now.toDateString();
    }
    if (period === '7days') {
      const past7 = new Date();
      past7.setDate(now.getDate() - 7);
      return d >= past7;
    }
    if (period === 'month') {
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }
    if (period === 'year') {
      return d.getFullYear() === now.getFullYear();
    }
    return true;
  });

  const totalInflow = filteredMovements
    .filter(m => ['pagamento_encomenda', 'adiantamento', 'pagamento_parcial', 'entrada'].includes(m.type))
    .reduce((sum, m) => sum + m.amount, 0);

  const totalOutflow = filteredMovements
    .filter(m => ['despesa', 'saida'].includes(m.type))
    .reduce((sum, m) => sum + m.amount, 0);

  const netBalance = totalInflow - totalOutflow;

  // Encomendas e Vendas
  const totalInvoiced = orders.reduce((sum, o) => sum + o.total, 0);
  const totalPaid = orders.reduce((sum, o) => sum + o.paidAmount, 0);
  const totalDebt = orders.reduce((sum, o) => sum + o.balanceDue, 0);

  // Serviços Mais Solicitados
  const serviceSalesMap: Record<string, { name: string; count: number; totalKz: number }> = {};
  orders.forEach(order => {
    order.items.forEach(item => {
      if (!serviceSalesMap[item.serviceName]) {
        serviceSalesMap[item.serviceName] = { name: item.serviceName, count: 0, totalKz: 0 };
      }
      serviceSalesMap[item.serviceName].count += item.quantity;
      serviceSalesMap[item.serviceName].totalKz += item.subtotal;
    });
  });

  const topServices = Object.values(serviceSalesMap).sort((a, b) => b.totalKz - a.totalKz);

  // Clientes Mais Activos
  const clientSalesMap: Record<string, { name: string; ordersCount: number; totalKz: number }> = {};
  orders.forEach(order => {
    if (!clientSalesMap[order.clientName]) {
      clientSalesMap[order.clientName] = { name: order.clientName, ordersCount: 0, totalKz: 0 };
    }
    clientSalesMap[order.clientName].ordersCount += 1;
    clientSalesMap[order.clientName].totalKz += order.total;
  });

  const topClients = Object.values(clientSalesMap).sort((a, b) => b.totalKz - a.totalKz);

  // Exportar para Excel / CSV
  const handleExportCSV = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';

    if (selectedReportTab === 'vendas') {
      csvContent += 'Numero,Cliente,Data,Total_Kz,Pago_Kz,Saldo_Kz,Estado\n';
      orders.forEach(o => {
        csvContent += `"${o.number}","${o.clientName}","${formatDate(o.createdAt)}",${o.total},${o.paidAmount},${o.balanceDue},"${o.status}"\n`;
      });
    } else if (selectedReportTab === 'financeiro') {
      csvContent += 'Recibo,Data,Tipo,Descricao,Metodo,Montante_Kz,Responsavel\n';
      filteredMovements.forEach(m => {
        csvContent += `"${m.receiptNumber}","${formatDate(m.timestamp)}","${m.type}","${m.description}","${m.paymentMethod}",${m.amount},"${m.responsibleUser}"\n`;
      });
    } else {
      csvContent += 'Codigo,Material,Categoria,Disponivel,Minimo,Custo_Kz\n';
      stock.forEach(s => {
        csvContent += `"${s.code}","${s.name}","${s.category}",${s.availableQty},${s.minQty},${s.unitCost}\n`;
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `relatorio_${selectedReportTab}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Exportar Relatório em PDF diretamente para o dispositivo do utilizador
  const handlePrint = () => {
    setIsExportingPDF(true);
    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const currentStore = stores.find(s => s.id === activeStoreId);
      const storeName = currentStore ? currentStore.name : 'Todas as Lojas (Consolidado)';

      const periodLabels: Record<string, string> = {
        today: 'Hoje',
        '7days': 'Últimos 7 Dias',
        month: 'Mês Atual (Novembro 2026)',
        year: 'Ano 2026',
        all: 'Histórico Completo (Tudo)',
      };

      const tabTitles: Record<string, string> = {
        vendas: 'Vendas & Encomendas',
        financeiro: 'Fluxo Financeiro & Caixa',
        producao: 'Serviços & Produção',
        stock: 'Consumos & Stock de Materiais',
      };

      // 1. Cabeçalho Corporativo com Paleta de Marca da Gráfica Arte Final
      // Barra estrutural em Azul-Petróleo Escuro (#062E3B)
      doc.setFillColor(6, 46, 59);
      doc.rect(0, 0, 210, 26, 'F');

      // Faixa de destaque em Amarelo Principal (#F7CB18)
      doc.setFillColor(247, 203, 24);
      doc.rect(0, 26, 210, 2.5, 'F');

      // Nome da Empresa e Logo Textual
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.text('GRÁFICA ARTE FINAL', 14, 11);

      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(19, 184, 219);
      doc.text('SISTEMA INTEGRADO DE GESTÃO E OPERAÇÕES EMPRESARIAIS', 14, 17);

      // Informações da Emissão e Unidade (Lado Direito)
      doc.setFontSize(7.5);
      doc.setTextColor(255, 255, 255);
      doc.text(`Data: ${new Date().toLocaleDateString('pt-PT')} ${new Date().toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}`, 196, 11, { align: 'right' });
      doc.setTextColor(247, 203, 24);
      doc.text(`Unidade: ${storeName}`, 196, 17, { align: 'right' });

      // 2. Título e Metadados do Relatório
      let currentY = 36;
      doc.setTextColor(6, 46, 59);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(13);
      doc.text(`Relatório Executivo: ${tabTitles[selectedReportTab]}`, 14, currentY);

      currentY += 5;
      doc.setFontSize(8.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text(`Período de Análise: ${periodLabels[period]} · Loja Responsável: ${storeName}`, 14, currentY);

      // 3. Bloco de Indicadores Consolidados (KPIs)
      currentY += 6;
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(14, currentY, 182, 20, 2, 2, 'FD');

      const colW = 182 / 4;

      // KPI 1: Faturação Bruta
      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 116, 139);
      doc.text('FATURAÇÃO BRUTA', 14 + 4, currentY + 6);
      doc.setFontSize(9.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(6, 46, 59);
      doc.text(formatKz(totalInvoiced), 14 + 4, currentY + 14);

      // KPI 2: Valores Cobrados
      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 116, 139);
      doc.text('VALORES COBRADOS', 14 + colW + 4, currentY + 6);
      doc.setFontSize(9.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 118, 32);
      doc.text(formatKz(totalPaid), 14 + colW + 4, currentY + 14);

      // KPI 3: Dívidas Pendentes
      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 116, 139);
      doc.text('DÍVIDAS PENDENTES', 14 + colW * 2 + 4, currentY + 6);
      doc.setFontSize(9.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(228, 17, 121);
      doc.text(formatKz(totalDebt), 14 + colW * 2 + 4, currentY + 14);

      // KPI 4: Resultado Líquido
      doc.setFontSize(6.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(100, 116, 139);
      doc.text('RESULTADO LÍQUIDO', 14 + colW * 3 + 4, currentY + 6);
      doc.setFontSize(9.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(6, 46, 59);
      doc.text(formatKz(netBalance), 14 + colW * 3 + 4, currentY + 14);

      currentY += 26;

      // 4. Tabelas Operacionais do Relatório Ativo
      if (selectedReportTab === 'vendas') {
        doc.setFontSize(9.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(6, 46, 59);
        doc.text('1. Ranking de Serviços Gráficos Mais Faturados', 14, currentY);
        currentY += 3;

        autoTable(doc, {
          startY: currentY,
          head: [['Serviço Gráfico', 'Quantidade Total', 'Volume Faturado (Kz)']],
          body: topServices.slice(0, 15).map(s => [
            s.name,
            s.count.toString(),
            formatKz(s.totalKz),
          ]),
          headStyles: { fillColor: [6, 46, 59], textColor: [255, 255, 255], fontStyle: 'bold' },
          styles: { fontSize: 8, cellPadding: 2.5 },
          columnStyles: {
            0: { cellWidth: 100 },
            1: { halign: 'center', cellWidth: 35 },
            2: { halign: 'right', cellWidth: 47, fontStyle: 'bold' },
          },
        });

        let finalY = (doc as any).lastAutoTable.finalY + 8;
        if (finalY > 235) {
          doc.addPage();
          finalY = 20;
        }

        doc.setFontSize(9.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(6, 46, 59);
        doc.text('2. Principais Clientes por Volume de Faturação', 14, finalY);
        finalY += 3;

        autoTable(doc, {
          startY: finalY,
          head: [['Cliente', 'Nº de Encomendas', 'Total Faturado (Kz)']],
          body: topClients.slice(0, 15).map(c => [
            c.name,
            c.ordersCount.toString(),
            formatKz(c.totalKz),
          ]),
          headStyles: { fillColor: [6, 46, 59], textColor: [255, 255, 255], fontStyle: 'bold' },
          styles: { fontSize: 8, cellPadding: 2.5 },
          columnStyles: {
            0: { cellWidth: 100 },
            1: { halign: 'center', cellWidth: 35 },
            2: { halign: 'right', cellWidth: 47, fontStyle: 'bold' },
          },
        });
      } else if (selectedReportTab === 'financeiro') {
        doc.setFontSize(9.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(6, 46, 59);
        doc.text(`Extrato Financeiro dos Movimentos de Caixa (${filteredMovements.length})`, 14, currentY);
        currentY += 3;

        autoTable(doc, {
          startY: currentY,
          head: [['Recibo', 'Data', 'Tipo', 'Descrição / Serviço', 'Método', 'Valor']],
          body: filteredMovements.map(m => {
            const isExit = m.type === 'despesa' || m.type === 'saida';
            return [
              m.receiptNumber,
              formatDate(m.timestamp),
              m.type.replace('_', ' ').toUpperCase(),
              m.description,
              m.paymentMethod.toUpperCase(),
              `${isExit ? '-' : '+'}${formatKz(m.amount)}`,
            ];
          }),
          headStyles: { fillColor: [6, 46, 59], textColor: [255, 255, 255], fontStyle: 'bold' },
          styles: { fontSize: 7.5, cellPadding: 2 },
          columnStyles: {
            0: { cellWidth: 26, fontStyle: 'bold' },
            1: { cellWidth: 22 },
            2: { cellWidth: 26 },
            3: { cellWidth: 57 },
            4: { cellWidth: 24 },
            5: { halign: 'right', cellWidth: 27, fontStyle: 'bold' },
          },
        });
      } else if (selectedReportTab === 'producao') {
        doc.setFontSize(9.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(6, 46, 59);
        doc.text('Desempenho da Produção & Status das Encomendas', 14, currentY);
        currentY += 3;

        autoTable(doc, {
          startY: currentY,
          head: [['Nº Encomenda', 'Cliente', 'Etapa', 'Operador', 'Prazo', 'Total Kz', 'Estado']],
          body: orders.map(o => [
            o.number,
            o.clientName,
            `Etapa ${o.productionStage}`,
            o.assignedOperatorName || 'Não atribuído',
            formatDate(o.deadline),
            formatKz(o.total),
            o.status.toUpperCase(),
          ]),
          headStyles: { fillColor: [6, 46, 59], textColor: [255, 255, 255], fontStyle: 'bold' },
          styles: { fontSize: 7.5, cellPadding: 2 },
          columnStyles: {
            0: { cellWidth: 26, fontStyle: 'bold' },
            1: { cellWidth: 40 },
            2: { cellWidth: 20, halign: 'center' },
            3: { cellWidth: 32 },
            4: { cellWidth: 22 },
            5: { halign: 'right', cellWidth: 24, fontStyle: 'bold' },
            6: { cellWidth: 18, halign: 'center' },
          },
        });
      } else if (selectedReportTab === 'stock') {
        doc.setFontSize(9.5);
        doc.setFont('helvetica', 'bold');
        doc.setTextColor(6, 46, 59);
        doc.text('Inventário de Materiais & Níveis Críticos de Stock', 14, currentY);
        currentY += 3;

        autoTable(doc, {
          startY: currentY,
          head: [['Código', 'Material', 'Categoria', 'Qtd Atual', 'Mínimo', 'Custo Unitário', 'Estado']],
          body: stock.map(s => {
            const isLow = s.availableQty <= s.minQty;
            return [
              s.code,
              s.name,
              s.category.replace('_', ' '),
              `${s.availableQty} ${s.unit}`,
              `${s.minQty} ${s.unit}`,
              formatKz(s.unitCost),
              isLow ? 'CRÍTICO' : 'NORMAL',
            ];
          }),
          headStyles: { fillColor: [6, 46, 59], textColor: [255, 255, 255], fontStyle: 'bold' },
          styles: { fontSize: 7.5, cellPadding: 2 },
          columnStyles: {
            0: { cellWidth: 22, fontStyle: 'bold' },
            1: { cellWidth: 55 },
            2: { cellWidth: 28 },
            3: { cellWidth: 22, halign: 'center' },
            4: { cellWidth: 18, halign: 'center' },
            5: { halign: 'right', cellWidth: 23 },
            6: { cellWidth: 14, halign: 'center', fontStyle: 'bold' },
          },
        });
      }

      // 5. Rodapé Informativo em Todas as Páginas
      const totalPages = doc.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        doc.setPage(i);
        doc.setFontSize(7);
        doc.setFont('helvetica', 'normal');
        doc.setTextColor(148, 163, 184);
        doc.setDrawColor(226, 232, 240);
        doc.line(14, 285, 196, 285);
        doc.text(
          'Gráfica Arte Final — Documento gerado eletronicamente para fins de gestão operacional e financeira.',
          14,
          289
        );
        doc.text(`Página ${i} de ${totalPages}`, 196, 289, { align: 'right' });
      }

      // Nome do ficheiro PDF e download direto para o dispositivo
      const cleanTabName = tabTitles[selectedReportTab].toLowerCase().replace(/[^a-z0-9]/gi, '_');
      const filename = `relatorio_${cleanTabName}_${new Date().toISOString().slice(0, 10)}.pdf`;
      doc.save(filename);

      setPdfSuccess(true);
      setTimeout(() => setPdfSuccess(false), 3000);
    } catch (err) {
      console.error('Erro ao gerar PDF:', err);
      window.print();
    } finally {
      setIsExportingPDF(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-[#13B8DB]" />
            <span>Relatórios Executivos & Análise Operacional</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Demonstrativos consolidados de faturação, eficiência produtiva, liquidações e histórico de vendas.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <button
            onClick={handleExportCSV}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs rounded-lg shadow-sm transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Exportar CSV</span>
          </button>

          <button
            onClick={handlePrint}
            disabled={isExportingPDF}
            className={`flex-1 sm:flex-initial flex items-center justify-center gap-2 px-3.5 py-2 font-bold text-xs rounded-lg shadow-sm transition-colors ${
              pdfSuccess
                ? 'bg-emerald-600 text-white'
                : 'bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B]'
            }`}
            title="Exportar relatório oficial formatado em PDF para o dispositivo"
          >
            {pdfSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>PDF Descarregado!</span>
              </>
            ) : isExportingPDF ? (
              <>
                <FileDown className="w-4 h-4 animate-bounce" />
                <span>A Gerar PDF...</span>
              </>
            ) : (
              <>
                <Printer className="w-4 h-4" />
                <span>Imprimir (Exportar PDF)</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Seletor de Período e Tipo de Relatório */}
      <div className="bg-white p-3.5 sm:p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Tabs de Relatórios */}
        <div className="flex items-center gap-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          {[
            { id: 'vendas', label: 'Vendas & Encomendas' },
            { id: 'financeiro', label: 'Fluxo Financeiro & Caixa' },
            { id: 'producao', label: 'Serviços & Produção' },
            { id: 'stock', label: 'Consumos & Stock' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setSelectedReportTab(tab.id as any)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap ${
                selectedReportTab === tab.id
                  ? 'bg-[#062E3B] text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Filtro de Período */}
        <div className="flex flex-wrap items-center gap-1.5 text-xs w-full md:w-auto">
          <span className="font-bold text-slate-500 uppercase text-[10px] mr-1">Período:</span>
          {[
            { id: 'today', label: 'Hoje' },
            { id: '7days', label: '7 Dias' },
            { id: 'month', label: 'Este Mês' },
            { id: 'year', label: 'Ano 2026' },
            { id: 'all', label: 'Tudo' },
          ].map(p => (
            <button
              key={p.id}
              onClick={() => setPeriod(p.id as any)}
              className={`px-2.5 py-1 rounded font-semibold text-xs transition-colors ${
                period === p.id ? 'bg-[#13B8DB] text-[#062E3B] font-bold' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Indicadores Consolidados */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Faturação Bruta</span>
          <div className="text-xl font-black text-slate-900 mt-1 tabular-nums">{formatKz(totalInvoiced)}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">{orders.length} encomendas faturadas</div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Valores Cobrados</span>
          <div className="text-xl font-black text-[#1E7620] mt-1 tabular-nums">{formatKz(totalPaid)}</div>
          <div className="text-[11px] text-emerald-700 font-semibold mt-0.5">
            {totalInvoiced > 0 ? ((totalPaid / totalInvoiced) * 100).toFixed(1) : 0}% taxa de cobrança
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Dívidas Pendentes</span>
          <div className="text-xl font-black text-[#E41179] mt-1 tabular-nums">{formatKz(totalDebt)}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">A receber na entrega</div>
        </div>

        <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">Resultado Líquido</span>
          <div className="text-xl font-black text-[#062E3B] mt-1 tabular-nums">{formatKz(netBalance)}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Entradas ({formatKz(totalInflow)}) - Saídas ({formatKz(totalOutflow)})</div>
        </div>
      </div>

      {/* Tabela do Relatório Selecionado */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden p-4 sm:p-6 space-y-6">
        {selectedReportTab === 'vendas' && (
          <div className="space-y-6">
            <div>
              <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-3">
                Ranking de Serviços Gráficos Mais Faturados
              </h3>
              <div className="border border-slate-200 rounded-lg overflow-x-auto">
                <table className="w-full min-w-[500px] text-xs text-left">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2.5">Serviço Gráfico</th>
                      <th className="px-3 py-2.5 text-center">Quantidade Total</th>
                      <th className="px-4 py-2.5 text-right">Volume Faturado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {topServices.slice(0, 8).map(srv => (
                      <tr key={srv.name} className="hover:bg-slate-50">
                        <td className="px-4 py-3 font-semibold text-slate-900">{srv.name}</td>
                        <td className="px-3 py-3 text-center font-mono">{srv.count}</td>
                        <td className="px-4 py-3 text-right font-black text-slate-900 tabular-nums">
                          {formatKz(srv.totalKz)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div>
              <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-3">
                Principais Clientes por Volume de Faturação
              </h3>
              <div className="border border-slate-200 rounded-lg overflow-x-auto">
                <table className="w-full min-w-[500px] text-xs text-left">
                  <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2.5">Cliente</th>
                      <th className="px-3 py-2.5 text-center">Encomendas</th>
                      <th className="px-4 py-2.5 text-right">Total Faturado</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {topClients.slice(0, 8).map(cli => (
                      <tr key={cli.name} className="hover:bg-slate-50">
                        <td className="px-4 py-3 font-semibold text-slate-900">{cli.name}</td>
                        <td className="px-3 py-3 text-center font-mono">{cli.ordersCount}</td>
                        <td className="px-4 py-3 text-right font-black text-slate-900 tabular-nums">
                          {formatKz(cli.totalKz)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {selectedReportTab === 'financeiro' && (
          <div>
            <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-3">
              Extrato Financeiro dos Movimentos do Período ({filteredMovements.length})
            </h3>
            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full min-w-[620px] text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-2.5">Recibo / Data</th>
                    <th className="px-3 py-2.5">Tipo</th>
                    <th className="px-3 py-2.5">Descrição</th>
                    <th className="px-3 py-2.5">Método</th>
                    <th className="px-3 py-2.5">Responsável</th>
                    <th className="px-4 py-2.5 text-right">Valor</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredMovements.map(m => {
                    const isExit = m.type === 'despesa' || m.type === 'saida';
                    return (
                      <tr key={m.id} className="hover:bg-slate-50">
                        <td className="px-4 py-2.5 font-mono">{m.receiptNumber}</td>
                        <td className="px-3 py-2.5 uppercase font-semibold">{m.type.replace('_', ' ')}</td>
                        <td className="px-3 py-2.5">{m.description}</td>
                        <td className="px-3 py-2.5 uppercase font-mono">{m.paymentMethod}</td>
                        <td className="px-3 py-2.5">{m.responsibleUser}</td>
                        <td className={`px-4 py-2.5 text-right font-black tabular-nums ${isExit ? 'text-rose-600' : 'text-[#1E7620]'}`}>
                          {isExit ? '-' : '+'}{formatKz(m.amount)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {selectedReportTab === 'producao' && (
          <div>
            <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-3">
              Desempenho da Produção & Status dos Trabalhos
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mb-6">
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-xs">
                <span className="font-bold text-slate-600 block">Total de Trabalhos</span>
                <span className="text-lg font-black text-slate-900">{orders.length}</span>
              </div>
              <div className="p-4 bg-green-50 rounded-lg border border-green-200 text-xs">
                <span className="font-bold text-green-800 block">Trabalhos Concluídos</span>
                <span className="text-lg font-black text-green-900">{orders.filter(o => o.status === 'entregue').length}</span>
              </div>
              <div className="p-4 bg-red-50 rounded-lg border border-red-200 text-xs">
                <span className="font-bold text-red-800 block">Trabalhos em Atraso</span>
                <span className="text-lg font-black text-red-900">
                  {orders.filter(o => o.status !== 'entregue' && (new Date(o.deadline) < new Date())).length}
                </span>
              </div>
            </div>
          </div>
        )}

        {selectedReportTab === 'stock' && (
          <div>
            <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider mb-3">
              Inventário de Materiais & Níveis Críticos
            </h3>
            <div className="border border-slate-200 rounded-lg overflow-x-auto">
              <table className="w-full min-w-[560px] text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-2.5">Código / Material</th>
                    <th className="px-3 py-2.5">Categoria</th>
                    <th className="px-3 py-2.5 text-center">Disponível</th>
                    <th className="px-3 py-2.5 text-center">Stock Mínimo</th>
                    <th className="px-4 py-2.5 text-right">Custo de Aquisição</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stock.map(s => (
                    <tr key={s.id} className="hover:bg-slate-50">
                      <td className="px-4 py-3 font-semibold text-slate-900">{s.name} ({s.code})</td>
                      <td className="px-3 py-3 capitalize">{s.category.replace('_', ' ')}</td>
                      <td className="px-3 py-3 text-center font-mono font-bold">{s.availableQty} {s.unit}</td>
                      <td className="px-3 py-3 text-center font-mono">{s.minQty} {s.unit}</td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums">{formatKz(s.unitCost)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
