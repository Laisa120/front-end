import React from 'react';
import { Printer, X, DollarSign, CheckCircle2 } from 'lucide-react';
import { CashMovement, SystemSettings, Store } from '../types';
import { formatKz, formatDateTime } from '../utils/formatters';
import { Logo } from './Logo';

interface ReceiptPrintModalProps {
  movement: CashMovement | null;
  settings: SystemSettings;
  store: Store | null;
  onClose: () => void;
}

export const ReceiptPrintModal: React.FC<ReceiptPrintModalProps> = ({
  movement,
  settings,
  store,
  onClose,
}) => {
  if (!movement) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md my-auto sm:my-8 overflow-hidden max-h-[96vh] flex flex-col">
        {/* Barra Superior Modal */}
        <div className="no-print p-3 sm:p-4 bg-[#062E3B] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <DollarSign className="w-5 h-5 text-[#F7CB18] shrink-0" />
            <span className="font-bold text-xs sm:text-sm truncate">
              Recibo — {movement.receiptNumber}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-2.5 sm:px-3 py-1.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span>Imprimir</span>
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-300 hover:text-white rounded">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Talão de Recibo Oficial para Balcão */}
        <div className="p-4 sm:p-6 text-slate-800 bg-white print-page space-y-4 font-mono text-xs border border-dashed border-slate-300 m-2 sm:m-4 rounded overflow-y-auto flex-1">
          <div className="text-center pb-3 border-b border-dashed border-slate-400">
            <div className="flex justify-center mb-1">
              <Logo customLogoUrl={settings.logoUrl} collapsed={false} />
            </div>
            <div className="font-bold text-slate-900">{settings.companyName}</div>
            <div className="text-[10px] text-slate-600">NIF: {settings.nif}</div>
            <div className="text-[10px] text-slate-600">{store ? store.name : 'Loja Sede'} — Luanda</div>
            <div className="text-[10px] text-slate-600">Tel: {store ? store.phone : settings.phone}</div>
          </div>

          <div className="text-center py-2 border-b border-dashed border-slate-400">
            <span className="font-bold text-sm text-slate-900 block">RECIBO DE CAIXA</span>
            <span className="text-xs font-bold text-[#062E3B]">{movement.receiptNumber}</span>
            <div className="text-[10px] text-slate-500 mt-0.5">{formatDateTime(movement.timestamp)}</div>
          </div>

          <div className="space-y-1.5 text-[11px]">
            {movement.clientName && (
              <div className="flex justify-between">
                <span className="text-slate-500">Cliente:</span>
                <span className="font-bold text-slate-900 text-right">{movement.clientName}</span>
              </div>
            )}

            {movement.orderNumber && (
              <div className="flex justify-between">
                <span className="text-slate-500">Ref. Encomenda:</span>
                <span className="font-bold text-slate-900">{movement.orderNumber}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span className="text-slate-500">Método de Pagamento:</span>
              <span className="font-bold text-slate-900 uppercase">{movement.paymentMethod}</span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-500">Operador / Caixa:</span>
              <span>{movement.responsibleUser}</span>
            </div>

            {movement.serviceName && movement.quantity && (
              <div className="flex justify-between">
                <span className="text-slate-500">Serviço:</span>
                <span className="font-bold text-slate-900 text-right">{movement.serviceName}</span>
              </div>
            )}

            {movement.quantity && (
              <div className="flex justify-between">
                <span className="text-slate-500">Quantidade:</span>
                <span className="font-bold text-slate-900 font-mono">
                  {movement.quantity} {movement.unitPrice ? `× ${formatKz(movement.unitPrice)}` : ''}
                </span>
              </div>
            )}

            <div className="pt-2 border-t border-dashed border-slate-300">
              <span className="text-slate-500 block mb-0.5">Descrição:</span>
              <p className="text-slate-800 italic">{movement.description}</p>
            </div>
          </div>

          <div className="p-3 bg-slate-100 rounded text-center border border-slate-200">
            <span className="text-[10px] uppercase font-bold text-slate-500 block">Valor Liquidado</span>
            <span className="text-lg font-black text-slate-900 tabular-nums">
              {formatKz(movement.amount)}
            </span>
          </div>

          <div className="text-center text-[10px] text-slate-400 pt-3 border-t border-dashed border-slate-400">
            <div>Obrigado pela sua preferência!</div>
            <div>Gráfica Arte Final — Qualidade e Precisão</div>
          </div>
        </div>
      </div>
    </div>
  );
};
