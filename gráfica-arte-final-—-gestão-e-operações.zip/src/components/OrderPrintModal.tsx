import React from 'react';
import { Printer, X, ShoppingBag, CheckCircle2, AlertTriangle, Clock } from 'lucide-react';
import { Order, SystemSettings, Store } from '../types';
import { formatKz, formatDate, formatDateTime } from '../utils/formatters';
import { PRODUCTION_STAGES } from '../services/mockData';
import { Logo } from './Logo';

interface OrderPrintModalProps {
  order: Order | null;
  settings: SystemSettings;
  store: Store | null;
  onClose: () => void;
}

export const OrderPrintModal: React.FC<OrderPrintModalProps> = ({
  order,
  settings,
  store,
  onClose,
}) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  const stageInfo = PRODUCTION_STAGES.find(s => s.stage === order.productionStage);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-3xl my-auto sm:my-8 overflow-hidden max-h-[96vh] flex flex-col">
        {/* Barra Superior Modal */}
        <div className="no-print p-3 sm:p-4 bg-[#062E3B] text-white flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#F7CB18] shrink-0" />
            <span className="font-bold text-xs sm:text-sm truncate max-w-[200px] sm:max-w-none">
              Guia de Produção — {order.number}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-2.5 sm:px-3 py-1.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span>Imprimir</span>
            </button>
            <button onClick={onClose} className="p-1.5 text-slate-300 hover:text-white rounded">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Guia / Talão para Impressão */}
        <div className="p-4 sm:p-8 text-slate-800 bg-white print-page space-y-6 overflow-y-auto flex-1">
          <div className="flex flex-col sm:flex-row items-start justify-between gap-4 pb-4 border-b-2 border-[#062E3B]">
            <div>
              <Logo customLogoUrl={settings.logoUrl} />
              <div className="mt-2 text-xs text-slate-600">
                <div className="font-bold text-slate-900">{settings.companyName}</div>
                <div>NIF: {settings.nif} · Tel: {store ? store.phone : settings.phone}</div>
                <div>{store ? store.name : 'Loja Sede'} — {store ? store.address : settings.address}</div>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <span className="inline-block px-3 py-1 rounded bg-[#062E3B] text-[#F7CB18] text-xs font-black uppercase tracking-wider mb-1">
                Guia de Produção & Entrega
              </span>
              <div className="text-lg sm:text-xl font-black text-slate-900 tabular-nums">{order.number}</div>
              <div className="text-xs text-slate-500 mt-0.5">Criada em: {formatDateTime(order.createdAt)}</div>
              <div className="text-xs font-bold text-red-600 mt-1">
                Prazo Prometido: {formatDate(order.deadline)}
              </div>
            </div>
          </div>

          {/* Dados do Cliente e Produção */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-lg bg-slate-50 border border-slate-200 text-xs">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Cliente</span>
              <div className="font-bold text-sm text-slate-900 mt-0.5">{order.clientName}</div>
              <div>Telefone: <span className="font-mono">{order.clientPhone}</span></div>
              {order.quoteId && <div>Ref. Orçamento: <span className="font-mono">{order.quoteId}</span></div>}
            </div>

            <div className="text-left sm:text-right">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Estado Atual</span>
              <div className="font-bold text-sm text-[#062E3B] uppercase mt-0.5">
                Etapa {order.productionStage}: {stageInfo?.name}
              </div>
              <div>Operador: <span className="font-semibold">{order.assignedOperatorName || 'Por atribuir'}</span></div>
              <div className="capitalize">Prioridade: <span className="font-bold">{order.priority}</span></div>
            </div>
          </div>

          {/* Itens da Encomenda */}
          <div className="border border-slate-200 rounded-lg overflow-x-auto">
            <table className="w-full min-w-[480px] text-xs text-left">
              <thead className="bg-[#062E3B] text-white font-bold">
                <tr>
                  <th className="px-4 py-2.5">Trabalho Gráfico</th>
                  <th className="px-3 py-2.5 text-center">Qtd</th>
                  <th className="px-4 py-2.5 text-right">Preço</th>
                  <th className="px-4 py-2.5 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {order.items.map((item, idx) => (
                  <tr key={item.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                    <td className="px-4 py-3">
                      <div className="font-bold text-slate-900">{item.serviceName}</div>
                      {item.description && <div className="text-[11px] text-slate-500 mt-0.5">{item.description}</div>}
                    </td>
                    <td className="px-3 py-3 text-center font-mono font-bold">{item.quantity}</td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums">{formatKz(item.unitPrice)}</td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatKz(item.subtotal)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Resumo Financeiro da Encomenda */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pt-3 border-t border-slate-200">
            <div className="text-xs text-slate-600 max-w-sm">
              <div className="font-bold text-slate-900 mb-1">Notas do Trabalho:</div>
              <p className="text-[11px]">{order.notes || 'Sem observações especiais registradas.'}</p>
            </div>

            <div className="w-full sm:w-64 space-y-1 text-xs text-right">
              <div className="flex justify-between py-1 text-slate-700">
                <span>Total da Encomenda:</span>
                <span className="font-mono font-bold tabular-nums">{formatKz(order.total)}</span>
              </div>
              <div className="flex justify-between py-1 text-emerald-700 font-bold border-b border-slate-200">
                <span>Valor Liquidado:</span>
                <span className="font-mono tabular-nums">{formatKz(order.paidAmount)}</span>
              </div>
              <div className="flex justify-between py-1.5 text-sm font-black text-[#E41179]">
                <span>Saldo em Falta:</span>
                <span className="font-mono tabular-nums">{formatKz(order.balanceDue)}</span>
              </div>
            </div>
          </div>

          {/* Campo de Assinatura de Entrega */}
          <div className="mt-12 pt-6 border-t border-slate-300 grid grid-cols-2 gap-8 text-center text-xs text-slate-500">
            <div>
              <div className="w-48 mx-auto border-b border-slate-400 mb-1" />
              <span>Responsável pela Expedição</span>
            </div>
            <div>
              <div className="w-48 mx-auto border-b border-slate-400 mb-1" />
              <span>Recebido em Conformidade pelo Cliente</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
