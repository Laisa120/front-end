import React from 'react';
import { Printer, Download, X, CheckCircle2, Building2, Phone, Mail, FileText } from 'lucide-react';
import { Quote, SystemSettings, Store } from '../types';
import { formatKz, formatDate } from '../utils/formatters';
import { Logo } from './Logo';

interface QuotePrintModalProps {
  quote: Quote | null;
  settings: SystemSettings;
  store: Store | null;
  onClose: () => void;
  onConvert?: (quoteId: string) => void;
}

export const QuotePrintModal: React.FC<QuotePrintModalProps> = ({
  quote,
  settings,
  store,
  onClose,
  onConvert,
}) => {
  if (!quote) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-4xl my-auto sm:my-8 overflow-hidden max-h-[96vh] flex flex-col">
        {/* Barra de Ações do Modal (Oculta na Impressão) */}
        <div className="no-print p-3 sm:p-4 bg-[#062E3B] text-white flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-[#F7CB18] shrink-0" />
            <span className="font-bold text-xs sm:text-sm truncate max-w-[200px] sm:max-w-none">
              Proposta Comercial — {quote.number}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {quote.status !== 'aprovado' && onConvert && (
              <button
                onClick={() => {
                  onConvert(quote.id);
                  onClose();
                }}
                className="px-2.5 sm:px-3 py-1.5 bg-[#1E7620] hover:bg-green-700 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors"
              >
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span className="hidden sm:inline">Aprovar & Converter</span>
                <span className="sm:hidden">Aprovar</span>
              </button>
            )}

            <button
              onClick={handlePrint}
              className="px-2.5 sm:px-3 py-1.5 bg-[#F7CB18] hover:bg-[#e6be12] text-[#062E3B] font-bold text-xs rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-4 h-4 shrink-0" />
              <span>Imprimir</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white rounded"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Folha Oficial de Orçamento para Impressão */}
        <div className="p-4 sm:p-8 md:p-12 text-slate-800 bg-white print-page overflow-y-auto flex-1">
          {/* Cabeçalho da Empresa */}
          <div className="flex flex-col sm:flex-row items-start justify-between gap-4 pb-6 border-b-2 border-[#062E3B]">
            <div>
              <Logo customLogoUrl={settings.logoUrl} />
              <div className="mt-3 text-xs text-slate-600 space-y-0.5">
                <div className="font-bold text-slate-900">{settings.companyName}</div>
                <div>NIF: {settings.nif}</div>
                <div>{store ? store.address : settings.address}</div>
                <div>Tel: {store ? store.phone : settings.phone} · {settings.email}</div>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <span className="inline-block px-3 py-1 rounded bg-[#062E3B] text-white text-xs font-black uppercase tracking-wider mb-2">
                Orçamento Oficial
              </span>
              <div className="text-lg sm:text-xl font-black text-slate-900 tabular-nums">{quote.number}</div>
              <div className="text-xs text-slate-500 mt-1">Data: {formatDate(quote.createdAt)}</div>
              <div className="text-xs font-bold text-slate-700">Validade: {quote.validityDays} dias (até {formatDate(quote.expiresAt)})</div>
            </div>
          </div>

          {/* Dados do Cliente */}
          <div className="my-6 p-4 rounded-lg bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Destinatário / Cliente</span>
              <div className="font-bold text-sm text-slate-900 mt-0.5">{quote.clientName}</div>
              {quote.clientNif && <div>NIF: <span className="font-mono">{quote.clientNif}</span></div>}
              <div>Telefone: <span className="font-mono">{quote.clientPhone}</span></div>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Responsável Comercial</span>
              <div className="font-semibold text-slate-900 mt-0.5">{quote.createdBy}</div>
              <div className="text-slate-500">{store ? store.name : 'Loja Sede'}</div>
              <div className="mt-1">
                Estado: <span className="font-bold uppercase text-[#062E3B]">{quote.status}</span>
              </div>
            </div>
          </div>

          {/* Tabela de Itens e Serviços */}
          <div className="my-6 overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full min-w-[500px] text-xs text-left">
              <thead className="bg-[#062E3B] text-white font-bold">
                <tr>
                  <th className="px-4 py-2.5">Item / Serviço Gráfico</th>
                  <th className="px-3 py-2.5 text-center">Qtd</th>
                  <th className="px-4 py-2.5 text-right">Preço Unitário</th>
                  <th className="px-4 py-2.5 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {quote.items.map((item, idx) => (
                  <tr key={item.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                    <td className="px-4 py-3">
                      <div className="font-bold text-slate-900">{item.serviceName}</div>
                      {item.description && (
                        <div className="text-[11px] text-slate-500 mt-0.5">{item.description}</div>
                      )}
                      {item.customSpecs && (
                        <div className="text-[10px] text-[#13B8DB] font-medium mt-0.5">
                          {item.customSpecs.width && item.customSpecs.height && (
                            <span>{item.customSpecs.width}m × {item.customSpecs.height}m · </span>
                          )}
                          {item.customSpecs.material && <span>{item.customSpecs.material} · </span>}
                          {item.customSpecs.finishing && <span>{item.customSpecs.finishing}</span>}
                        </div>
                      )}
                    </td>

                    <td className="px-3 py-3 text-center font-mono font-bold">
                      {item.quantity}
                    </td>

                    <td className="px-4 py-3 text-right font-mono tabular-nums">
                      {formatKz(item.unitPrice)}
                    </td>

                    <td className="px-4 py-3 text-right font-mono font-bold text-slate-900 tabular-nums">
                      {formatKz(item.subtotal)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totais e Condições Financeiras */}
          <div className="flex flex-col sm:flex-row justify-between gap-6 pt-4 border-t border-slate-200">
            <div className="text-xs text-slate-600 max-w-sm space-y-1">
              <span className="font-bold text-slate-900 block uppercase tracking-wider text-[11px]">
                Condições de Pagamento & Produção:
              </span>
              <p>• Adiantamento mínimo obrigatório de 50% para início dos trabalhos gráficos.</p>
              <p>• O saldo remanescente deverá ser liquidado no acto da entrega / levantamento.</p>
              <p>• Coordenadas Bancárias (IBAN): AO06.0040.0000.1234.5678.9012.3 (BAI Luanda)</p>
              {quote.notes && (
                <div className="mt-2 p-2 bg-amber-50 rounded border border-amber-200 text-amber-900">
                  <span className="font-bold">Observações: </span>{quote.notes}
                </div>
              )}
            </div>

            <div className="w-full sm:w-72 space-y-1.5 text-xs text-right">
              <div className="flex justify-between py-1 text-slate-600 border-b border-slate-100">
                <span>Subtotal Ilíquido:</span>
                <span className="font-mono font-semibold tabular-nums">{formatKz(quote.subtotal)}</span>
              </div>

              {quote.discountAmount > 0 && (
                <div className="flex justify-between py-1 text-rose-600 border-b border-slate-100">
                  <span>Desconto Aplicado ({quote.discount}%):</span>
                  <span className="font-mono font-semibold tabular-nums">-{formatKz(quote.discountAmount)}</span>
                </div>
              )}

              <div className="flex justify-between py-2 text-base font-black text-[#062E3B] border-b-2 border-[#062E3B]">
                <span>Total Global:</span>
                <span className="tabular-nums">{formatKz(quote.total)}</span>
              </div>

              <div className="flex justify-between py-1 text-[#13B8DB] font-bold">
                <span>Sinal Obrigatório (50%):</span>
                <span className="font-mono tabular-nums">{formatKz(quote.depositRequired)}</span>
              </div>

              <div className="flex justify-between py-1 text-slate-500 font-medium">
                <span>Saldo na Entrega:</span>
                <span className="font-mono tabular-nums">{formatKz(quote.remainingBalance)}</span>
              </div>
            </div>
          </div>

          {/* Assinaturas */}
          <div className="mt-14 pt-6 border-t border-slate-300 grid grid-cols-2 gap-8 text-center text-xs text-slate-500">
            <div>
              <div className="w-48 mx-auto border-b border-slate-400 mb-1" />
              <span>Pela Gráfica Arte Final</span>
            </div>
            <div>
              <div className="w-48 mx-auto border-b border-slate-400 mb-1" />
              <span>Visto de Aprovação do Cliente</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
