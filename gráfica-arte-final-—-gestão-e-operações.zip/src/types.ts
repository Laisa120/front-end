/**
 * Tipos e Definições de Dados do Sistema Integrado
 * GRÁFICA ARTE FINAL — MANEGAMENTO & OPERAÇÃO DE SISTEMA
 */

export type UserRole =
  | 'admin'          // Administrador geral
  | 'director'       // Director
  | 'gerente'        // Gerente
  | 'atendente'      // Atendente
  | 'designer'       // Designer
  | 'operador'       // Operador de produção
  | 'financeiro'     // Financeiro
  | 'consulta';      // Apenas consulta

export interface Store {
  id: string;
  code: string; // ex: 'LOJA 001'
  name: string; // ex: 'Loja Sede — Gráfica Arte Final'
  address: string;
  phone: string;
  email: string;
  manager: string;
  active: boolean;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  username: string;
  role: UserRole;
  storeId: string; // Loja associada ou 'all' para Admin Geral
  active: boolean;
  createdAt: string;
  lastLogin?: string;
  avatarUrl?: string;
}

export type ClientType = 'particular' | 'empresa' | 'instituicao';

export interface Client {
  id: string;
  name: string;
  commercialName?: string;
  phone: string;
  email: string;
  address: string;
  nif?: string;
  type: ClientType;
  storeId: string;
  notes?: string;
  active: boolean;
  createdAt: string;
}

export type ServiceCategory =
  | 'impressao'
  | 'identidade'
  | 'publicidade'
  | 'eventos'
  | 'acabamentos'
  | 'design';

export type PricingModel = 'fixo' | 'quantidade' | 'personalizado';

export interface Service {
  id: string;
  name: string;
  category: ServiceCategory;
  description: string;
  price: number; // Kz
  unit: 'unidade' | 'm2' | 'cento' | 'milheiro' | 'hora' | 'folha' | 'pacote';
  estimatedHours: number;
  pricingModel: PricingModel;
  active: boolean;
  minQuantity?: number;
}

export interface QuoteCustomSpecs {
  width?: number; // em metros ou cm
  height?: number;
  material?: string;
  finishing?: string;
  sides?: 'frente' | 'frente_verso';
  colors?: string;
  complexityFactor?: number;
}

export interface QuoteItem {
  id: string;
  serviceId: string;
  serviceName: string;
  description?: string;
  quantity: number;
  unitPrice: number;
  customSpecs?: QuoteCustomSpecs;
  subtotal: number;
}

export type QuoteStatus =
  | 'rascunho'
  | 'enviado'
  | 'pendente'
  | 'aprovado'
  | 'rejeitado'
  | 'expirado';

export interface Quote {
  id: string;
  number: string; // ex: 'ORC-2026-0045'
  clientId: string;
  clientName: string;
  clientPhone: string;
  clientNif?: string;
  storeId: string;
  items: QuoteItem[];
  subtotal: number;
  discount: number; // percentagem ou valor
  discountType: 'percentage' | 'fixed';
  discountAmount: number;
  total: number;
  depositRequired: number; // Adiantamento exigido (normalmente 50%)
  remainingBalance: number;
  validityDays: number;
  expiresAt: string;
  status: QuoteStatus;
  notes?: string;
  createdBy: string;
  createdAt: string;
  approvedAt?: string;
  convertedToOrderId?: string;
}

export type OrderStatus =
  | 'aguarda_pagamento'
  | 'em_preparacao'
  | 'em_producao'
  | 'controlo_qualidade'
  | 'pronto_entrega'
  | 'entregue'
  | 'cancelado';

export type ProductionStageNumber = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;

export interface ProductionStageInfo {
  stage: ProductionStageNumber;
  name: string;
  description: string;
}

export interface OrderHistoryEvent {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  stage?: ProductionStageNumber;
  note?: string;
}

export interface OrderIssue {
  id: string;
  reportedAt: string;
  reportedBy: string;
  reason: string;
  stage: ProductionStageNumber;
  resolved: boolean;
  resolvedAt?: string;
  solution?: string;
}

export interface Order {
  id: string;
  number: string; // ex: 'ENC-2026-0038'
  quoteId?: string;
  clientId: string;
  clientName: string;
  clientPhone: string;
  storeId: string;
  items: QuoteItem[];
  total: number;
  paidAmount: number;
  balanceDue: number;
  status: OrderStatus;
  productionStage: ProductionStageNumber;
  assignedOperatorId?: string;
  assignedOperatorName?: string;
  priority: 'baixa' | 'normal' | 'alta' | 'urgente';
  deadline: string; // ISO date
  createdBy: string;
  createdAt: string;
  deliveredAt?: string;
  deliveryNotes?: string;
  notes?: string;
  history: OrderHistoryEvent[];
  issues: OrderIssue[];
  consumedStockRecorded?: boolean;
}

export type PaymentMethod = 'dinheiro' | 'multicaixa' | 'transferencia' | 'outro';

export type MovementType =
  | 'entrada'
  | 'saida'
  | 'pagamento_encomenda'
  | 'adiantamento'
  | 'pagamento_parcial'
  | 'despesa';

export interface CashMovement {
  id: string;
  storeId: string;
  sessionId: string;
  timestamp: string;
  type: MovementType;
  amount: number;
  description: string;
  serviceName?: string;
  quantity?: number;
  unitPrice?: number;
  paymentMethod: PaymentMethod;
  orderId?: string;
  orderNumber?: string;
  clientName?: string;
  receiptNumber: string; // ex: 'REC-2026-0120'
  responsibleUser: string;
  notes?: string;
}

export interface CashSession {
  id: string;
  storeId: string;
  openedAt: string;
  closedAt?: string;
  openedBy: string;
  closedBy?: string;
  initialBalance: number;
  closingBalance?: number;
  actualBalance?: number;
  expectedBalance?: number;
  status: 'aberto' | 'fechado';
  notes?: string;
}

export type StockCategory =
  | 'papeis'
  | 'tintas_toner'
  | 'lonas_vinil'
  | 'acabamentos'
  | 'consumiveis'
  | 'outros';

export interface StockItem {
  id: string;
  code: string; // ex: 'STK-PAP-01'
  name: string;
  category: StockCategory;
  unit: string; // 'resmas', 'rolo m2', 'litro', 'unidade', 'caixa'
  availableQty: number;
  minQty: number;
  unitCost: number; // Kz
  supplierId?: string;
  supplierName?: string;
  storeId: string;
  location?: string;
  updatedAt: string;
  status?: 'normal' | 'baixo' | 'esgotado';
}

export interface StockMovement {
  id: string;
  stockItemId: string;
  stockItemName: string;
  storeId: string;
  type: 'entrada' | 'saida' | 'transferencia' | 'ajuste' | 'consumo_encomenda';
  quantity: number;
  reason: string;
  orderNumber?: string;
  targetStoreId?: string;
  timestamp: string;
  user: string;
}

export interface Supplier {
  id: string;
  name: string;
  company: string;
  contactName: string;
  phone: string;
  email: string;
  address: string;
  nif?: string;
  suppliedCategories: StockCategory[];
  notes?: string;
  active: boolean;
  createdAt: string;
}

export interface SystemSettings {
  companyName: string;
  commercialName: string;
  nif: string;
  phone: string;
  phoneSecondary?: string;
  email: string;
  address: string;
  city: string;
  country: string;
  logoUrl: string;
  quotePrefix: string;
  orderPrefix: string;
  receiptPrefix: string;
  defaultAdvancePercentage: number;
  quoteDefaultValidityDays: number;
  taxPercentage: number;
}
