import {
  Store,
  User,
  Client,
  Service,
  Quote,
  Order,
  CashMovement,
  CashSession,
  StockItem,
  StockMovement,
  Supplier,
  SystemSettings,
  ProductionStageNumber,
} from '../types';

import {
  INITIAL_STORES,
  INITIAL_USERS,
  INITIAL_SERVICES,
  INITIAL_CLIENTS,
  INITIAL_QUOTES,
  INITIAL_ORDERS,
  INITIAL_STOCK,
  INITIAL_SUPPLIERS,
  INITIAL_CASH_SESSION,
  INITIAL_CASH_MOVEMENTS,
  INITIAL_SETTINGS,
  PRODUCTION_STAGES,
} from './mockData';

const STORAGE_KEYS = {
  STORES: 'gaf_stores_v1',
  ACTIVE_STORE: 'gaf_active_store_v1',
  USERS: 'gaf_users_v1',
  CURRENT_USER: 'gaf_current_user_v1',
  CLIENTS: 'gaf_clients_v1',
  SERVICES: 'gaf_services_v1',
  QUOTES: 'gaf_quotes_v1',
  ORDERS: 'gaf_orders_v1',
  CASH_MOVEMENTS: 'gaf_cash_movements_v1',
  CASH_SESSIONS: 'gaf_cash_sessions_v1',
  STOCK: 'gaf_stock_v1',
  STOCK_MOVEMENTS: 'gaf_stock_movements_v1',
  SUPPLIERS: 'gaf_suppliers_v1',
  SETTINGS: 'gaf_settings_v1',
};

function safeGet<T>(key: string, fallback: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return fallback;
    return JSON.parse(item) as T;
  } catch (e) {
    console.error(`Error loading storage key "${key}":`, e);
    return fallback;
  }
}

function safeSet<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error(`Error saving storage key "${key}":`, e);
  }
}

export const StorageService = {
  // Configurações
  getSettings(): SystemSettings {
    return safeGet<SystemSettings>(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS);
  },
  saveSettings(settings: SystemSettings): void {
    safeSet(STORAGE_KEYS.SETTINGS, settings);
  },

  // Lojas
  getStores(): Store[] {
    return safeGet<Store[]>(STORAGE_KEYS.STORES, INITIAL_STORES);
  },
  saveStores(stores: Store[]): void {
    safeSet(STORAGE_KEYS.STORES, stores);
  },
  getActiveStoreId(): string {
    return safeGet<string>(STORAGE_KEYS.ACTIVE_STORE, 'store-001');
  },
  setActiveStoreId(id: string): void {
    safeSet(STORAGE_KEYS.ACTIVE_STORE, id);
  },
  addStore(store: Omit<Store, 'id' | 'createdAt'>): Store {
    const stores = this.getStores();
    const count = stores.length + 1;
    const newStore: Store = {
      ...store,
      id: `store-${String(count).padStart(3, '0')}`,
      createdAt: new Date().toISOString(),
    };
    stores.push(newStore);
    this.saveStores(stores);
    return newStore;
  },

  // Utilizadores & Sessão
  getUsers(): User[] {
    return safeGet<User[]>(STORAGE_KEYS.USERS, INITIAL_USERS);
  },
  saveUsers(users: User[]): void {
    safeSet(STORAGE_KEYS.USERS, users);
  },
  getCurrentUser(): User {
    const users = this.getUsers();
    const stored = safeGet<User | null>(STORAGE_KEYS.CURRENT_USER, null);
    if (stored && users.some(u => u.id === stored.id)) {
      return stored;
    }
    // Default to admin Carlos Silva
    return users[0] || INITIAL_USERS[0];
  },
  setCurrentUser(user: User): void {
    safeSet(STORAGE_KEYS.CURRENT_USER, user);
  },
  addUser(user: Omit<User, 'id' | 'createdAt'>): User {
    const users = this.getUsers();
    const newUser: User = {
      ...user,
      id: `usr-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    this.saveUsers(users);
    return newUser;
  },
  updateUser(user: User): void {
    const users = this.getUsers().map(u => (u.id === user.id ? user : u));
    this.saveUsers(users);
    if (this.getCurrentUser().id === user.id) {
      this.setCurrentUser(user);
    }
  },

  // Clientes
  getClients(): Client[] {
    return safeGet<Client[]>(STORAGE_KEYS.CLIENTS, INITIAL_CLIENTS);
  },
  saveClients(clients: Client[]): void {
    safeSet(STORAGE_KEYS.CLIENTS, clients);
  },
  addClient(client: Omit<Client, 'id' | 'createdAt'>): Client {
    const clients = this.getClients();
    const newClient: Client = {
      ...client,
      id: `cli-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    clients.unshift(newClient);
    this.saveClients(clients);
    return newClient;
  },
  updateClient(client: Client): void {
    const clients = this.getClients().map(c => (c.id === client.id ? client : c));
    this.saveClients(clients);
  },

  // Serviços
  getServices(): Service[] {
    return safeGet<Service[]>(STORAGE_KEYS.SERVICES, INITIAL_SERVICES);
  },
  saveServices(services: Service[]): void {
    safeSet(STORAGE_KEYS.SERVICES, services);
  },
  addService(service: Omit<Service, 'id'>): Service {
    const services = this.getServices();
    const newService: Service = {
      ...service,
      id: `srv-${Date.now()}`,
    };
    services.push(newService);
    this.saveServices(services);
    return newService;
  },
  updateService(service: Service): void {
    const services = this.getServices().map(s => (s.id === service.id ? service : s));
    this.saveServices(services);
  },

  // Orçamentos
  getQuotes(): Quote[] {
    return safeGet<Quote[]>(STORAGE_KEYS.QUOTES, INITIAL_QUOTES);
  },
  saveQuotes(quotes: Quote[]): void {
    safeSet(STORAGE_KEYS.QUOTES, quotes);
  },
  getNextQuoteNumber(): string {
    const quotes = this.getQuotes();
    const year = new Date().getFullYear();
    const nextSeq = quotes.length + 1;
    return `ORC-${year}-${String(nextSeq).padStart(4, '0')}`;
  },
  addQuote(quote: Omit<Quote, 'id' | 'number' | 'createdAt'>): Quote {
    const quotes = this.getQuotes();
    const newQuote: Quote = {
      ...quote,
      id: `orc-${Date.now()}`,
      number: this.getNextQuoteNumber(),
      createdAt: new Date().toISOString(),
    };
    quotes.unshift(newQuote);
    this.saveQuotes(quotes);
    return newQuote;
  },
  updateQuote(quote: Quote): void {
    const quotes = this.getQuotes().map(q => (q.id === quote.id ? quote : q));
    this.saveQuotes(quotes);
  },
  convertQuoteToOrder(quoteId: string, initialDeposit: number = 0, paymentMethod: 'dinheiro' | 'multicaixa' | 'transferencia' | 'outro' = 'multicaixa'): Order | null {
    const quotes = this.getQuotes();
    const quoteIndex = quotes.findIndex(q => q.id === quoteId);
    if (quoteIndex === -1) return null;

    const quote = quotes[quoteIndex];
    const currentUser = this.getCurrentUser();
    const orderNumber = this.getNextOrderNumber();
    const orderId = `enc-${Date.now()}`;

    // Update quote status
    quote.status = 'aprovado';
    quote.approvedAt = new Date().toISOString();
    quote.convertedToOrderId = orderId;
    this.saveQuotes(quotes);

    // Default deadline: 3 business days from now
    const deadline = new Date();
    deadline.setDate(deadline.getDate() + 3);

    const paid = initialDeposit > 0 ? initialDeposit : 0;
    const balance = quote.total - paid;

    const newOrder: Order = {
      id: orderId,
      number: orderNumber,
      quoteId: quote.id,
      clientId: quote.clientId,
      clientName: quote.clientName,
      clientPhone: quote.clientPhone,
      storeId: quote.storeId,
      items: quote.items,
      total: quote.total,
      paidAmount: paid,
      balanceDue: balance,
      status: paid >= quote.total ? 'em_preparacao' : (paid > 0 ? 'em_preparacao' : 'aguarda_pagamento'),
      productionStage: 1, // Recepção da encomenda
      priority: 'normal',
      deadline: deadline.toISOString(),
      createdBy: currentUser.name,
      createdAt: new Date().toISOString(),
      notes: `Convertido a partir do Orçamento ${quote.number}. ${quote.notes || ''}`,
      history: [
        {
          id: `hist-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: currentUser.name,
          action: `Encomenda criada por conversão do Orçamento ${quote.number}`,
          stage: 1,
        },
      ],
      issues: [],
    };

    const orders = this.getOrders();
    orders.unshift(newOrder);
    this.saveOrders(orders);

    // If initial deposit made, register cash movement
    if (initialDeposit > 0) {
      this.addCashMovement({
        storeId: quote.storeId,
        sessionId: 'sess-today',
        timestamp: new Date().toISOString(),
        type: paid >= quote.total ? 'pagamento_encomenda' : 'adiantamento',
        amount: initialDeposit,
        description: `Adiantamento na conversão do Orçamento ${quote.number} para Encomenda ${orderNumber}`,
        paymentMethod,
        orderId: newOrder.id,
        orderNumber: newOrder.number,
        clientName: newOrder.clientName,
        receiptNumber: this.getNextReceiptNumber(),
        responsibleUser: currentUser.name,
      });
    }

    return newOrder;
  },

  // Encomendas
  getOrders(): Order[] {
    return safeGet<Order[]>(STORAGE_KEYS.ORDERS, INITIAL_ORDERS);
  },
  saveOrders(orders: Order[]): void {
    safeSet(STORAGE_KEYS.ORDERS, orders);
  },
  getNextOrderNumber(): string {
    const orders = this.getOrders();
    const year = new Date().getFullYear();
    const nextSeq = orders.length + 1;
    return `ENC-${year}-${String(nextSeq).padStart(4, '0')}`;
  },
  addOrder(order: Omit<Order, 'id' | 'number' | 'createdAt' | 'history' | 'issues'>): Order {
    const orders = this.getOrders();
    const currentUser = this.getCurrentUser();
    const newOrder: Order = {
      ...order,
      id: `enc-${Date.now()}`,
      number: this.getNextOrderNumber(),
      createdAt: new Date().toISOString(),
      history: [
        {
          id: `hist-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: currentUser.name,
          action: 'Encomenda registada no sistema',
          stage: order.productionStage || 1,
        },
      ],
      issues: [],
    };
    orders.unshift(newOrder);
    this.saveOrders(orders);

    // If payment recorded on creation
    if (order.paidAmount > 0) {
      this.addCashMovement({
        storeId: order.storeId,
        sessionId: 'sess-today',
        timestamp: new Date().toISOString(),
        type: order.paidAmount >= order.total ? 'pagamento_encomenda' : 'adiantamento',
        amount: order.paidAmount,
        description: `Pagamento inicial para Encomenda ${newOrder.number}`,
        paymentMethod: 'multicaixa',
        orderId: newOrder.id,
        orderNumber: newOrder.number,
        clientName: newOrder.clientName,
        receiptNumber: this.getNextReceiptNumber(),
        responsibleUser: currentUser.name,
      });
    }

    return newOrder;
  },
  updateOrder(order: Order): void {
    const orders = this.getOrders().map(o => (o.id === order.id ? order : o));
    this.saveOrders(orders);
  },
  updateOrderStage(orderId: string, stage: ProductionStageNumber, note?: string): void {
    const orders = this.getOrders();
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    const currentUser = this.getCurrentUser();
    const stageInfo = PRODUCTION_STAGES.find(s => s.stage === stage);
    order.productionStage = stage;

    // Auto-update status based on stage
    if (stage === 9) {
      order.status = 'entregue';
      order.deliveredAt = new Date().toISOString();
    } else if (stage === 8) {
      order.status = 'pronto_entrega';
    } else if (stage === 7) {
      order.status = 'controlo_qualidade';
    } else if (stage >= 5) {
      order.status = 'em_producao';
    } else {
      order.status = 'em_preparacao';
    }

    order.history.unshift({
      id: `hist-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: currentUser.name,
      action: `Avanço para Etapa ${stage}: ${stageInfo?.name || ''}`,
      stage,
      note,
    });

    this.saveOrders(orders);
  },
  registerOrderPayment(orderId: string, amount: number, paymentMethod: 'dinheiro' | 'multicaixa' | 'transferencia' | 'outro'): void {
    const orders = this.getOrders();
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    const currentUser = this.getCurrentUser();
    order.paidAmount += amount;
    order.balanceDue = Math.max(0, order.total - order.paidAmount);

    const isFull = order.paidAmount >= order.total;
    const movementType = isFull ? 'pagamento_encomenda' : 'pagamento_parcial';

    order.history.unshift({
      id: `hist-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: currentUser.name,
      action: `Pagamento registado: ${amount} Kz (${paymentMethod.toUpperCase()}). Saldo restante: ${order.balanceDue} Kz`,
    });

    this.saveOrders(orders);

    this.addCashMovement({
      storeId: order.storeId,
      sessionId: 'sess-today',
      timestamp: new Date().toISOString(),
      type: movementType,
      amount,
      description: `Pagamento para Encomenda ${order.number} (${order.clientName})`,
      paymentMethod,
      orderId: order.id,
      orderNumber: order.number,
      clientName: order.clientName,
      receiptNumber: this.getNextReceiptNumber(),
      responsibleUser: currentUser.name,
    });
  },

  // Caixa & Movimentos
  getCashMovements(): CashMovement[] {
    return safeGet<CashMovement[]>(STORAGE_KEYS.CASH_MOVEMENTS, INITIAL_CASH_MOVEMENTS);
  },
  saveCashMovements(movements: CashMovement[]): void {
    safeSet(STORAGE_KEYS.CASH_MOVEMENTS, movements);
  },
  getNextReceiptNumber(): string {
    const movements = this.getCashMovements();
    const year = new Date().getFullYear();
    const nextSeq = movements.length + 1;
    return `REC-${year}-${String(nextSeq).padStart(4, '0')}`;
  },
  addCashMovement(movement: Omit<CashMovement, 'id'>): CashMovement {
    const movements = this.getCashMovements();
    const newMovement: CashMovement = {
      ...movement,
      id: `mov-${Date.now()}`,
    };
    movements.unshift(newMovement);
    this.saveCashMovements(movements);
    return newMovement;
  },
  getCashSession(): CashSession {
    return safeGet<CashSession>(STORAGE_KEYS.CASH_SESSIONS, INITIAL_CASH_SESSION);
  },
  saveCashSession(session: CashSession): void {
    safeSet(STORAGE_KEYS.CASH_SESSIONS, session);
  },
  closeCashSession(actualBalance: number, notes?: string): CashSession {
    const session = this.getCashSession();
    const currentUser = this.getCurrentUser();
    session.status = 'fechado';
    session.closedAt = new Date().toISOString();
    session.closedBy = currentUser.name;
    session.actualBalance = actualBalance;
    session.notes = notes;
    this.saveCashSession(session);
    return session;
  },
  openNewCashSession(initialBalance: number, notes?: string): CashSession {
    const currentUser = this.getCurrentUser();
    const newSession: CashSession = {
      id: `sess-${Date.now()}`,
      storeId: this.getActiveStoreId(),
      openedAt: new Date().toISOString(),
      openedBy: currentUser.name,
      initialBalance,
      status: 'aberto',
      notes,
    };
    this.saveCashSession(newSession);
    return newSession;
  },

  // Stock
  getStock(): StockItem[] {
    return safeGet<StockItem[]>(STORAGE_KEYS.STOCK, INITIAL_STOCK);
  },
  saveStock(stock: StockItem[]): void {
    safeSet(STORAGE_KEYS.STOCK, stock);
  },
  getStockMovements(): StockMovement[] {
    return safeGet<StockMovement[]>(STORAGE_KEYS.STOCK_MOVEMENTS, []);
  },
  saveStockMovements(movements: StockMovement[]): void {
    safeSet(STORAGE_KEYS.STOCK_MOVEMENTS, movements);
  },
  addStockItem(item: Omit<StockItem, 'id' | 'updatedAt'>): StockItem {
    const stock = this.getStock();
    const newItem: StockItem = {
      ...item,
      id: `stk-${Date.now()}`,
      updatedAt: new Date().toISOString(),
    };
    stock.push(newItem);
    this.saveStock(stock);
    return newItem;
  },
  updateStockItem(item: StockItem): void {
    const stock = this.getStock().map(s => (s.id === item.id ? { ...item, updatedAt: new Date().toISOString() } : s));
    this.saveStock(stock);
  },
  adjustStock(itemId: string, quantityChange: number, type: 'entrada' | 'saida' | 'ajuste' | 'transferencia' | 'consumo_encomenda', reason: string, orderNumber?: string): void {
    const stock = this.getStock();
    const item = stock.find(s => s.id === itemId);
    if (!item) return;

    item.availableQty = Math.max(0, item.availableQty + quantityChange);
    item.updatedAt = new Date().toISOString();
    this.saveStock(stock);

    const currentUser = this.getCurrentUser();
    const movements = this.getStockMovements();
    movements.unshift({
      id: `smov-${Date.now()}`,
      stockItemId: item.id,
      stockItemName: item.name,
      storeId: item.storeId,
      type,
      quantity: Math.abs(quantityChange),
      reason,
      orderNumber,
      timestamp: new Date().toISOString(),
      user: currentUser.name,
    });
    this.saveStockMovements(movements);
  },

  // Fornecedores
  getSuppliers(): Supplier[] {
    return safeGet<Supplier[]>(STORAGE_KEYS.SUPPLIERS, INITIAL_SUPPLIERS);
  },
  saveSuppliers(suppliers: Supplier[]): void {
    safeSet(STORAGE_KEYS.SUPPLIERS, suppliers);
  },
  addSupplier(supplier: Omit<Supplier, 'id' | 'createdAt'>): Supplier {
    const suppliers = this.getSuppliers();
    const newSup: Supplier = {
      ...supplier,
      id: `sup-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    suppliers.push(newSup);
    this.saveSuppliers(suppliers);
    return newSup;
  },
  updateSupplier(supplier: Supplier): void {
    const suppliers = this.getSuppliers().map(s => (s.id === supplier.id ? supplier : s));
    this.saveSuppliers(suppliers);
  },

  // Reiniciar aos dados iniciais
  resetToDefaults(): void {
    localStorage.removeItem(STORAGE_KEYS.STORES);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_STORE);
    localStorage.removeItem(STORAGE_KEYS.USERS);
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    localStorage.removeItem(STORAGE_KEYS.CLIENTS);
    localStorage.removeItem(STORAGE_KEYS.SERVICES);
    localStorage.removeItem(STORAGE_KEYS.QUOTES);
    localStorage.removeItem(STORAGE_KEYS.ORDERS);
    localStorage.removeItem(STORAGE_KEYS.CASH_MOVEMENTS);
    localStorage.removeItem(STORAGE_KEYS.CASH_SESSIONS);
    localStorage.removeItem(STORAGE_KEYS.STOCK);
    localStorage.removeItem(STORAGE_KEYS.STOCK_MOVEMENTS);
    localStorage.removeItem(STORAGE_KEYS.SUPPLIERS);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
  },

  // Backup & Restauro
  exportData(): string {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      stores: this.getStores(),
      users: this.getUsers(),
      clients: this.getClients(),
      services: this.getServices(),
      quotes: this.getQuotes(),
      orders: this.getOrders(),
      cashMovements: this.getCashMovements(),
      cashSession: this.getCashSession(),
      stock: this.getStock(),
      stockMovements: this.getStockMovements(),
      suppliers: this.getSuppliers(),
      settings: this.getSettings(),
    };
    return JSON.stringify(backup, null, 2);
  },

  importData(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.stores) safeSet(STORAGE_KEYS.STORES, data.stores);
      if (data.users) safeSet(STORAGE_KEYS.USERS, data.users);
      if (data.clients) safeSet(STORAGE_KEYS.CLIENTS, data.clients);
      if (data.services) safeSet(STORAGE_KEYS.SERVICES, data.services);
      if (data.quotes) safeSet(STORAGE_KEYS.QUOTES, data.quotes);
      if (data.orders) safeSet(STORAGE_KEYS.ORDERS, data.orders);
      if (data.cashMovements) safeSet(STORAGE_KEYS.CASH_MOVEMENTS, data.cashMovements);
      if (data.cashSession) safeSet(STORAGE_KEYS.CASH_SESSIONS, data.cashSession);
      if (data.stock) safeSet(STORAGE_KEYS.STOCK, data.stock);
      if (data.stockMovements) safeSet(STORAGE_KEYS.STOCK_MOVEMENTS, data.stockMovements);
      if (data.suppliers) safeSet(STORAGE_KEYS.SUPPLIERS, data.suppliers);
      if (data.settings) safeSet(STORAGE_KEYS.SETTINGS, data.settings);
      return true;
    } catch (e) {
      console.error('Falha ao importar dados:', e);
      return false;
    }
  },
};
