import React, { useState, useEffect } from 'react';
import { StorageService } from './services/storage';
import {
  Store,
  User,
  Client,
  Service,
  Quote,
  Order,
  CashMovement,
  CashSession,
  StockItem,
  StockMovement,
  Supplier,
  SystemSettings,
  ProductionStageNumber,
  PaymentMethod,
} from './types';
import { getDaysRemaining } from './utils/formatters';

import { TopNavbar, ActiveTab } from './components/TopNavbar';
import { DashboardView } from './components/DashboardView';
import { ClientsView } from './components/ClientsView';
import { ServicesView } from './components/ServicesView';
import { QuotesView } from './components/QuotesView';
import { OrdersView } from './components/OrdersView';
import { ProductionView } from './components/ProductionView';
import { CashView } from './components/CashView';
import { StockView } from './components/StockView';
import { SuppliersView } from './components/SuppliersView';
import { StaffView } from './components/StaffView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { QuotePrintModal } from './components/QuotePrintModal';
import { OrderPrintModal } from './components/OrderPrintModal';
import { ReceiptPrintModal } from './components/ReceiptPrintModal';

export default function App() {
  // Estado Global Persistente
  const [stores, setStores] = useState<Store[]>(StorageService.getStores());
  const [activeStoreId, setActiveStoreId] = useState<string>(StorageService.getActiveStoreId());
  const [users, setUsers] = useState<User[]>(StorageService.getUsers());
  const [currentUser, setCurrentUser] = useState<User>(StorageService.getCurrentUser());
  const [clients, setClients] = useState<Client[]>(StorageService.getClients());
  const [services, setServices] = useState<Service[]>(StorageService.getServices());
  const [quotes, setQuotes] = useState<Quote[]>(StorageService.getQuotes());
  const [orders, setOrders] = useState<Order[]>(StorageService.getOrders());
  const [cashMovements, setCashMovements] = useState<CashMovement[]>(StorageService.getCashMovements());
  const [cashSession, setCashSession] = useState<CashSession>(StorageService.getCashSession());
  const [stock, setStock] = useState<StockItem[]>(StorageService.getStock());
  const [stockMovements, setStockMovements] = useState<StockMovement[]>(StorageService.getStockMovements());
  const [suppliers, setSuppliers] = useState<Supplier[]>(StorageService.getSuppliers());
  const [settings, setSettings] = useState<SystemSettings>(StorageService.getSettings());

  // Navegação e Modais
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [printingQuote, setPrintingQuote] = useState<Quote | null>(null);
  const [printingOrder, setPrintingOrder] = useState<Order | null>(null);
  const [printingReceipt, setPrintingReceipt] = useState<CashMovement | null>(null);

  // Contextos pré-selecionados para acções rápidas entre módulos
  const [preselectedClient, setPreselectedClient] = useState<Client | null>(null);
  const [preselectedOrder, setPreselectedOrder] = useState<Order | null>(null);

  // Sincronização e recarga de dados
  const reloadData = () => {
    setStores(StorageService.getStores());
    setActiveStoreId(StorageService.getActiveStoreId());
    setUsers(StorageService.getUsers());
    setCurrentUser(StorageService.getCurrentUser());
    setClients(StorageService.getClients());
    setServices(StorageService.getServices());
    setQuotes(StorageService.getQuotes());
    setOrders(StorageService.getOrders());
    setCashMovements(StorageService.getCashMovements());
    setCashSession(StorageService.getCashSession());
    setStock(StorageService.getStock());
    setStockMovements(StorageService.getStockMovements());
    setSuppliers(StorageService.getSuppliers());
    setSettings(StorageService.getSettings());
  };

  // Filtragem multi-loja (se selecionada uma loja específica)
  const currentStore = stores.find(s => s.id === activeStoreId) || null;

  const filteredOrders = activeStoreId === 'all'
    ? orders
    : orders.filter(o => o.storeId === activeStoreId);

  const filteredQuotes = activeStoreId === 'all'
    ? quotes
    : quotes.filter(q => q.storeId === activeStoreId);

  const filteredCashMovements = activeStoreId === 'all'
    ? cashMovements
    : cashMovements.filter(m => m.storeId === activeStoreId);

  const filteredStock = activeStoreId === 'all'
    ? stock
    : stock.filter(s => s.storeId === activeStoreId);

  const filteredClients = activeStoreId === 'all'
    ? clients
    : clients.filter(c => c.storeId === activeStoreId);

  // Contadores para alertas operacionais no cabeçalho
  const delayedOrders = filteredOrders.filter(o => {
    if (['entregue', 'cancelado'].includes(o.status)) return false;
    return getDaysRemaining(o.deadline).isOverdue;
  });

  const lowStockItems = filteredStock.filter(s => s.availableQty <= s.minQty);
  const pendingQuotes = filteredQuotes.filter(q => q.status === 'pendente' || q.status === 'enviado');

  // Manipuladores de Operações

  const handleStoreChange = (storeId: string) => {
    setActiveStoreId(storeId);
    StorageService.setActiveStoreId(storeId);
  };

  const handleSwitchUser = (user: User) => {
    setCurrentUser(user);
    StorageService.setCurrentUser(user);
  };

  // Clientes
  const handleAddClient = (clientData: Omit<Client, 'id' | 'createdAt'>) => {
    StorageService.addClient(clientData);
    reloadData();
  };

  const handleUpdateClient = (client: Client) => {
    StorageService.updateClient(client);
    reloadData();
  };

  // Orçamentos
  const handleAddQuote = (quoteData: Omit<Quote, 'id' | 'number' | 'createdAt'>) => {
    StorageService.addQuote(quoteData);
    reloadData();
  };

  const handleUpdateQuote = (quote: Quote) => {
    StorageService.updateQuote(quote);
    reloadData();
  };

  const handleConvertToOrder = (quoteId: string, initialDeposit: number, paymentMethod: PaymentMethod) => {
    const newOrder = StorageService.convertQuoteToOrder(quoteId, initialDeposit, paymentMethod);
    reloadData();
    if (newOrder) {
      setPreselectedOrder(newOrder);
      setActiveTab('encomendas');
    }
  };

  // Encomendas
  const handleAddOrder = (orderData: Omit<Order, 'id' | 'number' | 'createdAt' | 'history' | 'issues'>) => {
    const newOrder = StorageService.addOrder(orderData);
    reloadData();
    setPreselectedOrder(newOrder);
  };

  const handleUpdateOrder = (order: Order) => {
    StorageService.updateOrder(order);
    reloadData();
  };

  const handleUpdateOrderStage = (orderId: string, stage: ProductionStageNumber, note?: string) => {
    StorageService.updateOrderStage(orderId, stage, note);
    reloadData();
  };

  const handleRegisterOrderPayment = (orderId: string, amount: number, paymentMethod: PaymentMethod) => {
    StorageService.registerOrderPayment(orderId, amount, paymentMethod);
    reloadData();
  };

  // Produção
  const handleAssignOperator = (orderId: string, operatorId: string, operatorName: string) => {
    const order = orders.find(o => o.id === orderId);
    if (order) {
      StorageService.updateOrder({
        ...order,
        assignedOperatorId: operatorId,
        assignedOperatorName: operatorName,
      });
      reloadData();
    }
  };

  const handleReportIssue = (orderId: string, reason: string, stage: ProductionStageNumber) => {
    const order = orders.find(o => o.id === orderId);
    if (order) {
      const issues = order.issues || [];
      issues.push({
        id: `issue-${Date.now()}`,
        reportedAt: new Date().toISOString(),
        reportedBy: currentUser.name,
        reason,
        stage,
        resolved: false,
      });
      StorageService.updateOrder({ ...order, issues });
      reloadData();
    }
  };

  const handleResolveIssue = (orderId: string, issueId: string, solution: string) => {
    const order = orders.find(o => o.id === orderId);
    if (order && order.issues) {
      const issues = order.issues.map(i =>
        i.id === issueId ? { ...i, resolved: true, resolvedAt: new Date().toISOString(), solution } : i
      );
      StorageService.updateOrder({ ...order, issues });
      reloadData();
    }
  };

  // Caixa
  const handleAddCashMovement = (movementData: Omit<CashMovement, 'id'>) => {
    const mov = StorageService.addCashMovement(movementData);
    reloadData();
    setPrintingReceipt(mov);
  };

  const handleCloseCashSession = (actualBalance: number, notes?: string) => {
    StorageService.closeCashSession(actualBalance, notes);
    reloadData();
  };

  const handleOpenCashSession = (initialBalance: number, notes?: string) => {
    StorageService.openNewCashSession(initialBalance, notes);
    reloadData();
  };

  // Stock
  const handleAddStockItem = (itemData: Omit<StockItem, 'id' | 'updatedAt'>) => {
    StorageService.addStockItem(itemData);
    reloadData();
  };

  const handleUpdateStockItem = (item: StockItem) => {
    StorageService.updateStockItem(item);
    reloadData();
  };

  const handleAdjustStock = (
    itemId: string,
    quantityChange: number,
    type: 'entrada' | 'saida' | 'ajuste' | 'transferencia' | 'consumo_encomenda',
    reason: string
  ) => {
    StorageService.adjustStock(itemId, quantityChange, type, reason);
    reloadData();
  };

  // Serviços
  const handleAddService = (serviceData: Omit<Service, 'id'>) => {
    StorageService.addService(serviceData);
    reloadData();
  };

  const handleUpdateService = (service: Service) => {
    StorageService.updateService(service);
    reloadData();
  };

  // Fornecedores
  const handleAddSupplier = (supplierData: Omit<Supplier, 'id' | 'createdAt'>) => {
    StorageService.addSupplier(supplierData);
    reloadData();
  };

  const handleUpdateSupplier = (supplier: Supplier) => {
    StorageService.updateSupplier(supplier);
    reloadData();
  };

  // Utilizadores
  const handleAddUser = (userData: Omit<User, 'id' | 'createdAt'>) => {
    StorageService.addUser(userData);
    reloadData();
  };

  const handleUpdateUser = (user: User) => {
    StorageService.updateUser(user);
    reloadData();
  };

  // Configurações & Lojas
  const handleUpdateSettings = (newSettings: SystemSettings) => {
    StorageService.saveSettings(newSettings);
    reloadData();
  };

  const handleAddStore = (storeData: Omit<Store, 'id' | 'createdAt'>) => {
    StorageService.addStore(storeData);
    reloadData();
  };

  const handleUpdateStore = (store: Store) => {
    const updated = stores.map(s => (s.id === store.id ? store : s));
    StorageService.saveStores(updated);
    reloadData();
  };

  // Backup & Restauro
  const handleExportData = () => {
    const json = StorageService.exportData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_grafica_arte_final_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportData = (jsonStr: string): boolean => {
    const ok = StorageService.importData(jsonStr);
    if (ok) reloadData();
    return ok;
  };

  const handleResetDefaults = () => {
    StorageService.resetToDefaults();
    reloadData();
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col text-slate-800">
      {/* Menu Superior Profissional (Navegação Superior Dinâmica - Requisito 2) */}
      <TopNavbar
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        stores={stores}
        activeStoreId={activeStoreId}
        onStoreChange={handleStoreChange}
        currentUser={currentUser}
        allUsers={users}
        onSwitchUser={handleSwitchUser}
        customLogoUrl={settings.logoUrl}
        delayedOrdersCount={delayedOrders.length}
        lowStockCount={lowStockItems.length}
        pendingQuotesCount={pendingQuotes.length}
        delayedOrders={delayedOrders}
        lowStockItems={lowStockItems}
        pendingQuotes={pendingQuotes}
      />

      {/* Área Central de Trabalho com Margens e Contraste Profissional */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto px-3 sm:px-6 py-4 sm:py-6 overflow-x-hidden">
        {activeTab === 'dashboard' && (
          <DashboardView
            orders={filteredOrders}
            quotes={filteredQuotes}
            cashMovements={filteredCashMovements}
            stock={filteredStock}
            clients={filteredClients}
            activeStore={currentStore}
            currentUser={currentUser}
            onNavigate={setActiveTab}
            onSelectOrder={(order) => {
              setPreselectedOrder(order);
              setActiveTab('encomendas');
            }}
            onSelectQuote={(quote) => {
              setPrintingQuote(quote);
            }}
            onNewOrder={() => setActiveTab('encomendas')}
            onNewQuote={() => setActiveTab('orcamentos')}
            onNewCashMovement={() => setActiveTab('caixa')}
          />
        )}

        {activeTab === 'clientes' && (
          <ClientsView
            clients={filteredClients}
            quotes={filteredQuotes}
            orders={filteredOrders}
            stores={stores}
            activeStoreId={activeStoreId}
            onAddClient={handleAddClient}
            onUpdateClient={handleUpdateClient}
            onCreateQuoteForClient={(client) => {
              setPreselectedClient(client);
              setActiveTab('orcamentos');
            }}
            onCreateOrderForClient={(client) => {
              setPreselectedClient(client);
              setActiveTab('encomendas');
            }}
          />
        )}

        {activeTab === 'servicos' && (
          <ServicesView
            services={services}
            onAddService={handleAddService}
            onUpdateService={handleUpdateService}
            onSelectServiceForQuote={(service, qty, price) => {
              setActiveTab('orcamentos');
            }}
          />
        )}

        {activeTab === 'orcamentos' && (
          <QuotesView
            quotes={filteredQuotes}
            clients={filteredClients}
            services={services}
            stores={stores}
            activeStoreId={activeStoreId}
            currentUser={currentUser}
            onAddQuote={handleAddQuote}
            onUpdateQuote={handleUpdateQuote}
            onConvertToOrder={handleConvertToOrder}
            onPrintQuote={(quote) => setPrintingQuote(quote)}
            preselectedClient={preselectedClient}
          />
        )}

        {activeTab === 'encomendas' && (
          <OrdersView
            orders={filteredOrders}
            clients={filteredClients}
            services={services}
            stores={stores}
            users={users}
            activeStoreId={activeStoreId}
            currentUser={currentUser}
            onAddOrder={handleAddOrder}
            onUpdateOrder={handleUpdateOrder}
            onUpdateStage={handleUpdateOrderStage}
            onRegisterPayment={handleRegisterOrderPayment}
            onPrintOrder={(order) => setPrintingOrder(order)}
            preselectedOrder={preselectedOrder}
            preselectedClient={preselectedClient}
          />
        )}

        {activeTab === 'producao' && (
          <ProductionView
            orders={filteredOrders}
            users={users}
            stock={filteredStock}
            currentUser={currentUser}
            onUpdateStage={handleUpdateOrderStage}
            onAssignOperator={handleAssignOperator}
            onReportIssue={handleReportIssue}
            onResolveIssue={handleResolveIssue}
            onDeductStock={(order) => {}}
            onSelectOrder={(order) => {
              setPreselectedOrder(order);
              setActiveTab('encomendas');
            }}
          />
        )}

        {activeTab === 'caixa' && (
          <CashView
            cashMovements={filteredCashMovements}
            cashSession={cashSession}
            orders={filteredOrders}
            services={services}
            stores={stores}
            activeStoreId={activeStoreId}
            currentUser={currentUser}
            onAddMovement={handleAddCashMovement}
            onCloseSession={handleCloseCashSession}
            onOpenSession={handleOpenCashSession}
            onPrintReceipt={(mov) => setPrintingReceipt(mov)}
          />
        )}

        {activeTab === 'stock' && (
          <StockView
            stock={filteredStock}
            movements={stockMovements}
            suppliers={suppliers}
            stores={stores}
            activeStoreId={activeStoreId}
            currentUser={currentUser}
            onAddStockItem={handleAddStockItem}
            onUpdateStockItem={handleUpdateStockItem}
            onAdjustStock={handleAdjustStock}
          />
        )}

        {activeTab === 'fornecedores' && (
          <SuppliersView
            suppliers={suppliers}
            stock={filteredStock}
            onAddSupplier={handleAddSupplier}
            onUpdateSupplier={handleUpdateSupplier}
          />
        )}

        {activeTab === 'funcionarios' && (
          <StaffView
            users={users}
            stores={stores}
            currentUser={currentUser}
            onAddUser={handleAddUser}
            onUpdateUser={handleUpdateUser}
            onSwitchUser={handleSwitchUser}
          />
        )}

        {activeTab === 'relatorios' && (
          <ReportsView
            orders={filteredOrders}
            quotes={filteredQuotes}
            cashMovements={filteredCashMovements}
            stock={filteredStock}
            stores={stores}
            clients={filteredClients}
            services={services}
            activeStoreId={activeStoreId}
          />
        )}

        {activeTab === 'configuracoes' && (
          <SettingsView
            settings={settings}
            stores={stores}
            currentUser={currentUser}
            onUpdateSettings={handleUpdateSettings}
            onAddStore={handleAddStore}
            onUpdateStore={handleUpdateStore}
            onExportData={handleExportData}
            onImportData={handleImportData}
            onResetDefaults={handleResetDefaults}
          />
        )}
      </main>

      {/* Rodapé Corporativo Discreto */}
      <footer className="no-print mt-auto bg-[#041D26] text-slate-400 border-t border-[#0b4556] py-4 text-xs">
        <div className="max-w-[1720px] mx-auto px-3 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5 sm:gap-2">
            <span className="font-bold text-white">{settings.companyName}</span>
            <span>·</span>
            <span>NIF: {settings.nif}</span>
            <span>·</span>
            <span>{currentStore ? currentStore.name : 'Todas as Lojas'}</span>
          </div>
          <div className="text-[11px] text-slate-500">
            Gráfica Arte Final — Sistema Integrado de Gestão e Operações Empresariais v1.0
          </div>
        </div>
      </footer>

      {/* Modais de Impressão */}
      <QuotePrintModal
        quote={printingQuote}
        settings={settings}
        store={currentStore}
        onClose={() => setPrintingQuote(null)}
        onConvert={(quoteId) => handleConvertToOrder(quoteId, (printingQuote?.depositRequired || 0), 'multicaixa')}
      />

      <OrderPrintModal
        order={printingOrder}
        settings={settings}
        store={currentStore}
        onClose={() => setPrintingOrder(null)}
      />

      <ReceiptPrintModal
        movement={printingReceipt}
        settings={settings}
        store={currentStore}
        onClose={() => setPrintingReceipt(null)}
      />
    </div>
  );
}
