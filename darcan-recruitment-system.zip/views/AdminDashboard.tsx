
import React from 'react';
import { ShieldCheck, Users, Activity, HardDrive, Bell, ArrowUpRight } from 'lucide-react';

const AdminDashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header>
        <h1 className="text-2xl font-bold text-slate-900">Consola de Administração</h1>
        <p className="text-slate-500">Monitorização global do ecossistema Darcan.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
              <ShieldCheck size={24} />
            </div>
            <span className="flex items-center text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded">ESTÁVEL</span>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Gestores Ativos</h3>
          <p className="text-3xl font-bold text-slate-900 mt-1">14</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
              <Users size={24} />
            </div>
            <span className="text-xs font-bold text-blue-600">+12% hoje</span>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Novos Registos</h3>
          <p className="text-3xl font-bold text-slate-900 mt-1">1.284</p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-slate-100 text-slate-600 rounded-2xl">
              <Activity size={24} />
            </div>
            <span className="text-xs font-bold text-slate-400">99.9% Uptime</span>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Atividade Global</h3>
          <p className="text-3xl font-bold text-slate-900 mt-1">842 <span className="text-sm font-normal text-slate-400">req/m</span></p>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
              <HardDrive size={24} />
            </div>
            <span className="text-xs font-bold text-amber-600">82% ocupado</span>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Armazenamento CVs</h3>
          <p className="text-3xl font-bold text-slate-900 mt-1">4.2 <span className="text-sm font-normal text-slate-400">TB</span></p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-slate-900 text-white p-8 rounded-[2rem] shadow-xl relative overflow-hidden">
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="text-emerald-400" size={24} />
              <h3 className="text-xl font-bold">Alertas de Segurança</h3>
            </div>
            <div className="space-y-4">
              {[
                { title: 'Acesso Não Autorizado', desc: 'Tentativa de login bloqueada em IP: 192.168.1.1', time: 'Há 5 min', color: 'bg-red-500' },
                { title: 'Backup Concluído', desc: 'Snapshot diário efetuado com sucesso na AWS S3.', time: 'Há 2 horas', color: 'bg-emerald-500' },
                { title: 'Novo Gestor Criado', desc: 'Ana Gestora foi adicionada à equipa de RH.', time: 'Há 4 horas', color: 'bg-blue-500' },
              ].map((item, i) => (
                <div key={i} className="flex gap-4 p-4 bg-white/5 rounded-2xl border border-white/10">
                  <div className={`w-1.5 h-auto rounded-full ${item.color}`} />
                  <div>
                    <h4 className="font-bold text-sm">{item.title}</h4>
                    <p className="text-xs text-slate-400 mt-1">{item.desc}</p>
                    <span className="text-[10px] text-slate-500 mt-2 block">{item.time}</span>
                  </div>
                </div>
              ))}
            </div>
            <button className="mt-6 w-full py-3 bg-white/10 hover:bg-white/20 rounded-xl text-sm font-bold transition-all">Ver Logs Completos</button>
          </div>
          {/* Decorative element */}
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl" />
        </div>

        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-6">Equipa de Gestão</h3>
            <div className="space-y-6">
              {[
                { name: 'Ana Gestora', role: 'Head of Recruitment', active: true },
                { name: 'Carlos RH', role: 'Technical Recruiter', active: true },
                { name: 'Sofia Lima', role: 'Talent Acquisition', active: false },
              ].map((member, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center font-bold text-slate-600">
                      {member.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900">{member.name}</h4>
                      <p className="text-xs text-slate-500">{member.role}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className={`w-2 h-2 rounded-full ${member.active ? 'bg-emerald-500' : 'bg-slate-300'}`} />
                    <button className="text-slate-400 hover:text-slate-600"><ArrowUpRight size={18} /></button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <button className="mt-8 text-emerald-600 font-bold text-sm hover:underline">Gerir permissões de acesso →</button>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
