
import React from 'react';
import { SystemConfig } from '../types';
import { Settings, Globe, Monitor, Bell, Save, Info } from 'lucide-react';

interface AdminSystemSettingsProps {
  systemConfig: SystemConfig;
  onUpdateSystemConfig: (config: SystemConfig) => void;
}

const AdminSystemSettings: React.FC<AdminSystemSettingsProps> = ({ systemConfig, onUpdateSystemConfig }) => {
  const handleUpdateSystem = (field: keyof SystemConfig, value: any) => {
    onUpdateSystemConfig({
      ...systemConfig,
      [field]: value
    });
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">Definições do Sistema</h1>
        <p className="text-gray-500">Configure os parâmetros globais e o branding do portal Darcan.</p>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <div className="xl:col-span-2 space-y-6">
          {/* Branding & Info */}
          <div className="bg-white rounded-3xl border border-green-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-50 bg-green-50/10 flex items-center gap-3">
              <Globe className="text-green-600" size={20} />
              <h3 className="font-bold text-gray-900">Branding e Identidade</h3>
            </div>
            <div className="p-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Nome da Instituição</label>
                  <input 
                    type="text" 
                    value={systemConfig.companyName}
                    onChange={(e) => handleUpdateSystem('companyName', e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-green-500 outline-none font-medium text-gray-900"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">E-mail de Suporte/RH</label>
                  <input 
                    type="email" 
                    value={systemConfig.notificationEmail}
                    onChange={(e) => handleUpdateSystem('notificationEmail', e.target.value)}
                    className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-green-500 outline-none font-medium text-gray-900"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Access & Notifications */}
          <div className="bg-white rounded-3xl border border-green-100 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-50 bg-green-50/10 flex items-center gap-3">
              <Monitor className="text-green-600" size={20} />
              <h3 className="font-bold text-gray-900">Preferências e Funcionalidades</h3>
            </div>
            <div className="p-8 space-y-4">
              {/* Notificações Toggle */}
              <div className="flex items-center justify-between p-5 bg-gray-50/50 rounded-2xl border border-gray-100 hover:border-green-200 transition-all">
                <div className="flex gap-4">
                  <div className="p-3 bg-white rounded-xl shadow-sm text-green-600">
                    <Bell size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Sistema de Notificações</h4>
                    <p className="text-xs text-gray-500">Alertar gestores sobre novas inscrições e testes concluídos.</p>
                  </div>
                </div>
                <button
                  onClick={() => handleUpdateSystem('enableNotifications', !systemConfig.enableNotifications)}
                  className={`relative inline-flex h-7 w-12 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    systemConfig.enableNotifications ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                >
                  <span className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${systemConfig.enableNotifications ? 'translate-x-5' : 'translate-x-0'}`} />
                </button>
              </div>

              <div className="flex items-center justify-between p-5 bg-gray-50/50 rounded-2xl border border-gray-100 hover:border-green-200 transition-all">
                <div className="flex gap-4">
                  <div className="p-3 bg-white rounded-xl shadow-sm text-blue-600">
                    <Globe size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Portal de Candidatos Ativo</h4>
                    <p className="text-xs text-gray-500">Permite que novos candidatos criem perfis e visualizem vagas.</p>
                  </div>
                </div>
                <button
                  onClick={() => handleUpdateSystem('allowNewRegistrations', !systemConfig.allowNewRegistrations)}
                  className={`relative inline-flex h-7 w-12 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    systemConfig.allowNewRegistrations ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                >
                  <span className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${systemConfig.allowNewRegistrations ? 'translate-x-5' : 'translate-x-0'}`} />
                </button>
              </div>

              <div className="flex items-center justify-between p-5 bg-gray-50/50 rounded-2xl border border-gray-100 hover:border-green-200 transition-all">
                <div className="flex gap-4">
                  <div className="p-3 bg-white rounded-xl shadow-sm text-amber-600">
                    <Save size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Registo de Auditoria</h4>
                    <p className="text-xs text-gray-500">Logs detalhados de alterações feitas pela equipa administrativa.</p>
                  </div>
                </div>
                <button
                  onClick={() => handleUpdateSystem('auditLogsEnabled', !systemConfig.auditLogsEnabled)}
                  className={`relative inline-flex h-7 w-12 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    systemConfig.auditLogsEnabled ? 'bg-green-600' : 'bg-gray-300'
                  }`}
                >
                  <span className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${systemConfig.auditLogsEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-green-700 text-white p-8 rounded-3xl shadow-xl shadow-green-100 flex flex-col justify-between aspect-square">
            <div>
              <Settings size={40} className="mb-6 opacity-80" />
              <h3 className="text-2xl font-bold mb-2">Resumo Global</h3>
              <p className="text-green-100 text-sm">Controle total sobre o ambiente de recrutamento da {systemConfig.companyName}.</p>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between text-sm border-b border-green-600/50 pb-2">
                <span className="opacity-70">Notificações</span>
                <span className="font-bold">{systemConfig.enableNotifications ? 'Ativas' : 'Desligadas'}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="opacity-70">Auditoria</span>
                <span className="font-bold">{systemConfig.auditLogsEnabled ? 'Ligada' : 'Desligada'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSystemSettings;
