
import React, { useState, useEffect } from 'react';
import { Job, Application, ApplicationStatus, OnlineTest, Question } from '../types';
import { INITIAL_JOBS, INITIAL_TESTS } from '../constants';
import { Clock, CheckCircle, XCircle, Send, Upload, Info, Briefcase, CalendarCheck, AlertTriangle } from 'lucide-react';

interface CandidatePortalProps {
  user: any;
  applications: Application[];
  onApply: (jobId: string, cvUrl: string) => void;
  onFinishTest: (appId: string, score: number) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const CandidatePortal: React.FC<CandidatePortalProps> = ({ 
  user, 
  applications, 
  onApply, 
  onFinishTest,
  activeTab,
  setActiveTab
}) => {
  const [takingTest, setTakingTest] = useState<{ test: OnlineTest; appId: string } | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (takingTest && timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
      return () => clearInterval(timer);
    } else if (takingTest && timeLeft === 0) {
      handleCompleteTest();
    }
  }, [takingTest, timeLeft]);

  const handleStartTest = (app: Application) => {
    const job = INITIAL_JOBS.find(j => j.id === app.jobId);
    const test = INITIAL_TESTS.find(t => t.id === job?.testId);
    if (test) {
      setTakingTest({ test, appId: app.id });
      setTimeLeft(test.timeLimitMinutes * 60);
      setCurrentQuestionIndex(0);
      setAnswers({});
    }
  };

  const handleCompleteTest = () => {
    if (!takingTest) return;
    let score = 0;
    takingTest.test.questions.forEach(q => {
      if (answers[q.id] === q.correctAnswer) {
        score += q.points;
      }
    });
    
    const maxScore = takingTest.test.questions.reduce((acc, q) => acc + q.points, 0);
    const percentScore = (score / maxScore) * 100;
    
    onFinishTest(takingTest.appId, percentScore);
    setTakingTest(null);
  };

  const getJobStatusBadge = (status: ApplicationStatus) => {
    const config: Record<string, { label: string; class: string }> = {
      [ApplicationStatus.PENDING_CV]: { label: 'Currículo Enviado', class: 'bg-blue-100 text-blue-800' },
      [ApplicationStatus.PENDING_TEST]: { label: 'Aguardando Teste', class: 'bg-yellow-100 text-yellow-800' },
      [ApplicationStatus.TEST_IN_PROGRESS]: { label: 'Teste Pendente', class: 'bg-orange-100 text-orange-800' },
      [ApplicationStatus.PENDING_REVIEW]: { label: 'Em Avaliação', class: 'bg-purple-100 text-purple-800' },
      [ApplicationStatus.APPROVED_FOR_INTERVIEW]: { label: 'Entrevista Agendada', class: 'bg-green-100 text-green-800' },
      [ApplicationStatus.REJECTED]: { label: 'Não Selecionado', class: 'bg-red-100 text-red-800' },
    };
    const c = config[status] || { label: status, class: 'bg-gray-100 text-gray-800' };
    return <span className={`px-2 py-1 rounded-full text-xs font-medium ${c.class}`}>{c.label}</span>;
  };

  if (takingTest) {
    const currentQuestion = takingTest.test.questions[currentQuestionIndex];
    return (
      <div className="max-w-4xl mx-auto py-12 px-4">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden border border-green-100">
          <div className="bg-green-700 p-6 flex justify-between items-center text-white">
            <div>
              <h2 className="text-xl font-bold">{takingTest.test.title}</h2>
              <p className="text-xs text-green-200 mt-1 uppercase tracking-widest font-bold">Sistema Americano V/F</p>
            </div>
            <div className="flex items-center gap-2 font-mono text-xl bg-black/20 px-4 py-2 rounded-2xl border border-white/10">
              <Clock size={20} className="text-green-300" />
              {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
            </div>
          </div>
          
          <div className="p-10">
            <div className="mb-8 flex gap-2">
              {takingTest.test.questions.map((_, i) => (
                <div key={i} className={`h-1.5 flex-1 rounded-full transition-all duration-500 ${i <= currentQuestionIndex ? 'bg-green-600' : 'bg-gray-100'}`} />
              ))}
            </div>

            <div className="mb-10 text-center sm:text-left">
              <span className="inline-block px-3 py-1 bg-green-50 text-green-700 rounded-lg text-xs font-bold mb-4">
                Questão {currentQuestionIndex + 1} de {takingTest.test.questions.length}
              </span>
              <h3 className="text-2xl font-bold text-gray-900 leading-tight">{currentQuestion.text}</h3>
              <p className="text-gray-400 text-sm mt-3 flex items-center gap-1">
                <AlertTriangle size={14} className="text-amber-500" /> Julgue a afirmação acima como verdadeira ou falsa.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <button
                onClick={() => setAnswers(prev => ({ ...prev, [currentQuestion.id]: 'TRUE' }))}
                className={`flex flex-col items-center justify-center p-8 rounded-3xl border-4 transition-all group ${
                  answers[currentQuestion.id] === 'TRUE' 
                    ? 'border-green-600 bg-green-50 shadow-xl shadow-green-100' 
                    : 'border-gray-100 hover:border-green-200 hover:bg-green-50/10'
                }`}
              >
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 transition-colors ${
                  answers[currentQuestion.id] === 'TRUE' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-400 group-hover:bg-green-100 group-hover:text-green-600'
                }`}>
                  <CheckCircle size={32} />
                </div>
                <span className={`text-xl font-black uppercase tracking-widest ${
                  answers[currentQuestion.id] === 'TRUE' ? 'text-green-700' : 'text-gray-400'
                }`}>Verdadeiro</span>
              </button>

              <button
                onClick={() => setAnswers(prev => ({ ...prev, [currentQuestion.id]: 'FALSE' }))}
                className={`flex flex-col items-center justify-center p-8 rounded-3xl border-4 transition-all group ${
                  answers[currentQuestion.id] === 'FALSE' 
                    ? 'border-red-600 bg-red-50 shadow-xl shadow-red-100' 
                    : 'border-gray-100 hover:border-red-200 hover:bg-red-50/10'
                }`}
              >
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 transition-colors ${
                  answers[currentQuestion.id] === 'FALSE' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-400 group-hover:bg-red-100 group-hover:text-red-600'
                }`}>
                  <XCircle size={32} />
                </div>
                <span className={`text-xl font-black uppercase tracking-widest ${
                  answers[currentQuestion.id] === 'FALSE' ? 'text-red-700' : 'text-gray-400'
                }`}>Falso</span>
              </button>
            </div>

            <div className="mt-16 flex justify-between items-center">
              <button
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex(prev => prev - 1)}
                className="px-6 py-2 text-gray-400 font-bold hover:text-gray-600 disabled:opacity-30 transition-colors"
              >
                ← Voltar
              </button>
              
              <div className="flex gap-4">
                {currentQuestionIndex < takingTest.test.questions.length - 1 ? (
                  <button
                    onClick={() => setCurrentQuestionIndex(prev => prev + 1)}
                    className="px-10 py-4 bg-green-600 text-white rounded-2xl font-bold hover:bg-green-700 transition-all shadow-lg shadow-green-100 flex items-center gap-2"
                  >
                    Próxima Questão
                  </button>
                ) : (
                  <button
                    onClick={handleCompleteTest}
                    className="px-10 py-4 bg-green-800 text-white rounded-2xl font-bold hover:bg-green-900 transition-all shadow-lg shadow-green-200 flex items-center gap-2"
                  >
                    Finalizar Avaliação <Send size={18} />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex gap-8 border-b border-gray-100 mb-8">
        <button 
          onClick={() => setActiveTab('jobs')}
          className={`pb-4 px-2 text-sm font-bold transition-colors border-b-2 ${activeTab === 'jobs' ? 'border-green-500 text-green-700' : 'border-transparent text-gray-400 hover:text-gray-700'}`}
        >
          Vagas Disponíveis
        </button>
        <button 
          onClick={() => setActiveTab('applications')}
          className={`pb-4 px-2 text-sm font-bold transition-colors border-b-2 ${activeTab === 'applications' ? 'border-green-500 text-green-700' : 'border-transparent text-gray-400 hover:text-gray-700'}`}
        >
          Minhas Candidaturas
        </button>
      </div>

      {activeTab === 'jobs' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {INITIAL_JOBS.filter(j => j.status === 'OPEN').map(job => {
            const hasApplied = applications.some(a => a.jobId === job.id);
            return (
              <div key={job.id} className="bg-white p-6 rounded-3xl shadow-sm border border-green-50 flex flex-col justify-between hover:shadow-md transition-shadow">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <span className="px-3 py-1 bg-green-50 text-green-700 text-[10px] font-black rounded-lg uppercase tracking-widest">{job.department}</span>
                    <span className="text-[10px] text-gray-300 font-bold uppercase">{new Date(job.createdAt).toLocaleDateString()}</span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{job.title}</h3>
                  <p className="text-gray-500 text-sm mb-4 line-clamp-3">{job.description}</p>
                </div>
                <div>
                  {hasApplied ? (
                    <div className="flex items-center gap-2 text-green-600 font-bold py-3 justify-center bg-green-50 rounded-xl">
                      <CheckCircle size={18} /> Inscrito
                    </div>
                  ) : (
                    <button 
                      onClick={() => onApply(job.id, 'cv-url-mockup')}
                      className="w-full py-4 bg-green-600 text-white rounded-2xl font-bold hover:bg-green-700 transition-colors flex items-center justify-center gap-2 shadow-sm"
                    >
                      Candidatar-se <Upload size={18} />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {activeTab === 'applications' && (
        <div className="space-y-4">
          {applications.length === 0 ? (
            <div className="text-center py-24 bg-gray-50 rounded-[2rem] border-2 border-dashed border-gray-200">
              <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-sm">
                <Info className="text-gray-300" size={32} />
              </div>
              <p className="text-gray-500 font-medium">Você ainda não iniciou nenhuma jornada de recrutamento.</p>
              <button onClick={() => setActiveTab('jobs')} className="text-green-600 font-black mt-4 hover:underline uppercase text-xs tracking-widest">Ver Vagas Disponíveis</button>
            </div>
          ) : (
            applications.map(app => {
              const job = INITIAL_JOBS.find(j => j.id === app.jobId);
              return (
                <div key={app.id} className="bg-white p-6 rounded-3xl shadow-sm border border-green-50 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:border-green-200 transition-all">
                  <div className="flex gap-5 items-center">
                    <div className="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center text-green-600 shrink-0">
                      <Briefcase size={28} />
                    </div>
                    <div>
                      <h4 className="font-bold text-gray-900 text-lg">{job?.title}</h4>
                      <div className="flex items-center gap-3 mt-1.5">
                        <span className="text-xs text-gray-400 font-medium">Aplicado em: {new Date(app.appliedAt).toLocaleDateString()}</span>
                        {getJobStatusBadge(app.status)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    {app.status === ApplicationStatus.PENDING_TEST && (
                      <button 
                        onClick={() => handleStartTest(app)}
                        className="px-8 py-3 bg-green-700 text-white rounded-2xl font-bold hover:bg-green-800 transition-all shadow-lg shadow-green-100 flex items-center gap-2"
                      >
                        Iniciar Teste V/F <Send size={16} />
                      </button>
                    )}
                    {app.status === ApplicationStatus.APPROVED_FOR_INTERVIEW && (
                      <div className="bg-green-50 px-5 py-3 rounded-2xl border border-green-100">
                        <p className="text-[10px] font-black text-green-800 uppercase mb-1 tracking-widest">Entrevista Agendada</p>
                        <p className="text-sm text-green-700 flex items-center gap-2 font-bold">
                          <CalendarCheck size={14} /> {new Date(app.interviewDate!).toLocaleString()}
                        </p>
                      </div>
                    )}
                    <button className="p-3 text-gray-300 hover:text-green-600 transition-colors">
                      <Info size={24} />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
};

export default CandidatePortal;
