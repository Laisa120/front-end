
import React from 'react';
import { Briefcase, User, LogOut, Layout } from 'lucide-react';

interface CandidateNavbarProps {
  userName: string;
  onLogout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const CandidateNavbar: React.FC<CandidateNavbarProps> = ({ userName, onLogout, activeTab, setActiveTab }) => {
  return (
    <nav className="bg-white border-b border-green-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <span className="text-xl font-bold text-green-700">Darcan Portal</span>
            <div className="hidden sm:ml-8 sm:flex sm:space-x-8">
              <button
                onClick={() => setActiveTab('jobs')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  activeTab === 'jobs' ? 'border-green-500 text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Vagas Disponíveis
              </button>
              <button
                onClick={() => setActiveTab('applications')}
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  activeTab === 'applications' ? 'border-green-500 text-gray-900' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Minhas Candidaturas
              </button>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <User size={18} className="text-green-600" />
              <span className="hidden sm:inline">{userName}</span>
            </div>
            <button
              onClick={onLogout}
              className="text-gray-500 hover:text-red-600 transition-colors"
              title="Sair"
            >
              <LogOut size={20} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default CandidateNavbar;
