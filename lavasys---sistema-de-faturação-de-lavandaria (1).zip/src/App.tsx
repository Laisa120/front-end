import { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { Orders } from './components/Orders';
import { Customers } from './components/Customers';
import { Services } from './components/Services';
import { Cashiers } from './components/Cashiers';
import { Reports } from './components/Reports';
import { Settings } from './components/Settings';
import { Invoicing } from './components/Invoicing';
import { Banner } from './components/Banner';
import { Login } from './components/Login';
import { LandingPage } from './components/LandingPage';
import { Order, Customer, LaundrySettings, User, LaundryItem } from './types';
import { DEFAULT_SETTINGS, DEFAULT_ITEMS } from './constants';

export default function App() {
  const [isLaundryRegistered, setIsLaundryRegistered] = useState<boolean>(false);
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [view, setView] = useState<'landing' | 'login' | 'system'>('landing');
  
  // State management (in a real app, this would be from an API or LocalStorage)
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [laundryItems, setLaundryItems] = useState<LaundryItem[]>(DEFAULT_ITEMS);
  const [settings, setSettings] = useState<LaundrySettings>(DEFAULT_SETTINGS);
  const [users, setUsers] = useState<User[]>([]);

  // Load registration state from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem('lavasys_settings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
      setIsLaundryRegistered(true);
      // We keep the view as 'landing' so the banner is always the first page
      setView('landing');
    }

    const savedItems = localStorage.getItem('lavasys_items');
    if (savedItems) {
      setLaundryItems(JSON.parse(savedItems));
    }

    const savedUsers = localStorage.getItem('lavasys_users');
    if (savedUsers) {
      setUsers(JSON.parse(savedUsers));
    } else {
      // Initial admin
      const initialAdmin: User = {
        id: 'u1',
        name: 'Administrador',
        email: 'admin@lavasys.com',
        role: 'admin',
        status: 'active',
        createdAt: new Date().toISOString()
      };
      setUsers([initialAdmin]);
    }
  }, []);

  // Mock initial data
  useEffect(() => {
    const mockCustomers: Customer[] = [
      { id: 'c1', name: 'Ana Pereira', email: 'ana@email.com', phone: '912345678', address: 'Av. Liberdade, 10, Lisboa', createdAt: new Date().toISOString() },
      { id: 'c2', name: 'Carlos Santos', email: 'carlos@email.com', phone: '923456789', address: 'Rua Augusta, 5, Lisboa', createdAt: new Date().toISOString() },
    ];
    
    const mockOrders: Order[] = [
      { 
        id: 'o1', 
        customerId: 'c1', 
        items: [{ itemId: '1', quantity: 2, priceAtTime: 1500.00 }], 
        status: 'ready', 
        total: 3000.00, 
        createdAt: new Date(Date.now() - 86400000).toISOString(), 
        updatedAt: new Date().toISOString(), 
        expectedDelivery: new Date().toISOString(),
        paymentStatus: 'paid'
      },
      { 
        id: 'o2', 
        customerId: 'c2', 
        items: [{ itemId: '2', quantity: 1, priceAtTime: 1000.00 }, { itemId: '7', quantity: 1, priceAtTime: 4500.00 }], 
        status: 'processing', 
        total: 5500.00, 
        createdAt: new Date().toISOString(), 
        updatedAt: new Date().toISOString(), 
        expectedDelivery: new Date(Date.now() + 172800000).toISOString(),
        paymentStatus: 'unpaid'
      }
    ];

    setCustomers(mockCustomers);
    setOrders(mockOrders);
  }, []);

  const handleRegisterLaundry = (newSettings: LaundrySettings) => {
    setSettings(newSettings);
    setIsLaundryRegistered(true);
    localStorage.setItem('lavasys_settings', JSON.stringify(newSettings));
    setView('login');
  };

  const handleLogin = (loggedUser: User) => {
    setUser(loggedUser);
    setView('system');
    setActiveTab(loggedUser.role === 'admin' ? 'dashboard' : 'orders');
  };

  const handleLogout = () => {
    setUser(null);
    setView('landing');
  };

  const handleAddOrder = (order: Order) => {
    setOrders([order, ...orders]);
  };

  const handleUpdateOrder = (updatedOrder: Order) => {
    setOrders(orders.map(o => o.id === updatedOrder.id ? updatedOrder : o));
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders(orders.map(o => o.id === orderId ? { ...o, status, updatedAt: new Date().toISOString() } : o));
  };

  const handleDeleteOrder = (orderId: string) => {
    if (window.confirm('Tem certeza que deseja excluir este pedido?')) {
      setOrders(orders.filter(o => o.id !== orderId));
    }
  };

  const handleAddCustomer = (customer: Customer) => {
    setCustomers([customer, ...customers]);
  };

  const handleUpdateCustomer = (updatedCustomer: Customer) => {
    setCustomers(customers.map(c => c.id === updatedCustomer.id ? updatedCustomer : c));
  };

  const handleDeleteCustomer = (customerId: string) => {
    if (window.confirm('Tem certeza que deseja excluir este cliente?')) {
      setCustomers(customers.filter(c => c.id !== customerId));
    }
  };

  const handleAddService = (service: LaundryItem) => {
    const updatedItems = [service, ...laundryItems];
    setLaundryItems(updatedItems);
    localStorage.setItem('lavasys_items', JSON.stringify(updatedItems));
  };

  const handleDeleteService = (serviceId: string) => {
    if (window.confirm('Tem certeza que deseja excluir este serviço?')) {
      const updatedItems = laundryItems.filter(i => i.id !== serviceId);
      setLaundryItems(updatedItems);
      localStorage.setItem('lavasys_items', JSON.stringify(updatedItems));
    }
  };

  const handleAddUser = (newUser: User) => {
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem('lavasys_users', JSON.stringify(updatedUsers));
  };

  const handleUpdateUser = (updatedUser: User) => {
    const updatedUsers = users.map(u => u.id === updatedUser.id ? updatedUser : u);
    setUsers(updatedUsers);
    localStorage.setItem('lavasys_users', JSON.stringify(updatedUsers));
  };

  const handleDeleteUser = (userId: string) => {
    if (window.confirm('Tem certeza que deseja excluir este usuário?')) {
      const updatedUsers = users.filter(u => u.id !== userId);
      setUsers(updatedUsers);
      localStorage.setItem('lavasys_users', JSON.stringify(updatedUsers));
    }
  };

  if (view === 'landing') {
    return (
      <LandingPage 
        isRegistered={isLaundryRegistered} 
        onRegister={handleRegisterLaundry} 
        onProceedToLogin={() => setView('login')}
      />
    );
  }

  if (view === 'login' || !user) {
    return <Login onLogin={handleLogin} users={users} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return user.role === 'admin' ? (
          <>
            <Banner />
            <Dashboard orders={orders} customers={customers} />
          </>
        ) : null;
      case 'invoicing':
        return (
          <Invoicing 
            orders={orders}
            customers={customers}
            laundryItems={laundryItems}
            settings={settings}
            currentUser={user}
            onAddCustomer={handleAddCustomer}
            onUpdateCustomer={handleUpdateCustomer}
            onEmitInvoice={(invoice) => {
              // In a real app, we would add this to the orders list
              // For now, we just log it as the component handles the preview
              console.log('Invoice emitted:', invoice);
            }}
          />
        );
      case 'orders':
        return (
          <Orders 
            orders={orders} 
            customers={customers} 
            laundryItems={laundryItems}
            settings={settings}
            userRole={user.role}
            onAddOrder={handleAddOrder}
            onUpdateOrder={handleUpdateOrder}
            onUpdateStatus={handleUpdateOrderStatus}
            onDeleteOrder={handleDeleteOrder}
          />
        );
      case 'customers':
        return (
          <Customers 
            customers={customers} 
            orders={orders}
            laundryItems={laundryItems}
            onAddCustomer={handleAddCustomer}
            onUpdateCustomer={handleUpdateCustomer}
            onDeleteCustomer={handleDeleteCustomer}
          />
        );
      case 'reports':
        return (
          <Reports 
            orders={orders}
            customers={customers}
            laundryItems={laundryItems}
          />
        );
      case 'services':
        return user.role === 'admin' ? (
          <Services 
            services={laundryItems}
            onAddService={handleAddService}
            onDeleteService={handleDeleteService}
          />
        ) : null;
      case 'cashiers':
        return user.role === 'admin' ? (
          <Cashiers 
            cashiers={users}
            onAddCashier={handleAddUser}
            onUpdateCashier={handleUpdateUser}
            onDeleteCashier={handleDeleteUser}
          />
        ) : null;
      case 'settings':
        return user.role === 'admin' ? (
          <Settings 
            settings={settings} 
            onUpdateSettings={(newSettings) => {
              setSettings(newSettings);
              localStorage.setItem('lavasys_settings', JSON.stringify(newSettings));
            }} 
          />
        ) : null;
      default:
        return user.role === 'admin' ? <Dashboard orders={orders} customers={customers} /> : <Orders orders={orders} customers={customers} laundryItems={laundryItems} onAddOrder={handleAddOrder} onUpdateStatus={handleUpdateOrderStatus} onDeleteOrder={handleDeleteOrder} />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab} user={user} settings={settings} onLogout={handleLogout}>
      {renderContent()}
    </Layout>
  );
}
