import { LaundryItem, LaundrySettings } from './types';

export const DEFAULT_ITEMS: LaundryItem[] = [
  { id: '1', name: 'Lavagem de roupa', price: 1500.00, category: 'clothing' },
  { id: '2', name: 'Passadoria', price: 1000.00, category: 'clothing' },
  { id: '3', name: 'Lavagem a Seco', price: 3500.00, category: 'clothing' },
  { id: '4', name: 'Limpeza de Tapetes', price: 5000.00, category: 'bedding' },
  { id: '5', name: 'Lençol Casal', price: 2000.00, category: 'bedding' },
  { id: '6', name: 'Toalha de Banho', price: 800.00, category: 'bedding' },
  { id: '7', name: 'Edredão', price: 4500.00, category: 'bedding' },
  { id: '8', name: 'Cortina (m2)', price: 2500.00, category: 'curtains' },
];

export const DEFAULT_SETTINGS: LaundrySettings = {
  companyName: 'Lavandaria Brilho Limpo',
  tradeName: 'Brilho Limpo',
  nif: '5001234567',
  companyType: 'Lda',
  country: 'Angola',
  province: 'Luanda',
  municipality: 'Luanda',
  fullAddress: 'Rua 4 de Fevereiro, Luanda',
  postalCode: '0000',
  phone: '923 000 000',
  email: 'contato@brilholimpo.ao',
  ivaRegime: 'geral',
  defaultIvaRate: 14,
  currency: 'Kz',
  invoiceSeries: 'FT',
  startInvoiceNumber: 1,
  invoiceModel: 'A4',
  invoiceNumberFormat: 'SERIE/NUMERO',
  allowCreditSales: false,
  defaultDueDays: 30,
  allowGlobalDiscount: true,
  printerConnectionType: 'usb',
  autoPrintReceipt: false,
  autoDownloadPDF: false,
};

export const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  processing: 'bg-blue-100 text-blue-800 border-blue-200',
  ready: 'bg-green-100 text-green-800 border-green-200',
  delivered: 'bg-gray-100 text-gray-800 border-gray-200',
  cancelled: 'bg-red-100 text-red-800 border-red-200',
};

export const STATUS_LABELS: Record<string, string> = {
  pending: 'Pendente',
  processing: 'Em Processamento',
  ready: 'Pronto',
  delivered: 'Entregue',
  cancelled: 'Cancelado',
};
