import React, { useRef } from 'react';
import { 
  Printer, 
  Download, 
  X, 
  Receipt, 
  Calendar, 
  User, 
  Phone, 
  MapPin,
  CheckCircle2
} from 'lucide-react';
import { Order, Customer, LaundryItem, LaundrySettings } from '../types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface InvoiceProps {
  order: Order;
  customer: Customer;
  laundryItems: LaundryItem[];
  settings: LaundrySettings;
  onClose: () => void;
}

export const Invoice: React.FC<InvoiceProps> = ({ 
  order, 
  customer, 
  laundryItems, 
  settings,
  onClose 
}) => {
  const invoiceRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = async () => {
    if (!invoiceRef.current) return;
    
    const canvas = await html2canvas(invoiceRef.current, {
      scale: 2,
      logging: false,
      useCORS: true
    });
    
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`fatura-${order.id.slice(0, 8)}.pdf`);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[70] flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col my-8">
        {/* Header Actions */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <button 
              onClick={handlePrint}
              className="flex items-center gap-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 px-4 py-2 rounded-xl text-sm font-bold transition-all"
            >
              <Printer className="w-4 h-4" />
              Imprimir
            </button>
            <button 
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-bold transition-all shadow-lg shadow-blue-100"
            >
              <Download className="w-4 h-4" />
              Baixar PDF
            </button>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-200 rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-slate-500" />
          </button>
        </div>

        {/* Invoice Content */}
        <div ref={invoiceRef} className="p-10 bg-white print:p-0">
          {/* Company Info */}
          <div className="flex justify-between items-start mb-10">
            <div>
              {settings.logo ? (
                <img src={settings.logo} alt="Logo" className="h-16 mb-4 object-contain" />
              ) : (
                <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white font-bold text-2xl mb-4">
                  {settings.name.charAt(0)}
                </div>
              )}
              <h1 className="text-2xl font-black text-slate-800 uppercase tracking-tight">{settings.name}</h1>
              <p className="text-sm text-slate-500 max-w-xs mt-1">{settings.address}</p>
              <div className="flex flex-col gap-0.5 mt-3 text-xs font-medium text-slate-400">
                <span>{settings.phone}</span>
                <span>{settings.email}</span>
                {settings.nif && <span>NIF: {settings.nif}</span>}
              </div>
            </div>
            <div className="text-right">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-[10px] font-black uppercase tracking-widest mb-4">
                <Receipt className="w-3 h-3" />
                Fatura Recibo
              </div>
              <h2 className="text-4xl font-black text-slate-200 uppercase tracking-tighter mb-1">#{order.id.slice(0, 8)}</h2>
              <div className="space-y-1 text-xs font-bold text-slate-400">
                <p className="flex items-center justify-end gap-2">
                  Data: {format(new Date(order.createdAt), 'dd/MM/yyyy')}
                  <Calendar className="w-3 h-3" />
                </p>
                <p className="flex items-center justify-end gap-2">
                  Vencimento: {format(new Date(order.expectedDelivery), 'dd/MM/yyyy')}
                  <Calendar className="w-3 h-3" />
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-10 mb-10 p-6 bg-slate-50 rounded-3xl border border-slate-100">
            <div>
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                <User className="w-3 h-3" />
                Dados do Cliente
              </h3>
              <p className="font-bold text-slate-800 text-lg">{customer.name}</p>
              <div className="space-y-1 mt-2 text-sm text-slate-500">
                <p className="flex items-center gap-2">
                  <Phone className="w-3 h-3" />
                  {customer.phone}
                </p>
                <p className="flex items-center gap-2">
                  <MapPin className="w-3 h-3" />
                  {customer.address}
                </p>
              </div>
            </div>
            <div className="text-right">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2 justify-end">
                Status do Pagamento
                <CheckCircle2 className="w-3 h-3" />
              </h3>
              <span className={`inline-block px-4 py-2 rounded-xl text-sm font-black uppercase tracking-tight ${
                order.paymentStatus === 'paid' 
                  ? 'bg-green-100 text-green-700' 
                  : 'bg-amber-100 text-amber-700'
              }`}>
                {order.paymentStatus === 'paid' ? 'Liquidado' : 'Aguardando Pagamento'}
              </span>
            </div>
          </div>

          {/* Items Table */}
          <table className="w-full mb-10">
            <thead>
              <tr className="border-b-2 border-slate-100">
                <th className="text-left py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Descrição do Serviço</th>
                <th className="text-center py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Qtd</th>
                <th className="text-right py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Preço Unit.</th>
                <th className="text-right py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {order.items.map((item, index) => {
                const laundryItem = laundryItems.find(li => li.id === item.itemId);
                return (
                  <tr key={index}>
                    <td className="py-4">
                      <p className="font-bold text-slate-800">{laundryItem?.name || 'Serviço'}</p>
                      <p className="text-xs text-slate-400">Lavagem e Tratamento</p>
                    </td>
                    <td className="py-4 text-center font-bold text-slate-600">{item.quantity}</td>
                    <td className="py-4 text-right font-bold text-slate-600">{item.priceAtTime.toFixed(2)} Kz</td>
                    <td className="py-4 text-right font-black text-slate-800">{(item.quantity * item.priceAtTime).toFixed(2)} Kz</td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-64 space-y-3">
              <div className="flex justify-between text-sm">
                <span className="font-bold text-slate-400">Subtotal</span>
                <span className="font-bold text-slate-600">{order.total.toFixed(2)} Kz</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="font-bold text-slate-400">Desconto</span>
                <span className="font-bold text-slate-600">0.00 Kz</span>
              </div>
              <div className="flex justify-between items-center pt-4 border-t-2 border-slate-100">
                <span className="text-lg font-black text-slate-800 uppercase tracking-tighter">Total Geral</span>
                <span className="text-3xl font-black text-blue-600 tracking-tighter">{order.total.toFixed(2)} Kz</span>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-20 pt-10 border-t border-dashed border-slate-200 text-center">
            <p className="text-sm font-bold text-slate-800 mb-1">Obrigado pela sua preferência!</p>
            <p className="text-xs text-slate-400">Este documento serve como comprovativo de entrega e fatura-recibo.</p>
            <div className="mt-8 flex justify-center gap-10">
              <div className="w-40 border-t border-slate-200 pt-2">
                <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest">Assinatura do Cliente</p>
              </div>
              <div className="w-40 border-t border-slate-200 pt-2">
                <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest">Assinatura da Lavandaria</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
