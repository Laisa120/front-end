import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Calendar, 
  TrendingUp, 
  DollarSign, 
  Package,
  ChevronRight
} from 'lucide-react';
import { format, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear, isWithinInterval, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Order, Customer, LaundryItem } from '../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ReportsProps {
  orders: Order[];
  customers: Customer[];
  laundryItems: LaundryItem[];
}

type ReportType = 'daily' | 'weekly' | 'monthly' | 'yearly';

export const Reports: React.FC<ReportsProps> = ({ orders, customers, laundryItems }) => {
  const [reportType, setReportType] = useState<ReportType>('daily');
  const [isGenerating, setIsGenerating] = useState(false);

  const getFilteredOrders = (type: ReportType) => {
    const now = new Date();
    let start: Date;
    let end: Date;

    switch (type) {
      case 'daily':
        start = startOfDay(now);
        end = endOfDay(now);
        break;
      case 'weekly':
        start = startOfWeek(now, { weekStartsOn: 1 });
        end = endOfWeek(now, { weekStartsOn: 1 });
        break;
      case 'monthly':
        start = startOfMonth(now);
        end = endOfMonth(now);
        break;
      case 'yearly':
        start = startOfYear(now);
        end = endOfYear(now);
        break;
    }

    return orders.filter(order => {
      const orderDate = parseISO(order.createdAt);
      return isWithinInterval(orderDate, { start, end });
    });
  };

  const generatePDF = async (type: ReportType) => {
    setIsGenerating(true);
    const filteredOrders = getFilteredOrders(type);
    const totalRevenue = filteredOrders.reduce((acc, order) => acc + order.total, 0);
    const totalOrders = filteredOrders.length;
    const paidOrders = filteredOrders.filter(o => o.paymentStatus === 'paid').length;
    
    const doc = new jsPDF();
    const title = `Relatório ${type === 'daily' ? 'Diário' : type === 'weekly' ? 'Semanal' : type === 'monthly' ? 'Mensal' : 'Anual'}`;
    const dateStr = format(new Date(), "dd/MM/yyyy HH:mm");

    // Header
    doc.setFontSize(20);
    doc.setTextColor(30, 41, 59); // slate-800
    doc.text('LavaSys - Sistema de Lavandaria', 14, 22);
    
    doc.setFontSize(14);
    doc.setTextColor(71, 85, 105); // slate-600
    doc.text(title, 14, 32);
    
    doc.setFontSize(10);
    doc.text(`Gerado em: ${dateStr}`, 14, 40);

    // Summary Box
    doc.setDrawColor(226, 232, 240); // slate-200
    doc.setFillColor(248, 250, 252); // slate-50
    doc.roundedRect(14, 48, 182, 30, 3, 3, 'FD');
    
    doc.setFontSize(11);
    doc.setTextColor(30, 41, 59);
    doc.text(`Total de Pedidos: ${totalOrders}`, 20, 58);
    doc.text(`Pedidos Pagos: ${paidOrders}`, 20, 66);
    doc.text(`Receita Total: ${totalRevenue.toFixed(2)} Kz`, 120, 58);

    // Table
    const tableData = filteredOrders.map(order => {
      const customer = customers.find(c => c.id === order.customerId);
      return [
        order.id,
        customer?.name || 'N/A',
        format(parseISO(order.createdAt), 'dd/MM/yyyy HH:mm'),
        order.status.toUpperCase(),
        order.paymentStatus === 'paid' ? 'PAGO' : 'PENDENTE',
        `${order.total.toFixed(2)} Kz`
      ];
    });

    autoTable(doc, {
      startY: 85,
      head: [['ID', 'Cliente', 'Data', 'Status', 'Pagamento', 'Total']],
      body: tableData,
      theme: 'striped',
      headStyles: { fillColor: [37, 99, 235] }, // blue-600
      styles: { fontSize: 9 },
    });

    doc.save(`relatorio_${type}_${format(new Date(), 'yyyyMMdd')}.pdf`);
    setIsGenerating(false);
  };

  const filteredOrders = getFilteredOrders(reportType);
  const totalRevenue = filteredOrders.reduce((acc, order) => acc + order.total, 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Relatórios Financeiros</h2>
          <p className="text-slate-500">Acompanhe o desempenho da sua lavandaria em diferentes períodos.</p>
        </div>
      </div>

      {/* Report Type Selector */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { id: 'daily', label: 'Diário', icon: Calendar },
          { id: 'weekly', label: 'Semanal', icon: TrendingUp },
          { id: 'monthly', label: 'Mensal', icon: FileText },
          { id: 'yearly', label: 'Anual', icon: Package },
        ].map((type) => (
          <button
            key={type.id}
            onClick={() => setReportType(type.id as ReportType)}
            className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-3 ${
              reportType === type.id 
                ? 'bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-200' 
                : 'bg-white border-slate-100 text-slate-600 hover:border-blue-200 hover:bg-blue-50/30'
            }`}
          >
            <type.icon className={`w-6 h-6 ${reportType === type.id ? 'text-white' : 'text-blue-500'}`} />
            <span className="font-bold text-sm">{type.label}</span>
          </button>
        ))}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 rounded-xl bg-emerald-50 text-emerald-600">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">Receita no Período</p>
              <p className="text-2xl font-bold text-slate-800">{totalRevenue.toFixed(2)} Kz</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 rounded-xl bg-blue-50 text-blue-600">
              <Package className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">Total de Pedidos</p>
              <p className="text-2xl font-bold text-slate-800">{filteredOrders.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-center">
          <button 
            onClick={() => generatePDF(reportType)}
            disabled={isGenerating}
            className="w-full flex items-center justify-center gap-3 bg-slate-800 hover:bg-slate-900 text-white py-4 rounded-xl font-bold transition-all shadow-lg disabled:opacity-50"
          >
            {isGenerating ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Download className="w-5 h-5" />
                Baixar Relatório PDF
              </>
            )}
          </button>
        </div>
      </div>

      {/* Recent Activity in Period */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-50 flex items-center justify-between">
          <h3 className="font-bold text-slate-800">Detalhamento do Período</h3>
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            {filteredOrders.length} registros encontrados
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">ID</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Cliente</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Data</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Total</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredOrders.map((order) => {
                const customer = customers.find(c => c.id === order.customerId);
                return (
                  <tr key={order.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-4 text-sm font-medium text-slate-600">#{order.id}</td>
                    <td className="px-6 py-4">
                      <p className="text-sm font-bold text-slate-800">{customer?.name || 'N/A'}</p>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {format(parseISO(order.createdAt), 'dd MMM, HH:mm', { locale: ptBR })}
                    </td>
                    <td className="px-6 py-4 font-bold text-slate-800">{order.total.toFixed(2)} Kz</td>
                    <td className="px-6 py-4 text-right">
                      <button className="p-2 text-slate-400 hover:text-blue-600 transition-colors">
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
              {filteredOrders.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                    Nenhum pedido encontrado neste período.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
