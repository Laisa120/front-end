import { LaundryItem, LaundrySettings } from './types';

export const DEFAULT_ITEMS: LaundryItem[] = [
  { id: '1', name: 'Camisa', price: 5.00, category: 'clothing' },
  { id: '2', name: 'Calças', price: 6.50, category: 'clothing' },
  { id: '3', name: 'Vestido', price: 12.00, category: 'clothing' },
  { id: '4', name: 'Casaco', price: 15.00, category: 'clothing' },
  { id: '5', name: 'Lençol Casal', price: 8.00, category: 'bedding' },
  { id: '6', name: 'Toalha de Banho', price: 3.50, category: 'bedding' },
  { id: '7', name: 'Edredão', price: 25.00, category: 'bedding' },
  { id: '8', name: 'Cortina (m2)', price: 10.00, category: 'curtains' },
];

export const DEFAULT_SETTINGS: LaundrySettings = {
  companyName: 'Lavandaria Brilho Azul, Lda',
  tradeName: 'Brilho Azul',
  nif: '500123456',
  companyType: 'Lda',
  country: 'Angola',
  province: 'Luanda',
  municipality: 'Luanda',
  fullAddress: 'Rua das Flores, 123, Luanda',
  postalCode: '0000',
  phone: '+244 900 000 000',
  email: 'contato@brilhoazul.ao',
  ivaRegime: 'geral',
  defaultIvaRate: 14,
  currency: 'Kz',
  invoiceSeries: '2026',
  startInvoiceNumber: 1,
  invoiceModel: 'A4',
  invoiceNumberFormat: 'SERIE/NUMERO',
  allowCreditSales: false,
  defaultDueDays: 30,
  allowGlobalDiscount: true,
  printerConnectionType: 'usb',
  autoPrintReceipt: false,
};

export const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  processing: 'bg-blue-100 text-blue-800 border-blue-200',
  ready: 'bg-green-100 text-green-800 border-green-200',
  delivered: 'bg-gray-100 text-gray-800 border-gray-200',
  cancelled: 'bg-red-100 text-red-800 border-red-200',
};

export const STATUS_LABELS: Record<string, string> = {
  pending: 'Pendente',
  processing: 'Em Processamento',
  ready: 'Pronto',
  delivered: 'Entregue',
  cancelled: 'Cancelado',
};
